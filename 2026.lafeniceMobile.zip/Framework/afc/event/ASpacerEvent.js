
/**
 * 
 */

ASpacerEvent = class ASpacerEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
//---------------------------------------------------------------------------------------------------
//	Component Event Functions
//	events: ['click']

}



