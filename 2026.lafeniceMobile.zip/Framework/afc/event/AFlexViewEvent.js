
/**
 * @author asoocool
 */

class AFlexViewEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.AFlexViewEvent = AFlexViewEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
