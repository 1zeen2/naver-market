
/**
 * @author asoocool
 */

class AWebViewEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.AWebViewEvent = AWebViewEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------




