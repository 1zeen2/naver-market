
/**
 * @author asoocool
 */

class AProgressEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.AProgressEvent = AProgressEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
