
/**
 * @author asoocool
 */

class AFlexLayoutEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.AFlexLayoutEvent = AFlexLayoutEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
