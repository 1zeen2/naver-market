

class AFlowOneLineEvent extends AViewEvent
{
    constructor(acomp)
    {
        super(acomp)
    }
	
	
}
window.AFlowOneLineEvent = AFlowOneLineEvent;


//---------------------------------------------------------------------------------------------------
//	Component Event Functions


/* ex)
AFlowOneLineEvent.prototype.click = function()
{
	this._click();
};
*/

//---------------------------------------------------------------------------------------------------
                    
