                    

class AFlowThreeLineEvent extends AViewEvent
{
    constructor(acomp)
    {
        super(acomp)
    }
	
	
}

window.AFlowThreeLineEvent = AFlowThreeLineEvent;

//---------------------------------------------------------------------------------------------------
//	Component Event Functions


/* ex)
AFlowThreeLineEvent.prototype.click = function()
{
	this._click();
};
*/

//---------------------------------------------------------------------------------------------------
                    
