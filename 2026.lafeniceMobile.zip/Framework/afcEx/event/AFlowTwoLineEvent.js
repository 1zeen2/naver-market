


class AFlowTwoLineEvent extends AViewEvent
{
    constructor(acomp)
    {
        super(acomp)
    }
	
	
}

window.AFlowTwoLineEvent = AFlowTwoLineEvent

//---------------------------------------------------------------------------------------------------
//	Component Event Functions


/* ex)
AFlowTwoLineEvent.prototype.click = function()
{
	this._click();
};
*/

//---------------------------------------------------------------------------------------------------
