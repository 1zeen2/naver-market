
/**
 * @author bks
 */

class APagingBarEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.APagingBarEvent = APagingBarEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
                    
