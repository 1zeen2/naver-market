
/**
 * @author bks
 */

class AFileUploaderEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}

window.AFileUploaderEvent = AFileUploaderEvent;




//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------
