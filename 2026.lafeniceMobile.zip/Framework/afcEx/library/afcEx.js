/**
 * @author asoocool
 */

var afcEx = 
{
	
};

afcEx.compLabel = {
	"AFileUploader": "FileUploader",
	"ACalendarPicker": "CalendarPicker",
	"APagingBar": "PagingBar",
	"AFlowOneLine": "FlowOneLine",
	"AFlowTwoLine": "FlowTwoLine",
	"AFlowThreeLine": "FlowThreeLine",
};






