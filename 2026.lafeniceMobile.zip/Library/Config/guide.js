const guide = {
    1: {
        img: '',
        content: '',  
    },
    2: {
        img: '',
        content: '',
    },
    3: {
        img: '',
        content: '',
    }

}