const page = {
    'Source/Intro/Splash.lay': 'Splash',
    'Source/MainView.lay': 'MainView',
    'Source/Intro/OnBoarding.lay': 'OnBoarding',
    'Source/MainPage/MainPage.lay': 'MainPage', //메인
    'Source/Intro/TermsAgree.lay': 'TermsAgree',
    'Source/Intro/AccessPermission.lay': 'AccessPermission',
    'Source/Intro/Login.lay': 'Login',
    'Source/Intro/SignUpComplete.lay': 'SignUpComplete',    
    'Source/CalendarPage/CalenderMain.lay': 'CalendarPage', //메인
    'Source/ShowinPage/ShowinMain.lay': 'ShowinMain', //메인
    'Source/Payment/PayMain.lay': 'PayMain', //메인
    'Source/MarketPage/MarketMain.lay': 'MarketMain', //메인
    'Source/MarketPage/MarketOrderHistory.lay' : 'MarketOrderHistory', // 구매 내역
    'Source/ShowinPage/ShowinDetail.lay': 'ShowinDetail',   // 전시 상세
    'Source/ShowinPage/ViewingMain.lay': 'ViewingMain',     // 전시 관람내역
    'Source/MorePage/NoticeMain.lay': 'NoticeMain', // 공지사항
    'Source/MorePage/NoticeDetail.lay': 'NoticeDetail', // 공지사항 상세
    'Source/MorePage/Setting.lay': 'Setting', // 설정
    'Source/MorePage/UserInfo.lay': 'UserInfo', // 회원 정보
    'Source/MorePage/MissionInProgress.lay': 'MissionInProgress', //진행중인 미션
    'Source/MorePage/Language.lay': 'Language', // 언어
    'Source/MorePage/PointHistory.lay': 'PointHistory', //포인트 이용 내역
    'Source/MorePage/Event.lay': 'Event',
    'Source/MarketPage/ProductGoods.lay': 'ProductGoods', //굿즈 상세
    'Source/MainPage/AlarmMain.lay': 'AlarmMain', //알림함
    'Source/MorePage/FAQ.lay': 'FAQ', // 자주 묻는 질문
    'Source/MorePage/PrivacyPolicy.lay': 'PrivacyPolicy', // 개인정보 처리방침
    'Source/MorePage/TermsOfService.lay': 'TermsOfService', // 서비스 이용약관
    'Source/MorePage/LegalPolicy.lay': 'LegalPolicy', // 약관 및 정책
    'Source/MorePage/MarketingConsent.lay': 'MarketingConsent', // 마케팅 정보 수신
    'Source/MorePage/CustomerSupport.lay': 'CustomerSupport', // 고객문의
    'Source/MorePage/NotificationSetting.lay': 'NotiSetting',
    'Source/Payment/OrderList.lay': 'OrderList',
}

//url: id