
const network = {
    address: 'http://172.30.1.22:7900/access',
    path: 'api',
}
