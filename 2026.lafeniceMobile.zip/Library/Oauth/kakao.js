function loginWithKakao() {
    return new Promise((resolve, reject) => {
        // 1. 카카오 인증 창 호출
        Kakao.Auth.login({
            success: function (auth) {
                const accessToken = auth.access_token;

                // 2. 인증 성공 시 사용자 정보 요청 (v2/user/me)
                Kakao.API.request({
                    url: "/v2/user/me",
                })
                .then((user) => {
                    // 3. 최종 데이터 객체 생성 및 resolve 호출
                    resolve({
                        provider: "kakao",
                        providerId: String(user.id),
                        accessToken: accessToken,
                    });
                })
                .catch((err) => {
                    // 사용자 정보 조회 실패 시 처리
                    reject(err);
                });
            },
            fail: function (error) {
                // 카카오 인증 자체 실패 시 처리
                reject(error);
            },
        });
    });
}