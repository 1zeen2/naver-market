function openBottomSheet(ownerView, options)
{
    // 윈도우 생성
    const wnd = new AWindow();
	
	// 윈도우 객체들에 저장
	wnd.wndOptions = {
        title: options.title || '',
        path: options.path || '',
        data: options.data || null
    };

    // 부모 컨테이너
    const parent = ownerView.getContainer();
    
    wnd.setOption({
        isModal: true
    });

    // 콜백 실행 result가 true면 콜백 실행
    wnd.setResultCallback((result, data) => {
        if (result === true) {
            console.log('콜백 데이터', data);
            options.onSelect(data);
        } else {
            if (options.onCancel) {
                options.onCancel();
            }
        }
    });

    // 윈도우 오픈
    wnd.openFull('Source/BottomSheet/BottomSheet.lay', parent);
}