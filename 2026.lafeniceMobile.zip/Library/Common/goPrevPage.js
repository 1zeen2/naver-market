function goPrevPage(data, is_popstate = false){
    
    if(!is_popstate && !data && theApp.history_count > 0) {
        history.back();
        return;
    }

    const activePage = theApp.mainContainer.navigator.getActivePage();

    // 1. MainView 내부에서 탭 이동 기록이 있는 경우 처리
    if(activePage && activePage.containerId === 'MainView') {
        const historyArr = activePage.view.page_history;
        if(historyArr && historyArr.length > 1) {
            historyArr.pop(); // 현재 탭 제거
            const prevTab = historyArr.pop(); // 이전 탭 (MovePage에서 다시 push됨)
            activePage.view.SwitchTab(prevTab, true);
            
            if(!is_popstate) {
                history.replaceState({ page: prevTab }, '', `#${prevTab}`);
            }
            theApp.history_count--;
            return;
        }
    }

    theApp.mainContainer.navigator.setSlideDir('right');
    const prevPage = theApp.mainContainer.navigator.getPrevPage();
    let containerId = prevPage ? prevPage.containerId : '';
    let pageId = containerId;
    
    // 2. 이전 페이지가 MainView인 경우 마지막 탭 ID를 가져옴
    if(containerId === 'MainView') {
        const historyArr = prevPage?.view?.page_history;
        if(historyArr && historyArr.length > 0) {
            pageId = historyArr[historyArr.length - 1];
        }
    }

    theApp.mainContainer.navigator.goPrevPage(data);

    // 3. MainView로 돌아온 경우 MovePage(SwitchTab)를 통해 화면 갱신
    if(containerId === 'MainView') {
        const mainViewPage = theApp.mainContainer.navigator.getActivePage();
        if(mainViewPage && mainViewPage.view && mainViewPage.view.SwitchTab) {
            const historyArr = mainViewPage.view.page_history;
            const lastTab = historyArr.pop(); // 마지막 탭을 꺼내서 SwitchTab에 전달
            mainViewPage.view.SwitchTab(lastTab, true);
        }
    }

    if(activePage && activePage.containerId !== 'MainView') {
        setTimeout(() => {
            theApp.mainContainer.navigator.closePage(activePage.containerId);
        }, 800);
    }
    
    if(!is_popstate) {
        history.replaceState({ page: pageId }, '', `#${pageId}`);
    }

    theApp.history_count--;
}