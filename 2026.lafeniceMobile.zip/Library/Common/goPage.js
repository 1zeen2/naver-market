function goPage(pageId, data, pageHistory = false){
    
    const main_view_tabs = ['MainPage', 'MarketMain', 'ShowinMain', 'MoreMain', 'CalendarPage'];

    if (main_view_tabs.includes(pageId)) {
        const activePage = theApp.mainContainer.activePage;
        
        if (activePage && activePage.containerId === 'MainView') {
            if(activePage.view && activePage.view.SwitchTab) {
                activePage.view.SwitchTab(pageId);
                theApp.history_count++;
            }
        } else {
            theApp.mainContainer.navigator.setSlideDir('left');
            theApp.mainContainer.navigator.goPage('MainView', { targetTab: pageId }, pageHistory);
            
            history.pushState({ page: pageId }, '', `#${pageId}`);
            theApp.history_count++;
        }
    } else {
        theApp.mainContainer.navigator.setSlideDir('left');
        theApp.mainContainer.navigator.goPage(pageId, data, pageHistory);
        
        history.pushState({ page: pageId }, '', `#${pageId}`);
        theApp.history_count++;
    }

    // const title = (typeof menuCollection !== 'undefined' && menuCollection[pageId]) ? menuCollection[pageId] : '메인';
    // document.title = `QUERY | ${title}`;
}