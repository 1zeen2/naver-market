const fmt_rules = {


    'required': {
        'Y': '필수',
        'N': '선택',
    },

    'number': (value, unit = '') => {
        const num = Number(value);
    
        // 유효한 숫자가 아닐 경우의 처리
        if (isNaN(num)) {
            return `0${unit}`;
        }

        // 천 단위 콤마 포맷팅
        const formatted = num.toLocaleString('ko-KR');

        // 단위 결합 후 반환
        return `${formatted}${unit}`;
    }
    









}