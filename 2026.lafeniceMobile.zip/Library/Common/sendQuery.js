async function sendQuery(path = '', trcode = '', inblock = {}, fileData = null) {
    const url = `${network.address}/${path}/${trcode}`;
    const isRefreshRequest = path === 'auth' && trcode === 'refresh';

    const isMultipart = fileData instanceof FormData;
    let requestBody = isMultipart ? fileData : JSON.stringify(inblock);

    if (isMultipart && inblock && Object.keys(inblock).length > 0) {
        requestBody.append('requestDto', JSON.stringify(inblock));
    }

    try {
        const fetchOptions = {
            method: "POST",
            headers: {
                "Authorization": (theApp.auth_session && !isRefreshRequest) 
                                 ? `Bearer ${theApp.auth_session.accessToken}` : '',
            },
            body: requestBody,
        };

        if (!isMultipart) {
            fetchOptions.headers["Content-Type"] = "application/json";
        }

        const response = await fetch(url, fetchOptions);
        // 3. 401 Unauthorized 처리
        if (response.status === 401) {
            // [중요] 리프레시 요청 자체가 401인 경우 재귀를 중단하고 즉시 종료
            if (isRefreshRequest) {
                
                const refreshResult = await sendQuery('auth', 'refresh', { refreshToken: localStorage.getItem('refreshToken') });

                if (refreshResult && refreshResult.accessToken) {
                    theApp.auth_session.accessToken = refreshResult.accessToken;
                    // 성공 시에만 원본 요청을 재시도함
                    return await sendQuery(path, trcode, inblock, fileData);
                } else {
                    new AToast().show('세션이 만료되었습니다.');
                    goPage('Login', {});
                }     
                
            }
        }

        if (response.status !== 200) throw new Error(result.message);

        const result = await response.json();
        return result;
        
    } catch (err) {
        return {
            error: true,
            message: err,
        };
    }
}