
class ProductAllList extends AView
{
	constructor()
	{
		super()

		this.m_get_data = null;         // 받은 데이터
        this.m_exhibition_uid = null;   // 전시ID
        this.m_select_cnt = 0;          // 선택한 총 상품 개수
        this.m_select_amt = 0;          // 선택한 총 상품 가격
        this.m_is_show_all = false;     // true:바텀시트열림 false:닫힘
        this.m_select_goods = [];       // 선택한 굿즈 목록 정보

        this.m_startY = 0;
        this.m_start_height = 0;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

		this.m_get_data = this.getContainer().getData();
		this.m_exhibition_uid = this.m_get_data.exhibition_uid;

        this.goods_img.setImage( network.address.replace('/access', '') + this.m_get_data.thumbnail_path );
        this.name_lbl.setText( this.m_get_data.exhibition_title );
        this.subtext_lbl.setText( this.m_get_data.exhibition_subtitle );
        this.GetGoodsListData();

        // 이미지 배경 블러
        document.querySelectorAll('.back_blur').forEach(wrap => {
            const img = wrap.querySelector('img');
            if (!img) return;

            wrap.style.setProperty('--bg', `url("${img.src}")`);
        });

        this.bottom_view.element.classList.add('open');

        // 리스트 뷰 스타일
        this.goods_list.itemWrapper[0].classList.add('wrapper-align');
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    // TFUNCTION: PrevBtn: 뒤로가기 버튼 
	PrevBtn(comp, info, e)
	{
		goPrevPage();
        // this.getContainer().close();
	}

    // TFUNCTION: GetGoodsListData: 굿즈 리스트 데이터를 가져온다.
    async GetGoodsListData()
    {
        let res = await sendQuery('exhibition', 'goodsList', {exhibition_uid : this.m_exhibition_uid});
        
        this.goods_list.removeAllItems();
        
        if(res.error || res.length === 0)
        {
            this.goods_cnt_lbl.setText('0개 상품');
        }
        else
        {
            res.forEach((obj) => {
                obj.exhibition_title    = this.m_get_data.exhibition_title;
                obj.exhibition_subtitle = this.m_get_data.exhibition_subtitle;
                obj.place_name          = this.m_get_data.place_name;
            })
            this.goods_cnt_lbl.setText(`${res.length}개 상품`);
            this.goods_list.addItem("Source/MarketPage/ProductAllListItem.lay", res);
        }
    }

    // TFUNCTION: SetAllCountAmt: 총 상품 개수, 가격(포인트) 셋팅 (ProductAllListItem에서 사용)
    SetAllCountAmt(cnt, amt)
    {
        if(cnt !== 0 && !cnt) cnt = 0;
        if(amt !== 0 && !amt) amt = 0;

        this.m_select_cnt += cnt;
        this.select_cnt_lbl.setText(`${ADataMask.Number.money.func(this.m_select_cnt)}개`);

        this.m_select_amt += amt;
        this.price_lbl.setText(`${ADataMask.Number.money.func(this.m_select_amt)}P`);
    }

    // TFUNCTION: Validation: 유효성 검사
    Validation()
    {
        if(this.m_select_goods.length === 0)
        {
            AToast.show('상품을 선택해주세요');
            return false;
        }
        else if(this.m_select_amt == 0)
        {
            AToast.show('상품을 1개 이상 선택해주세요');
            return false;
        }
        else return true;
    }

    // TFUNCTION: OnBuyBtnClick: 구매하기 버튼 클릭 이벤트
	OnBuyBtnClick()
	{
        this.m_select_goods = [];

        for(let i=0; i<this.goods_list.getItemCount(); i++) {
            let list_item = this.goods_list.getItem(i).view.SendSelectedItems();

            if(list_item) this.m_select_goods.push(list_item);
        }
        
        if(!this.m_is_show_all)
        {
            if(!this.Validation()) return;
            
            this.sel_goods_list.removeAllItems();
            this.sel_goods_list.addItem('Source/MarketPage/ProductItemPopupItem.lay', this.m_select_goods);

            this.SetBottomSheetStyle();
        }
        else
        {
            console.log('선택한 구매 굿즈 : ',this.m_select_goods);

            let send_data = this.m_select_goods.filter(obj => obj.select_count > 0 && obj.select_price > 0);
            if(send_data.length == 0) return AToast.show('상품을 1개 이상 선택해주세요');
            
            goPage('PayMain', send_data); // this.m_select_goods 데이터 가지고 결제 화면으로 이동
        }
	}

    // TFUNCTION: SetBottomSheetStyle: 바텀시트 스타일 셋팅
	SetBottomSheetStyle()
    {
        if(!this.m_is_show_all) //바텀시트 열기
        {
            this.scroll_top_view.show();
            this.sel_goods_list_view.show();

            this.bottom_back_view.setStyleObj({
                'height': '100%',
                'bottom': '0px',
                'background-color': 'rgba(0, 0, 0, 0.6)'
            });

            this.bottom_wrap_view.element.style.height = '450px';

            this.bottom_view.setStyleObj({
                'height' : '104px',
                'border-top': '1px solid rgb(244, 245, 247)',
            });

            this.bottom_flay.setStyleObj({
                'align-items': 'stretch',
                'flex-direction': 'column'
            });

            this.select_cnt_lbl.hide();
            this.select_cnt_title_lbl.setStyleObj({
                'color' : '#1F2129',
                'font-weight' : '600',
                'font-size' : '16px',
            });

            this.price_lbl.setStyleObj({
                'position': 'absolute',
                'right': '0'
            });

            this.m_is_show_all = true;
        }
        else //바텀시트 닫기
        {
            this.scroll_top_view.hide();
            this.sel_goods_list_view.hide();

            this.sel_goods_list.removeAllItems();

            this.bottom_back_view.setStyleObj({
                'height': '74px',
                'bottom': '0px',
                'background-color': 'transparent'
            });

            this.bottom_wrap_view.element.style.height = '74px';

            this.bottom_view.setStyleObj({
                'height' : '74px',
                'border-top': 'none',
            });

            this.bottom_flay.setStyleObj({
                'align-items': 'center',
                'flex-direction': 'row'
            });

            this.select_cnt_lbl.show();
            this.select_cnt_title_lbl.setStyleObj({
                'color' : '#616678',
                'font-weight' : '500',
                'font-size' : '11px',
            });

            this.price_lbl.setStyleObj({
                'position': 'relative',
                'right': '0'
            });

            this.m_is_show_all = false;
        }
    }

    // TFUNCTION: OnBottomBackViewClick: 바텀시트 배경 클릭 이벤트 (바텀시트 닫힘)
	OnBottomBackViewClick(comp, info, e)
	{
        if(this.m_is_show_all)
        {
            this.SetBottomSheetStyle();
        }
	}

    // TFUNCTION: OnScrollTopViewActiondown: 바텀시트 actiondown이벤트 (초기값 저장)
	OnScrollTopViewActiondown(comp, info, e)
	{
		this.m_startY = e.changedTouches[0].clientY;
        this.m_start_height = this.bottom_wrap_view.getHeight();
	}

    // TFUNCTION: OnScrollTopViewActionmove: 바텀시트 actionmove이벤트 (이동값에 따라 height값 달라짐)
    OnScrollTopViewActionmove(comp, info, e)
	{
		const moveY = e.changedTouches[0].clientY;
        const diff = moveY - this.m_startY;

        let height = this.m_start_height - diff;
        height = Math.max(104, Math.min(height, 450));

        this.bottom_wrap_view.setStyle('height', height+'px');
	}

    // TFUNCTION: OnScrollTopViewActionup: 바텀시트 actionup이벤트 (이동값에 따라 닫히거나 그대로거나)
	OnScrollTopViewActionup(comp, info, e)
	{
        if(e.changedTouches[0].clientY > this.m_startY + 70)
        {
            this.SetBottomSheetStyle();
        }
    };

    // TFUNCTION: OnBottomWrapViewClick: 바텀시트 몸통 클릭 이벤트(배경 클릭 이벤트 먹히지 않도록 대응한 함수임)
	OnBottomWrapViewClick(comp, info, e){}


}

