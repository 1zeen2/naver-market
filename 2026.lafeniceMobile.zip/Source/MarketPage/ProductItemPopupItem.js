
class ProductItemPopupItem extends AView
{
	constructor()
	{
		super()

        this.m_list_data = null;
        this.m_max = 0;             // 재고(최대 선택 개수)
        this.m_price = 0;           // 개당 가격
        this.m_count = 0;           // 선택한 개수
        this.m_select_amt = 0;      // 전체 금액
        this.m_goods_uid = null;    // 굿즈ID
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.m_list_data    = data;
        this.m_max          = Number(data.goods_stock);
        this.m_price        = Number(data.goods_price);
        this.m_count        = Number(data.select_count);
        this.m_select_amt   = Number(data.select_price);
        this.m_goods_uid    = data.goods_uid;

        this.name_lbl.setText(data.goods_title);
        this.subtext_lbl.setText(data.exhibition_subtitle + ' 굿즈');
        this.count_lbl.setText(ADataMask.Number.money.func(data.select_count));
        this.price_lbl.setText(ADataMask.Number.money.func(data.select_price) + 'P');
    }

    // TFUNCTION: OnPlusBtnClick: 갯수 +(플러스) 버튼 클릭 이벤트
	OnPlusBtnClick(comp, info, e)
	{
		if(this.m_count >= this.m_max)
        {
            this.m_count = this.m_max;
            this.m_select_amt = this.m_max * this.m_price;

            return AToast.show(`최대 선택 가능 개수는 ${this.m_max}개입니다`);
        }
        else
        {
            this.m_count++;
            this.m_select_amt += this.m_price;
        }

        const select_goods = this.getContainerView().m_select_goods;
        const goods = select_goods.find(obj => obj.goods_uid == this.m_goods_uid);
        if(goods)
        {
            goods.select_count = this.m_count;
            goods.select_price = this.m_select_amt;
        }
        
        this.count_lbl.setText(this.m_count);
        this.price_lbl.setText(ADataMask.Number.money.func(this.m_select_amt) + 'P');

        this.SetAnotherListView('plus');
	}

    // TFUNCTION: OnMinusBtnClick: 갯수 -(마이너스) 버튼 클릭 이벤트
	OnMinusBtnClick(comp, info, e)
	{
        if(this.m_count <= 0)
        {
            this.m_count = 0;
            this.m_select_amt = 0;
            return;
        }
        else
        {
            this.m_count--;
            this.m_select_amt -= this.m_price;
        }

        const select_goods = this.getContainerView().m_select_goods;
        const goods = select_goods.find(obj => obj.goods_uid == this.m_goods_uid);
        if(goods)
        {
            goods.select_count = this.m_count;
            goods.select_price = this.m_select_amt;
        }
        
        this.count_lbl.setText(this.m_count);
        this.price_lbl.setText(ADataMask.Number.money.func(this.m_select_amt) + 'P');

        this.SetAnotherListView('minus');
	}

    // TFUNCTION: OnDelBtnClick: 리스트아이템 삭제 버튼 클릭 이벤트
	OnDelBtnClick(comp, info, e)
	{
		//삭제하시겠습니까 팝업 생기면 콜백으로 넣어주면 됨-----------
        const select_goods = this.getContainerView().m_select_goods;
        this.getContainerView().m_select_goods = select_goods.filter((obj) => obj.goods_uid !== this.m_list_data.goods_uid);

        this.m_count = 0;
        this.m_select_amt = 0;

        this.SetAnotherListView('del');

        this.owner.removeItem(this.getItem());
	}

    // TFUNCTION: SetAnotherListView: 선택한 굿즈 개수 ProductAllListItem에도 셋팅해주기
	SetAnotherListView(state)
	{
		const all_items = this.getContainerView().goods_list.getItems();
        const item_list = Array.isArray(all_items) ? all_items : all_items.toArray()
        const item      = item_list.find(obj => obj.view.m_list_data.goods_uid == this.m_goods_uid);

        if(!item) return;

        if(state == 'plus')
        {
            //item.view.plus_btn.reportEvent('click');
            item.view.OnPlusBtnClick();
        }
        else if(state == 'minus')
        {
            //item.view.minus_btn.reportEvent('click');
            item.view.OnMinusBtnClick();
        }
        else if(state == 'del')
        {
            item.view.check_btn.setCheck(false);
            item.view.OnCheckCtnClick(item.view.check_btn);
        }
	}
}

