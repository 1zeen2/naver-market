
class OrderHistoryListItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    setData(data) {
        if (!data) return;

        this.order_history_item_img.setImage('Assets/junel-mujar-p-YhoHYOHvo-unsplash.jpg'); // 임시 이미지
        this.title_lbl.setText(data.exhibition_title);
        this.price_lbl.setText(data.price || '0원'); // 임시 데이터
        this.quantity_lbl.setText(data.qty || '일반 구매권 2매'); // 임시 데이터

        if (data.type === 'TICKET') {
            this.type_img.setImage('Assets/ticket-icon.png');
            this.type_lbl.setText('티켓');
        } else {
            this.type_img.setImage('Assets/md-icon.png');
            this.type_lbl.setText('굿즈')
        }

    }
}

