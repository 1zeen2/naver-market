
class ProductAllListItem extends AView
{
	constructor()
	{
		super()

        this.m_list_data = null;
        this.m_max = 0;     // 재고(최대 선택 개수)
        this.m_price = 0;   // (개당)가격
        this.m_count = 0;   // 선택한 개수
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.m_list_data = data;
        this.m_max = Number(data.goods_stock);
        this.m_price = Number(data.goods_price);

        if(this.m_max == 0)
        {
            this.check_btn.hide();
            this.soldout_view.show();
        }
        else
        {
            this.check_btn.show();
            this.soldout_view.hide();
        }
        
        this.goods_img.setImage(network.address.replace('/access', '') + data.thumbnail_path);
        this.name_lbl.setText(data.goods_title);
        this.plice_lbl.setText(ADataMask.Number.money.func(data.goods_price) + 'P');
    }

    // TFUNCTION: OnCheckCtnClick: 좌측 상단 체크버튼 클릭 이벤트
	OnCheckCtnClick(comp, info, e)
	{
        if(comp.isChecked)
        {
            this.count_view.show();
        }
        else
        {
            this.owner.getRootView().SetAllCountAmt(-this.m_count, -(this.m_price * this.m_count));
            
            this.m_count = 0;
            this.count_lbl.setText(0);
            this.count_view.hide();
        }
	}

    // TFUNCTION: OnPlusBtnClick: + 버튼 클릭 이벤트
	OnPlusBtnClick(comp, info, e)
	{
        if(this.m_count >= this.m_max)
        {
            this.m_count = this.m_max;
            
            return AToast.show(`최대 선택 가능 개수는 ${this.m_max}개입니다`);
        }
        else this.m_count++;
        
		this.count_lbl.setText(this.m_count);

        this.owner.getRootView().SetAllCountAmt(1, this.m_price);
	}

    // TFUNCTION: OnMinusBtnClick: - 버튼 클릭 이벤트
	OnMinusBtnClick(comp, info, e)
	{
        if(this.m_count <= 0)
        {
            this.m_count = 0;
            return;
        }
        else this.m_count--;

		this.count_lbl.setText(this.m_count);

        this.owner.getRootView().SetAllCountAmt(-1, -this.m_price);
	}

    // TFUNCTION: SendSelectedItems: 데이터를 내보낸다(기존 get_data & 선택한 개수, 가격 같이 내보내줌. ProductAllList에서 사용)
	SendSelectedItems(comp, info, e)
	{
        if(!this.check_btn.isChecked || this.m_count === 0) return false;
        
        let send_data = {
            ...this.m_list_data,
            select_count : this.m_count,
            select_price : (this.m_price * this.m_count)
        };

        return send_data
	}

    // TFUNCTION: OnWrapViewClick: 뷰 클릭 이벤트(상세 굿즈 화면 오픈)
	OnWrapViewClick(comp, info, e)
	{
		goPage('ProductGoods', this.m_list_data);
	}
}

