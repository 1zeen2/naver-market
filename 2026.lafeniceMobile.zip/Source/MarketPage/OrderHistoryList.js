 
class OrderHistoryList extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.order_history_list.itemWrapper[0].classList.add('order-group-divider');
	}

    /**
     *  TR 작성 되면 전부 수정 예정. (날짜의 시작 일자 포함.)
     */
    setData(data) {
        if (data.status === 'PR') {
            this.order_status_lbl.setText('구매 완료');
            this.order_status_lbl.addClass('text-pink-500');
            this.order_status_lbl.removeClass('text-metal-400');
        } else {
            this.order_status_lbl.setText('취소 완료');
            this.order_status_lbl.addClass('text-metal-400');
            this.order_status_lbl.removeClass('text-pink-500');
        }

        // TR 나오면 구매일자로 적용 (현재는 시작 일자)
        const target_date = data.start_date;

        if (target_date) {
            const formatted_date = target_date.replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})/, '$1.$2.$3 $4:$5');;
            this.order_time_lbl.setText(formatted_date);
        }

        if (this.order_history_list) {
            this.order_history_list.removeAllItems();
            this.order_history_list.addItem('Source/MarketPage/OrderHistoryListItem.lay', [data]);
        }
    }


	OpenDetail(comp, info, e)
	{

		//this._item.itemData

	}
}