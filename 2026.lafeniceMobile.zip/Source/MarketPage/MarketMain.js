
class MarketMain extends AView
{
	constructor()
	{
		super()

        this.select_type = '';
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone() {
        super.onInitDone();

        this.SetStyle();
    }

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
        this.OnChangeType(this.all_lbl);

        this.market_list.itemWrapper[0].classList.add('wrapper-align');
    }

    OnPointHistoryClick()
    {
        goPage('PointHistory');
    }

    SetStyle()
    {

        const stop_scroll = this.point_area_flay.getHeight();
        this.type_view.setStyleObj({
            top: stop_scroll
        });

        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }

    OnChangeType(comp, info, e)
	{
        
        if(this.select_type) {
            this.select_type.addClass('text-metal-400');    
            this.select_type.removeClass('text-pink-500');
        }
        
        this.select_type = comp;
        this.select_type.addClass('text-pink-500');
        this.select_type.removeClass('text-metal-400');

        const rect = comp.element.getBoundingClientRect();
        const bar = this.underbar_view;

        bar.setWidth(rect.width);
        bar.setStyleObj({
            transform: `translateX(${rect.x - 20}px)`
        })

        this.GetMarketList(false);

	}

    async GetMarketList(isFirst) {

        let status;

        if(this.select_type?.compId === 'all_lbl') status = '';
        else if(this.select_type?.compId === 'ticket_lbl') status = 'TICKET';
        else if(this.select_type?.compId === 'goods_lbl') status = 'GOODS';
        else {
            status = '';
            this.OnChangeType(this.all_lbl);
        }

        if(!isFirst) this.market_list.removeAllItems();

        await sendQuery('market', 'list', {status: status})
            .then(res => {
                
                let count = 0;

                if(res && res.length > 0) {
                    count = res.length;
                    this.market_list.addItem('Source/MarketPage/MainListItem.lay', res);
                }

                this.list_count_lbl.setText(`${count}개 상품`)
            });
    }
}