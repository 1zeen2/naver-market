
class MainListItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    setData(data) {
        this.data = data; 

        this.ProductSetData(data); 
    }

    
    FormatDate(yyyyMMdd) {
        if (!yyyyMMdd || yyyyMMdd.length !== 8) return yyyyMMdd;
        return yyyyMMdd.replace(/(\d{4})(\d{2})(\d{2})/, '$1.$2.$3');
    }

    // PR: 진행 중, WT: 대기, ED: 종료
    Status(status) {
        if (status === 'PR') {
            this.status_lbl.setText('진행중');
            this.status_lbl.addClass('status-ongoing');
        } else if (status === 'WT') {
            this.status_lbl.setText('진행 예정');
            this.status_lbl.addClass('status-upcoming');
        } else if (status === 'ED') {
            this.status_lbl.setText('마감');
            this.status_lbl.addClass('status-ended');
        } else {
            console.log('status 값을 확인해야 함 (안내려오는건지, 못받은건지 등)');
        }
    }

    ProductSetData(data) {
        if (!data) return;

         // 굿즈 티켓 모두 중복되는 값
        this.thumb_img.setImage(data.thumbnail_path ? `${network.address.replace('/access', '')}${data.thumbnail_path}` : 'Assets/junel-mujar-p-YhoHYOHvo-unsplash.jpg');
        this.title_lbl.setText(data.exhibition_title);
        this.venue_lbl.setText(data.place_name);

        if (data.type === 'TICKET') {
            this.type_img.setImage('Assets/ticket-icon.png');
            this.type_lbl.setText('티켓');
            this.status_lbl.show();
            this.Status(data.status);
        } else if (data.type === 'GOODS') {
            this.type_img.setImage('Assets/md-icon.png');
            this.type_lbl.setText('굿즈');
            this.status_lbl.hide();
        }

        const { start_date, end_date } = data;

        if (start_date && end_date) {
            const formatted_peroid = `${this.FormatDate(start_date)} ~ ${this.FormatDate(end_date)}`;
            this.period_lbl.setText(formatted_peroid);
        }
        
    }

}

