
class ProductGoods extends AView
{
	constructor()
	{
		super()

        this.m_data = null;         // 조회한 데이터
        this.m_get_Data = null;     // 받은 데이터
        this.m_goods_uid = null;    // 굿즈ID
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

    onActive(isFirst)
	{
		super.onActive(isFirst)

        this.m_get_Data = this.getContainer().getData();
        this.m_goods_uid = this.getContainer().getData().goods_uid;

        this.GetGoodsData();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        /*this.m_get_Data = this.getContainer().getData();
        this.m_goods_uid = this.getContainer().getData().goods_uid;

        this.GetGoodsData();*/
	}
    
	// TFUNCTION: PrevBtn: 뒤로가기 버튼
	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}

    // TFUNCTION: GetGoodsData: 굿즈 상세정보 데이터를 조회한다.
    async GetGoodsData()
    {
        const res = await sendQuery('market', 'goodsDetail', { goods_uid : this.m_goods_uid });

        console.log(res);

        if(res.error || res.length === 0)
        {
            AToast.show('조회에 실패했습니다');
            return;
        }
        else
        {
            this.m_data = res;

            this.goods_img.setImage(network.address.replace('/access', '') + res.thumbnail_path);
            this.name_lbl.setText(res.goods_title);
            this.subtext_lbl.setText(res.goods_subtitle);
            this.price_lbl.setText(ADataMask.Number.money.func(res.goods_price) + 'P');
            this.category_lbl.setText(res.category_code || '-');
            this.material_lbl.setText('-');
            this.size_lbl.setText('-');
            this.weight_lbl.setText('-');
            this.manufacturer_lbl.setText('-');
            this.infotext_txb.setText(res.goods_description);
            this.info_img_img.setImage(network.address.replace('/access', '') + res.goods_detail_path);
        }
    }


}

