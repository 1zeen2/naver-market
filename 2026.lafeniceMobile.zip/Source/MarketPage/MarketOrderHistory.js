
class MarketOrderHistory extends AView
{
	constructor()
	{
		super()
    
        this.m_selected_type = '';
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        this.OnChangeType(this.all_lbl);

        this.order_list.itemWrapper[0].classList.add('wrapper-align-vertical');
        this.content_view.element.parentElement.classList.add('min-height-0');
	}

	OnChangeType(comp, info, e)
	{
        if (this.m_selected_type) {
            this.m_selected_type.addClass('text-metal-400');
            this.m_selected_type.removeClass('text-pink-500');
        }

        this.m_selected_type = comp;
        this.m_selected_type.addClass('text-pink-500');
        this.m_selected_type.removeClass('text-metal-400');
		
        const rect = comp.element.getBoundingClientRect();
        const underbar = this.underbar_view;

        underbar.setWidth(rect.width);
        underbar.setStyleObj({
            transform: `translateX(${rect.x - 20}px)`
        })

        this.GetOrderList();
    }

    async GetOrderList() {
        let status = '';

        if (this.m_selected_type === this.ticket_lbl) status = 'TICKET';
        else if (this.m_selected_type === this.goods_lbl) status = 'GOODS';

        this.order_list.removeAllItems();

        const res = await sendQuery('market', 'list', { status })
            
        if (res && res.length > 0) {
            this.order_list.addItem('Source/MarketPage/OrderHistoryList.lay', res);
        }
    }
    

	PrevBtn(comp, info, e)
	{

		goPrevPage();

	}
}