
class CustomerSupport extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.content_view.element.style.setProperty('padding-bottom', '64px', 'important');

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    async SendData()
    {
        const code = this.code_txf.getText();
		const title = this.title_txf.getText();
		const content = this.content_txf.getText();
		const email = this.email_txf.getText();

		if (!code || !title || !content || !email) {
			AToast.show('모든 항목을 입력해주세요');
			return;
		}

		if (!this.CheckEmail(email)) {
			AToast.show('올바른 이메일 형식이 아닙니다');
			return;
		}

        const supcode = Object.values(theApp._bsnsCode.supportCode).find(supportcode => supportcode.label === this.code_txf.getText());

        const inblock = {
            support_code: supcode.code,
            support_title: this.title_txf.getText(),
            support_content: this.content_txf.getText(),
            reply_email: this.email_txf.getText()
        };

        const reData = await sendQuery('board', 'supportReqeust', inblock);

        if (reData.success === true) {
            console.log(reData);

            this.code_txf.setText('');
            this.title_txf.setText('');
            this.content_txf.setText('');
            this.email_txf.setText('');
        }
    }

    CheckEmail(email)
	{
		const valiEmail = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

		return valiEmail.test(email);
	}

	FAQBtnClick(comp, info, e)
	{
        goPage('FAQ');
	}

	PrevBtn(comp, info, e)
	{
        goPrevPage();
	}
    
}

