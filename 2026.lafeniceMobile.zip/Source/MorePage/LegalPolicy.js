
class LegalPolicy extends AView
{
	constructor()
	{
		super()

		this.m_active = false;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here
        this.ResponseData();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    /**
     *  마케팅 정보 수신 버튼 (class 토글 방식)
     */
	ToggleBtn(comp, info, e)
	{
        this.m_active = !this.m_active;

        const { element } = comp;
        const iconEl = this.toggle_icon_view;

        if (this.m_active === true) {
            element.classList.replace('bg-metal-100', 'bg-pink-500');
            iconEl.setStyleObj({ 'transition': 'transform 0.15s linear', 'transform': 'translateX(20px)' })
        } else {
            element.classList.replace('bg-pink-500', 'bg-metal-100');
            iconEl.setStyleObj({ 'transition': 'transform 0.15s linear', 'transform': 'translateX(0px)' })
        }
	}

    /**
     *  
     */
    ResponseData() {
        const response_data = theApp._terms;

        if (!response_data) return;

        const set_text = (title, date, key) => {
            const data = response_data.find(term => term.terms_title.includes(key));
            
            title.setText(data.terms_title);
            date.setText(`최종 업데이트 : ${this.FormattedDate(data.updated_at)}`);
        };

        set_text(this.service_title_lbl, this.service_updated_at_lbl, '서비스');
        set_text(this.privacy_update_lbl, this.privacy_updated_at_lbl, '개인정보');
        set_text(this.marketing_title_lbl, this.marketing_updated_at_lbl, '마케팅');
    }

    /**
     *  yyyy-MM-dd hh:mm 형식을
     *  yyyy.MM.dd로 변환.
     */
    FormattedDate(data) {
        const year = data.substring(0, 4);
        const month = data.substring(5, 7);
        const date = data.substring(8, 10);

        return `${year}.${month}.${date}`;
    }

    /**
     *  동의 내역에 대한 데이터 출력
     */
    async AgreementRecords() {
        await sendQuery('user', 'term', {}) 

            .then(res => {
                console.log(res.user.terms);
            })
    }

    // 마케팅 정보 수신 페이지로 이동
	GoMarketingConsent(comp, info, e)
	{
        goPage(comp.compId);
	}

    // 이전 화면으로 이동
	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}


