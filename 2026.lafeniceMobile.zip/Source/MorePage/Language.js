
class Language extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		const languageList = [
            {list: '한국어', selected: true},
            /* {list: '영어', selected: false},
            {list: '일본어', selected: false},
            {list: '중국어', selected: false} */
        ];

        this.language_list.addItem('Source/MorePage/LanguageItem.lay', languageList);

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

	PrevBtn(comp, info, e)
	{
        goPrevPage();
	}
    
}

