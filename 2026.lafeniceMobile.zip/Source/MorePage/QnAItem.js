
class QnAItem extends AView
{
	constructor()
	{
		super()

		this.transview = false;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.content_view.setStyleObj({ 'transition': 'max-height 0.3s ease-in-out, opacity 0.3s ease-in-out' });

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetData(this.getItemData());

        const ownerView =  this.owner;
        const item = ownerView.getItems();

        const firstList = $(item[0]).children('div').children('div').children('div')[0];

        if (firstList) {
            firstList.style.paddingTop = '0px';
        }
	}

    // 데이터 맵핑
    SetData(data)
    {
        console.log(data);

        const textcode = Object.values(theApp._bsnsCode.faqCode).find(faqcode => faqcode.code === data.faq_code);
        this.state_lbl.setText(textcode.label);                     // QnA 타입

        this.title_lbl.setText(data.question);                      // QnA 질문
        this.content_lbl.setText(data.answer);                      // QnA 답변
    }

	DownClick(comp, info, e)
	{
        if (!this.transview) {
			this.chevron_icon.addClass('transform-180');

			this.content_view.setStyleObj({
				'max-height': 'none',
				'opacity': '1'
			});

			const scrollHeight = this.content_view.element.scrollHeight;

			this.content_view.setStyleObj({
				'max-height': '0px',
				'opacity': '0'
			});

            setTimeout(() => {
                this.content_view.setStyleObj({
                    'max-height': scrollHeight + 'px',
                    'opacity': '1'
                });
            })

			this.transview = true;
            this.row.hide();

		} else {
			this.chevron_icon.removeClass('transform-180');
            this.row.show();

			const currentHeight = this.content_view.element.scrollHeight;
            this.content_view.setStyleObj({
                'max-height': currentHeight + 'px'
            });

            setTimeout(() => {
                this.content_view.setStyleObj({
                    'max-height': '0px',
                    'opacity': '0'
                });
            }, 10);

			this.transview = false;
		}
	}
}

