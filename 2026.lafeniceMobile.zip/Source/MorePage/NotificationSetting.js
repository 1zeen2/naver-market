class NotificationSetting extends AView
{
	constructor()
	{
		super()
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

		this.GetNotiValue();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    GetNotiValue()
    {
        sendQuery('user', 'alarms', {})
            .then( res => {
                this.noti_value = res.notice_agree;
                this.SetNotiAll(this.noti_toggle_btn, null, null);  
            })
    }

	SetNotiAll(comp, info, e)
	{
        if (this.noti_value === undefined) this.noti_value = 'N';
        
		if(e) 
        {
            this.noti_value = (this.noti_value === 'Y' ? 'N' : 'Y');
            sendQuery('user', 'alarmUpd', { notice_agree: this.noti_value });

            if(this.noti_value === 'Y') AToast.show('전체 푸시 알림을 받습니다.');
            else AToast.show('전체 푸시 알림을 받지 않습니다.');
        }

		const circle = comp.getChildren()[0];
        if (this.noti_value === 'Y') {
            circle.element.style.transform = 'translateX(20px)';
            comp.addClass('bg-pink-500');
            comp.removeClass('bg-metal-100');
        } else {
            circle.element.style.transform = 'translateX(0px)';
            comp.removeClass('bg-pink-500');
            comp.addClass('bg-metal-100');
        }
	}

    PrevBtn(comp, info, e)
    {
        goPrevPage();
    }
}