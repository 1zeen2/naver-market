
class PointHistory extends AView
{
	constructor()
	{
		super()

		this.scroll_pending = true;
        this.timeout = '';
        this.is_move = 0;
        this.last_list = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here
        this.SetStyle();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        this.GetListData();
	}

    SetStyle()
    {
        
        const bar_width = this.point_detail.getWidth();

        this.underbar_view.setStyleObj({
            width: `${bar_width}px`
        });
    }

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}

    async GetListData(isFirst)
    {

        if(isFirst){

        }

        const inblock = {
            start_date: '20260101',
            end_date: '20260204',
            next_key: '',
        };

        const result = await sendQuery('user', 'pointList', inblock);
        this.current_point.setText(`${ADataMask.Number.money.func(result.expiring_point)}P`);
        this.detail_list.addItem('Source/MorePage/PointHistoryDate.lay', [...result.list, ...result.list])
            .then( res => {
                if(this.last_list) {
                    this.last_list.children[0].style.borderBottomWidth = 8; 
                }  

                this.last_list = res[res.length - 1];
                this.last_list.children[0].style.borderBottomWidth = 0; 
            
            });
    }

	ScrollContentView(comp, info, e)
	{
        const left = e.target.scrollLeft / 2;
        const min_left = 0;
        const max_left = this.content_cntr.getWidth() / 2;
        const is_can = left === min_left || left === max_left;

        if(this.timeout) {
            clearTimeout(this.timeout);
            this.timeout = null;
        }

        this.timeout = setTimeout(() => {
            if(!is_can || left === this.is_move) return;

            if(left === min_left) {
                this.point_expiry.removeClass('text-pink-500');
                this.point_detail.removeClass('text-metal-400');
                this.point_expiry.addClass('text-metal-400');
                this.point_detail.addClass('text-pink-500');
            } else if(left === max_left) {
                this.point_detail.removeClass('text-pink-500');
                this.point_expiry.removeClass('text-metal-400');
                this.point_detail.addClass('text-metal-400');
                this.point_expiry.addClass('text-pink-500');
            } else {
                //
            }
            
            this.is_move = left;
        }, 50);
        
        this.underbar_view.setStyleObj({
            transform: `translateX(${left}px)`
        });


        if(!this.scroll_pending) {
            //스크롤 종료 후 동작 로직
        }

	}

	OnChangeType(comp, info, e)
	{
        const rect = comp.element.getBoundingClientRect();
		const type = comp.compId === 'point_detail' ? '1' : '2';
        let left;

        switch(type){
            case '1':
                left = rect.width;
                break;
            case '2':
                left = rect.width * 2;
                break;
            default:
                break;    
        }

        console.log(rect);

        this.content_cntr.element.scrollTo({
            left: left,
            behavior: 'smooth'
        });
	}


	onAView2Click(comp, info, e)
	{
         
        this.getContainer().element.style.overflow = 'hidden' //
    
        const this_obj = this;
		openBottomSheet(this, {
            title: '필터',
            path: 'Source/BottomSheet/PointHistorySheet.lay',
            data: this.m_selectDate,
            onSelect: async (data) => {
                this_obj.getContainer().element.style.overflow = 'auto' //
            },

            onCancel: () => {
                
            }
        });
	}

	CntrScroll(comp, info, e)
	{

		console.log(e);

	}
}

