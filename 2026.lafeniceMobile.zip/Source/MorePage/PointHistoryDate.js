
class PointHistoryDate extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.SetListItems();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    SetListItems()
    {
        this.history_list.addItem('Source/MorePage/PointHistoryItem.lay', [1, 2]);
    }

}

