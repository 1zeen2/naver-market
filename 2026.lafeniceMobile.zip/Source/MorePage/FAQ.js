
class FAQ extends AView
{
	constructor()
	{
		super()

		this.selectedType = null;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.CreateLabel();
        this.SetList();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    CreateLabel()
    {
        const bizfaq = Object.values(theApp._bsnsCode.faqCode);

        bizfaq.forEach((faqLabel, index) => {
            const lbl = new ALabel();
            lbl.init();
            lbl.setText(faqLabel.label);

            if (index === 0) {
                lbl.addClass('font-size-13 radius-100 selectStyle');
                this.selectedType = faqLabel;
            } else {
                lbl.addClass('font-size-13 radius-100 defaultStyle');
            }

            lbl.setStyleObj({
                'position': 'relative',
                'width': 'auto',
                'height': 'auto',
                'display': 'inline-block',
                'line-height': '15px',
                'border-width': '1px',
                'border-style': 'solid',
                'margin-right': '8px',
                'padding': '5px 8px'
            });

            this.state_view.addComponent(lbl);

            lbl.addEventListener('click', this, 'StateBtnClick');
        });
    }

    StateBtnClick(comp, info, e)
    {
        const lblText = comp.getText();

        const faqCode = Object.values(theApp._bsnsCode.faqCode).find(faqlbl => faqlbl.label === lblText);

        if (this.selectedType === faqCode) {
            return;
        }

        const stateLabel = this.state_view.getChildren();

        stateLabel.forEach(btn => {
            btn.removeClass('selectStyle');
            btn.addClass('defaultStyle');
        })

        comp.removeClass('defaultStyle');
        comp.addClass('selectStyle');

        this.selectedType = faqCode;

        this.SetList(faqCode);
    }

    async SetList(data)
    {
        this.faq_list.removeAllItems();

        let code = 'AA';

        if (data) {
            code = data.code;
        }

        const inblock = {
            faq_code: code,
            keyword: this.search_txf.getText() || null
        };

        const reData = await sendQuery('board', 'faqList', inblock);

        if (reData) {
            console.log(reData);

            const sortData = reData.sort((a, b) => a.sort_order - b.sort_order);

            this.faq_list.addItem('Source/MorePage/QnAItem.lay', sortData);
        }
    }

	SearchKeydown(comp, info, e)
	{
        if (e.keyCode === 13 && comp.getText()) {
            this.SetList();
        }
	}

	SupportBtnClick(comp, info, e)
	{
        goPage('CustomerSupport');
	}

	PrevBtn(comp, info, e)
	{
        goPrevPage();
	}
    
}

