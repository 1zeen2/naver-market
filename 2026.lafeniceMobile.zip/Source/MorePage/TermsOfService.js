
class TermsOfService extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		const service = Object.values(theApp._terms).find(term => term.terms_title === '서비스 이용약관');

        this.title_lbl.setText(service.terms_title);
        this.date_lbl.setText(this.FormatDate(service.updated_at));
        this.content_lbl.setText(service.terms_contents);
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    FormatDate(date)
    {
        const year = date.substring(0, 4);
        const month = date.substring(5, 7);
        const day = date.substring(8, 11);

        return `${year}.${month}.${day}`;
    }

	PrevBtn(comp, info, e)
	{
        goPrevPage();
	}
    
}

