
class NoticeItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.row.hide();
        this.thickRow.hide();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetData(this.getItemData());

	}

    // 데이터 맵핑
    SetData(data)
    {
        console.log(data);

        const date = new Date();
        const today = this.FormatDateFull(date);

        if (data.notice_date) {
            if (data.notice_date === today) {
                this.CreateToday();                                     // 오늘 text show
            }

            this.CreateDate(data.notice_date);                          // 공지 날짜

            if (this.InWeek(data.notice_date, today)) {
                this.CreateNew();
            }

            this.thickRow.show();
            this.row.hide();

        } else {
            this.thickRow.hide();
            this.row.show();

        }

        const typeText = Object.values(theApp._bsnsCode.notice.type).find(typecode => typecode.code === data.notice_type);
        this.state_lbl.setText(typeText.label);                         // 공지 타입

        this.title_lbl.setText(data.notice_title);                      // 공지 제목
        this.subTitle_lbl.setText(data.notice_content);                 // 공지 내용

        if (data.index === data.totalCount - 1) {
            this.main_view.setStyleObj({'margin-bottom': '0px'});
            this.thickRow.hide();
            this.row.hide();
        }
    }

    CreateNew()
    {
        const lbl = new ALabel();
        lbl.init();
        lbl.setText('NEW');
        lbl.addClass('font-size-10 text-metal-50 font-weight-semibold radius-100 bg-pink-500');
        lbl.setStyleObj({
            'position': 'relative',
            'width': 'auto',
            'height': 'auto',
            'display': 'inline-block',
            'border-width': '1px',
            'border-style': 'solid',
            'padding': '4px 8px'
        });

        this.statelbl_view.addComponent(lbl);
    }

    CreateToday()
    {
        const lbl = new ALabel();
        lbl.init();
        lbl.setText('오늘');
        lbl.addClass('font-size-13 text-metal-800 font-weight-medium');
        lbl.setStyleObj({
            'position': 'relative',
            'width': 'auto',
            'height': '100%',
            'display': 'inline-block',
            'margin-right': '4px'
        });

        const view = new AView();
        view.init();
        view.addClass('bg-metal-800');
        view.setStyleObj({
            'position': 'relative',
            'width': '2px',
            'height': '2px',
            'display': 'inline-block',
            'border-radius': '50%',
            'margin-right': '4px'
        });

        this.datelbl_view.addComponent(lbl);
        this.datelbl_view.addComponent(view);
    }

    CreateDate(date)
    {
        const lbl = new ALabel();
        lbl.init();
        lbl.setText(this.FormatDate(date));
        lbl.addClass('font-size-13 text-metal-800 font-weight-medium');
        lbl.setStyleObj({
            'position': 'relative',
            'width': 'auto',
            'height': '100%',
            'display': 'inline-block'
        });

        this.datelbl_view.addComponent(lbl);
    }

    InWeek(noticeDate, todayStr)
    {
        const notice = new Date(
            noticeDate.substring(0, 4),
            noticeDate.substring(4, 6) - 1,
            noticeDate.substring(6, 8)
        );
        
        const today = new Date(
            todayStr.substring(0, 4),
            todayStr.substring(4, 6) - 1,
            todayStr.substring(6, 8)
        );

        const diffTime = today - notice;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        return diffDays >= 0 && diffDays <= 7;
    }

    FormatDate(date)
    {
        const year = date.substring(2, 4);
        const month = date.substring(4, 6);
        const day = date.substring(6, 8);

        return `${year}.${month}.${day}`;
    }

    FormatDateFull(date)
    {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        
        return `${year}${month}${day}`;
    }

}

