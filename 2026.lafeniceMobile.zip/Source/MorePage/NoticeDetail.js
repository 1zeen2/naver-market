
class NoticeDetail extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		const infoData = this.getContainer().getData();

        this.SetData(infoData);
	}

    async SetData(data)
    {
        const inblock = {
            notice_uid: data.notice_uid
        };

        const reData = await sendQuery('board', 'noticeDetail', inblock);

        if (reData) {
            console.log(reData);

            const noticeCode = reData.notice_type;
            const noticeType = Object.values(theApp._bsnsCode.notice.type).find(typeCode => typeCode.code === noticeCode);

            this.state_lbl.setText(noticeType.label);
            this.title_lbl.setText(reData.notice_title);
            this.date_lbl.setText(this.FormatDate(reData.notice_date));
            this.content_tbx.setText(reData.notice_content);
        }
    }

    FormatDate(date)
    {
        const year = date.substring(0, 4);
        const month = date.substring(4, 6);
        const day = date.substring(6, 8);

        return `${year}.${month}.${day}`;
    }

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}

