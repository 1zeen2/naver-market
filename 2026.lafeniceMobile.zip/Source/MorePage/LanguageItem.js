
class LanguageItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetData(this.getItemData());

	}

    SetData(data)
    {
        this.language_lbl.setText(data.list);

        const selectCheck = this.element.querySelector('[id$="check_view"]');
        if (selectCheck) {
            if (data.selected) {
                selectCheck.classList.remove('check-default_Icon');
                selectCheck.classList.add('check-active_Icon');
            } else {
                selectCheck.classList.remove('check-active_Icon');
                selectCheck.classList.add('check-default_Icon');
            }
        }
    }

	RowClick(comp, info, e)
	{
        const listView = this.element.closest('[data-base="AListView"]');
    
        if (listView) {
            const checkView = listView.querySelectorAll('[id$="check_view"]');
            
            checkView.forEach(icon => {
                icon.classList.remove('check-active_Icon');
                icon.classList.add('check-default_Icon');
            });
        }
        
        const selectView = this.element.querySelector('[id$="check_view"]');
        if (selectView) {
            selectView.classList.remove('check-default_Icon');
            selectView.classList.add('check-active_Icon');
        }
	}

}

