
class EventListItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    setData(data)
    {
        this.thumb_img.setImage( data.thumbnail_path ? `${network.address.replace('/access', '')}${data.thumbnail_path}` : '');
        this.title_lbl.setText(data.promotion_title || '');
        this.content_lbl.setText(data.promotion_content || '');
    }

}

