
class UserInfo extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.SetUserInfo();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    async SetUserInfo()
    {
        const reData = await sendQuery('user', 'get', );

        if (reData) {
            console.log(reData);

            this.name_lbl.setText(reData.name);
            this.tel_lbl.setText(this.FormatPhone(reData.phone));
            this.email_lbl.setText(reData.email);
        }
    }

    FormatPhone(tel)
    {
        const fir = tel.substring(0, 3);
        const sec = tel.substring(3, 7);
        const thr = tel.substring(7, 11);

        return `${fir}-${sec}-${thr}`;
    }

	PrevBtn(comp, info, e)
	{
        goPrevPage();
	}
    
}

