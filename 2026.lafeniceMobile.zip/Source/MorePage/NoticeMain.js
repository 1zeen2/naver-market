
class NoticeMain extends AView
{
	constructor()
	{
		super()

		this.selectedType = null;
        this.cursor = null;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.CreateLabel();
		this.SetData();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    onDeactiveDone()
    {
        super.onDeactiveDone()

        this.selectedType = null;
        this.cursor = null;

        const stateLabel = this.state_view.getChildren();
        stateLabel.forEach(btn => {
            btn.removeClass('selectStyle');
            btn.addClass('defaultStyle');
        });

        stateLabel[0].removeClass('defaultStyle');
        stateLabel[0].addClass('selectStyle');
    }

    CreateLabel()
    {
        const bizNotice = Object.values(theApp._bsnsCode.notice.type);

        bizNotice.forEach((noticeType) => {
            const lbl = new ALabel();
            lbl.init();
            lbl.setText(noticeType.label);
            lbl.addClass('font-size-13 radius-100 defaultStyle');
            lbl.setStyleObj({
                'position': 'relative',
                'width': 'auto',
                'height': 'auto',
                'display': 'inline-block',
                'line-height': '15px',
                'border-width': '1px',
                'border-style': 'solid',
                'margin-right': '8px',
                'padding': '5px 8px'
            });

            this.state_view.addComponent(lbl);

            lbl.addEventListener('click', this, 'StateBtnClick');
        });
    }

    StateBtnClick(comp, info, e)
    {
        const typeText = comp.getText();

        let noticeType = null;
        if (typeText !== '전체') {
            noticeType = Object.values(theApp._bsnsCode.notice.type).find(typelbl => typelbl.label === typeText);
        }

        if (this.selectedType === noticeType) {
            return;
        }

        const stateLabel = this.state_view.getChildren();

        stateLabel.forEach(btn => {
            btn.removeClass('selectStyle');
            btn.addClass('defaultStyle');
        })

        comp.removeClass('defaultStyle');
        comp.addClass('selectStyle');

        this.selectedType = noticeType;

        this.cursor = null;

        this.notice_list.removeAllItems();

        this.SetData(noticeType);
    }

    async SetData(data)
    {
        let type = null;

        if (data) {
            type = data.code;
        }

        const inblock = {
            notice_type: type,
            cursor: this.cursor
        };

        const reData = await sendQuery('board', 'notice', inblock);

        if (reData) {
            console.log(reData);

            this.cursor = reData.cursor;

            const sortList = reData.list.sort((a, b) => {
                return b.notice_date.localeCompare(a.notice_date);
            });

            sortList.forEach((item, index) => {
                if (index > 0 && sortList[index - 1].notice_date === item.notice_date) {
                    item.notice_date = '';
                }

                item.index = index;
                item.totalCount = sortList.length;
            });

            this.notice_list.addItem('Source/MorePage/NoticeItem.lay', sortList);
        }
    }

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}

	SelectNotice(comp, info, e)
	{
        goPage('NoticeDetail', info.view.getItemData());
	}

}

