
class Event extends AView
{
	constructor()
	{
		super()

		this.scroll_pending = true;
        this.timeout = '';
        this.is_move = 0;
        this.last_list = {
            ing: '',
            hisotry: '',
        } 
        this.cursor = {
            ing: null,
            history: null,
            is_ing: false,
            is_history: false
        };
        this.tab_type = '1';
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.SetStyle();

        Promise.all([
            this.GetEventList(),
            this.GetHistoryList(),
        ])
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    SetStyle()
    {
        const bar_width = this.ing_btn.getWidth();
        const content_veiw = this.content_view.getHeight();
        const tab_height = this.tab_cntr_view.getHeight();

        this.content_cntr.setStyleObj({
            height: `${content_veiw - tab_height}px`
        });
        this.underbar_view.setStyleObj({
            width: `${bar_width}px`
        });
    }

    ScrollContentView(comp, info, e)
	{
        const left = e.target.scrollLeft / 2;
        const min_left = 0;
        const max_left = this.content_cntr.getWidth() / 2;
        const is_can = left === min_left || left === max_left;

        if(this.timeout) {
            clearTimeout(this.timeout);
            this.timeout = null;
        }

        this.timeout = setTimeout(() => {
            if(!is_can || left === this.is_move) return;
            this.is_move = left;
        }, 50);
        
        if(left > max_left / 2) {
            this.ing_btn.removeClass('text-pink-500');
            this.history_btn.removeClass('text-metal-400');
            this.ing_btn.addClass('text-metal-400');
            this.history_btn.addClass('text-pink-500');
        } else {
            this.history_btn.removeClass('text-pink-500');
            this.ing_btn.removeClass('text-metal-400');
            this.history_btn.addClass('text-metal-400');
            this.ing_btn.addClass('text-pink-500');
        }

        this.underbar_view.setStyleObj({
            transform: `translateX(${left}px)`
        });

        if(!this.scroll_pending) {
            //스크롤 종료 후 동작 로직
        }

	}

	OnChangeType(comp, info, e)
	{
        let left;
        const rect = comp.element.getBoundingClientRect();
		const type = comp.compId === 'ing_btn' ? '1' : '2';
        this.tab_type = type;

        switch(type){
            case '1':
                left = rect.width;
                break;
            case '2':
                left = rect.width * 2;
                break;
            default:
                break;    
        }

        this.content_cntr.element.scrollTo({
            left: left,
            behavior: 'smooth'
        });
	}

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}

    async GetEventList(comp, info ,e)
    {
        const inblock = {
            cursor: this.cursor.ing
        };

        if(this.cursor.is_ing && !this.cursor.ing) return;

        await sendQuery('promotion', 'list', inblock)
            .then( res => {
                
                if(!res || !res.list) return;

                this.event_list.addItem('Source/MorePage/EventListItem.lay', res.list)
                    .then( res => {
                        if(res.length === 0) return;
                        if(this.last_list.ing) {
                            this.last_list.ing.children[0].style.borderBottomWidth = 1; 
                        }  
                        this.last_list.ing = res[res.length - 1];
                        this.cursor.ing = res[res.length - 1].cursor;
                        this.last_list.ing.children[0].style.borderBottomWidth = 0; 
                    })
                if(!this.cursor.is_ing) this.cursor.is_ing = !this.cursor.is_ing;
            });
    }

    async GetHistoryList()
    {

        if(this.cursor.is_history && !this.cursor.history) return;

        const inblock = {
            cursor: this.cursor.history
        };

        await sendQuery('promotion', 'history', inblock)
            .then( res => {

                if(!res || !res.list) return;

                this.history_list.addItem('Source/MorePage/EventResultItem.lay', [...res.list, ...res.list, ...res.list, ...res.list])
                    .then( res => {
                        if(res.length === 0) return;
                        if(this.last_list.history) {
                            this.last_list.history.children[0].style.borderBottomWidth = 1; 
                        }  
                        this.last_list.history = res[res.length - 1];
                        this.cursor.history = res[res.length - 1].cursor;
                        this.last_list.history.children[0].style.borderBottomWidth = 0; 
                    })

                if(!this.cursor.is_history) this.cursor.is_history = !this.cursor.is_history;
            });
    }

	onAView1Scroll(comp, info, e)
	{

		console.log(e);

	}
}

