class MoreMain extends AView
{
	constructor()
	{
		super()

		this.user_referral_code = '';
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.SetUserInfo();

        const referred_code = theApp.auth_session.user.referred_code || '';

        if(referred_code) {
            this.referral_fld.setReadOnly(true);
            this.referral_fld.setText(referred_code);
            this.referral_btn.setAttr('disabled', true);
            this.referral_btn.setText('추천인 코드 등록완료');
            
            //

            this.referral_btn.removeClass('bg-pink-25');
            this.referral_btn.removeClass('text-pink-500');
            this.referral_btn.addClass('bg-metal-50');
            this.referral_btn.addClass('text-metal-400');
        }

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    //TFUNCTION: OnChangeReferralCode: 추천인 코드 입력
	OnChangeReferralCode(comp, info, e)
	{
		this.user_referral_code = e.target.value;
	}

    // TFUNCTION: RegisterReferral: 추천인 등록
    async RegisterReferral()
    {
        const referralCode = this.user_referral_code;
        
        if (!referralCode) {
            new AToast().show('추천인 코드를 입력해주세요.');
            return;
        }

        const inblock = {
            referral_code: referralCode
        };

        try {
            const res = await sendQuery('user', 'referral', inblock);

            if (res.error) {
                new AToast().show(res.error.message || '추천인 등록에 실패했습니다.');
            } else {
                new AToast().show('추천인이 성공적으로 등록되었습니다.');
                // Optionally refresh user info or UI if needed
                this.SetUserInfo();
            }
        } catch(err) {
            
        }
    }

    //TFUNCTION: SetClipboard: 나의 추천인 코드 복사하기
	SetClipboard(comp, info, e)
	{

        const user_info = theApp?.auth_session?.user;
		const executeCopy = (text) => {
        // 1. 최신 보안 환경(HTTPS)에서의 동작
            if (navigator.clipboard && window.isSecureContext) {
                return navigator.clipboard.writeText(text);
            } 

            // 2. 비보안(HTTP) 또는 구형 모바일 환경에서의 동작
            return new Promise((resolve, reject) => {
                const textArea = document.createElement("textarea");
                textArea.value = text;

                // 화면 왜곡을 방지하기 위한 최소한의 기능적 설정
                textArea.style.position = "absolute";
                textArea.style.left = "-9999px";
                textArea.style.top = "0";
                
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();

                try {
                    const successful = document.execCommand('copy');
                    successful ? resolve() : reject();
                } catch (err) {
                    reject(err);
                } finally {
                    document.body.removeChild(textArea);
                }
            });
        };


        const targetText = user_info?.referral_code || '';
        executeCopy(targetText)
            .then(() => {
                // 성공 시 처리 로직
                new AToast().show('복사 완료');
            })
            .catch(() => {
                // 실패 시 처리 로직
                console.error('복사 기능 미지원 환경임');
            });
	}

	GoDetailView(comp, info, e)
	{
		goPage(comp.compId);
	}

    SetUserInfo()
    {
        const user_info = theApp?.auth_session?.user;

		this.user_name_lbl.setText(user_info ? user_info.name : '');
        this.user_email_lbl.setText(user_info ? user_info.email : '');
        this.user_referral_code_lbl.setText(user_info ? user_info.referral_code : '');
    }
	
}

