
class MarketingConsent extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.MarketingConsentData();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    MarketingConsentData() {
        const data = theApp._terms?.find(term => term.terms_title === '마케팅 정보 수신 동의');

        if (!data) return;

        const { terms_title, updated_at, terms_contents } = data;

        this.title_lbl.setText(terms_title);
        this.updated_at_lbl.setText(`최종 업데이트 : ${this.DateFormat(updated_at)}`);
        this.content_tbx.setText(terms_contents);
    }

    DateFormat(data) {
        const year = data.substring(0, 4);
        const month = data.substring(5, 7);
        const day = data.substring(8, 10);

        return `${year}.${month}.${day}`;
    }

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}

