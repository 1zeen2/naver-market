
class PrivacyPolicy extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		const privacy = Object.values(theApp._terms).find(term => term.terms_title === '개인정보 처리방침');

        this.title_lbl.setText(privacy.terms_title);
        this.date_lbl.setText(this.FormatDate(privacy.updated_at));
        this.content_lbl.setText(privacy.terms_contents);
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    FormatDate(date)
    {
        const year = date.substring(0, 4);
        const month = date.substring(5, 7);
        const day = date.substring(8, 11);

        return `${year}.${month}.${day}`;
    }

	PrevBtn(comp, info, e)
	{
        goPrevPage();
	}
    
}

