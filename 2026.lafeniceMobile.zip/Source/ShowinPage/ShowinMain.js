
class ShowinMain extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.filterText_view.addClass('display-none');

        this.m_filterData = {
            status: 'AA',
            statusText: '전체',
            periodText: '전체',
            start_date: '',
            end_date: ''
        }

        this.showListView_list.itemWrapper[0].classList.add('wrapper-align');

        this.SetListview();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		if (!isFirst) {
            this.SetListview();
        }

	}

    onDeactiveDone()
	{
		super.onDeactiveDone()

        this.filterText_view.addClass('display-none');
        this.filter_view.removeClass('selectBorder');
        this.filter_icon.removeClass('filter_Icon_active');
        this.filter_lbl.addClass(['text-metal-400', 'font-weight-medium']);
        this.filter_lbl.removeClass(['text-pink-500', 'font-weight-semibold']);
        
        this.startDate_lbl.removeClass('font-weight-semibold');
        this.endDate_lbl.removeClass('font-weight-semibold');
        this.tilde_lbl.addClass('display-none');
        this.endDate_lbl.addClass('display-none');
        
        this.m_filterData = {
            status: 'AA',
            statusText: '전체',
            periodText: '전체',
            start_date: '',
            end_date: ''
        };
	}

	FilterBtnClick(comp, info, e)
	{
        openBottomSheet(this, {
            title: '필터',
            path: 'Source/BottomSheet/ShowinFilter.lay',
            data: this.m_filterData,
            onSelect: async (data) => {
                console.log(data);

                this.filterText_view.removeClass('display-none');
                this.filter_view.addClass('selectBorder');
                this.filter_icon.addClass('filter_Icon_active');

                this.filter_lbl.setText(data.status);
                this.filter_lbl.removeClass(['text-metal-400', 'font-weight-medium']);
                this.filter_lbl.addClass(['text-pink-500', 'font-weight-semibold']);

                this.startDate_lbl.addClass('font-weight-semibold');

                if (data.status === '진행 예정') {
                    data.status = '대기';
                }

                const statusCode = Object.values(theApp._bsnsCode.status).find(state => state.label === data.status);

                this.m_filterData = {
                    status: statusCode.code,
                    statusText: data.status,
                    periodText: data.period,
                    start_date: '',
                    end_date: ''
                }

                if (data.period === '직접입력') {
                    this.endDate_lbl.addClass('font-weight-semibold');

                    this.startDate_lbl.setText(this.FormatDate(data.startDate));
                    this.endDate_lbl.setText(this.FormatDate(data.endDate));

                    this.m_filterData.start_date = data.startDate;
                    this.m_filterData.end_date = data.endDate;

                    this.tilde_lbl.removeClass('display-none');
                    this.endDate_lbl.removeClass('display-none');
                } else {
                    this.startDate_lbl.setText(data.period);
                    this.PeriodDateSet(data.period);

                    this.tilde_lbl.addClass('display-none');
                    this.endDate_lbl.addClass('display-none');
                }

                await this.SetListview();
            }
        });
	}

    async SetListview()
    {
        this.showListView_list.removeAllItems();

        const inblock = {
            keyword: this.search_txf.getText() || null,
            status: this.m_filterData.status,
            start_date: this.m_filterData.start_date,
            end_date: this.m_filterData.end_date,
            isHome: false,
            next_key: ''
        };

        const reData = await sendQuery('exhibition', 'list', inblock);

        if (reData) {
            console.log(reData);

            this.showLength_lbl.setText('전시' + reData.length + '개');

            this.showListView_list.addItem('Source/ShowinPage/ShowinItem.lay', reData);

            const listViewele = $(this.showListView_list.element);
            
            listViewele.find('.list_item_wrapper').css({
                'justify-content': 'space-between'
            });
        }
    }

    PeriodDateSet(period)
    {
        const today = new Date();

        if (period === '전체') {
            this.m_filterData.start_date = '';
            this.m_filterData.end_date = '';

            return;
        }

        let startDate;
        let endDate;

        if (period === '일간') {
            startDate = new Date(today);
            endDate = new Date(today);

        } else if (period === '주간') {
            const weekDates = this.WeekDate(today);

            startDate = weekDates.start;
            endDate = weekDates.end;

        } else if (period === '월간') {
            const monthDates = this.MonthDate(today);

            startDate = monthDates.start;
            endDate = monthDates.end;
        }

        this.m_filterData.start_date = this.FormatDateFull(startDate);
        this.m_filterData.end_date = this.FormatDateFull(endDate);
    }

    FormatDate(date)
    {
        const year = date.substring(2, 4);
        const month = date.substring(4, 6);
        const day = date.substring(6, 8);

        return `${year}.${month}.${day}`;
    }

    FormatDateFull(date)
    {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        
        return `${year}${month}${day}`;
    }

    MonthDate(today)
    {
        const startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        const endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);

        return { start: startDate, end: endDate };
    }

    WeekDate(today)
    {
        const startDate = new Date(today);
        const day = startDate.getDay();
        const diff = day === 0 ? -6 : 1 - day;
        startDate.setDate(startDate.getDate() + diff);

        const endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() + 6);

        return { start: startDate, end: endDate };
    }

	RowSelect(comp, info, e)
	{
        goPage('ShowinDetail', info.view.getItemData());
	}

	GoViewingMainPage(comp, info, e)
	{
		goPage('ViewingMain');
	}

	SearchKeydown(comp, info, e)
	{
        if (e.keyCode === 13 && comp.getText()) {
            this.SetListview();
        }
	}
}

