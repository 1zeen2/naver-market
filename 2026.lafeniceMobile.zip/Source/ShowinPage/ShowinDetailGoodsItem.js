
class ShowinDetailGoodsItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetData(this.getItemData());

	}

    SetData(data)
    {
        this.show_img.setImage(`${network.address.replace('/access', '')}${data.thumbnail_path}`);
        this.inventory_lbl.setText('재고 ' + data.goods_stock + '개');
        this.goodsName_lbl.setText(data.goods_title);
        this.price_lbl.setText(this.MoneyMask(data.goods_price));
    }

    MoneyMask(money)
    {
        return Number(money).toLocaleString();
    }

}

