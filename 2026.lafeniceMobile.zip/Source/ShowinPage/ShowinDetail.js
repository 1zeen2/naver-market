
class ShowinDetail extends AView
{
	constructor()
	{
		super()

		this.m_setImgHeight = false;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        const infoData = this.getContainer().getData();

        this.ListDetailAPI(infoData);
        this.GoodsAPI(infoData);
	}

    async ListDetailAPI(data)
    {
        const inblock = {
            exhibition_uid: data.exhibition_uid
        };

        const reDetailData = await sendQuery('exhibition', 'detail', inblock);

        if (reDetailData) {
            console.log('상세 리스트', reDetailData);

            this.headTitle_lbl.setText(reDetailData.exhibition_title);                                                      // 헤더 타이틀
            this.show_img.setImage(`${network.address.replace('/access', '')}${reDetailData.thumbnail_path}`);              // 썸네일 이미지

            this.SetTag(reDetailData.exhibition_tag);                                                                       // 태그

            this.title_lbl.setText(reDetailData.exhibition_title);                                                          // 타이틀
            this.subTitle_lbl.setText(reDetailData.exhibition_subtitle);                                                    // 서브 타이틀

            // 가격
            // this.price1_lbl.setText(reDetailData.);                                                                      // 성인 가격
            // this.price2_lbl.setText(reDetailData.);                                                                      // 청소년 가격
            // this.price3_lbl.setText(reDetailData.);                                                                      // 어린이 가격

            this.startDate_lbl.setText(this.FormatDate(reDetailData.start_date));                                           // 시작일
            this.endDate_lbl.setText(this.FormatDate(reDetailData.end_date));                                               // 종료일

            this.startTime_lbl.setText(this.FormatTime(reDetailData.start_time));                                           // 시작 시간
            this.endTime_lbl.setText(this.FormatTime(reDetailData.end_time));                                               // 종료 시간

            this.SetOperate(reDetailData.operating_days);                                                                   // 운영일, 휴무일

            this.organ_lbl.setText(reDetailData.exhibition_organizer);                                                      // 기관
            this.tel_lbl.setText(reDetailData.exhibition_tel);                                                              // 전화번호
            this.place_lbl.setText(reDetailData.place_name);                                                                // 장소
            this.address_lbl.setText(reDetailData.address_name);                                                            // 주소

            this.about_lbl.setText(reDetailData.exhibition_description);                                                    // 전시 소개
            this.highlight_lbl.setText(reDetailData.exhibition_highlight);                                                  // 전시 하이라이트

            this.detailShow_img.setImage(`${network.address.replace('/access', '')}${reDetailData.thumbnail_path}`);        // 상세 이미지
        }
    }

    async GoodsAPI(data)
    {
        this.goods_list.removeAllItems();

        const inblock = {
            exhibition_uid: data.exhibition_uid,
            limit: 5
        };

        const reGoodsData = await sendQuery('exhibition', 'goodsList', inblock);

        if (reGoodsData) {
            console.log('굿즈 리스트', reGoodsData);

            this.goods_list.addItem('Source/ShowinPage/ShowinDetailGoodsItem.lay', reGoodsData);
        }
    }

    SetTag(tagData)
    {
        if (!tagData) {
            return;
        }

        const tags = JSON.parse(tagData);

        this.tag_view.removeChildren();

        tags.forEach(tagText => {
            const tagLabel = new ALabel();
            tagLabel.init();

            tagLabel.setText('#' + tagText);
            tagLabel.setStyleObj({
                position: 'relative',
                padding: '3px 4px',
                width: 'auto',
                height: 'auto',
                'margin-right': '4px',
                'font-size': '11px',
                color: '#4B4F5C',
                'font-weight': '500',
                'background-color': '#F4F5F7',
                'border-radius': '4px'
            });

            this.tag_view.addComponent(tagLabel);
        })
    }

    SetOperate(operateData)
    {
        if (!operateData) {
            return;
        }

        const operateDay = JSON.parse(operateData);
        const dayName = ['일', '월', '화', '수', '목', '금', '토'];
        
        const operatText = operateDay.length > 1
            ? `${dayName[operateDay[0]]}-${dayName[operateDay[operateDay.length - 1]]}`
            : dayName[operateDay[0]];

        this.dayOfTheWeek_lbl.setText(operatText);
        
        const allDays = [0, 1, 2, 3, 4, 5, 6];
        const closedDays = allDays.filter(day => !operateDay.includes(day));
        
        const closedText = closedDays.length > 0
            ? (closedDays.length > 1 
                ? `(${dayName[closedDays[0]]}-${dayName[closedDays[closedDays.length - 1]]} 휴관)`
                : `(${dayName[closedDays[0]]} 휴관)`)
            : '없음';

        this.closed_lbl.setText(closedText);
    }

    FormatDate(date)
    {
        const year = date.substring(0, 4);
        const month = date.substring(4, 6);
        const day = date.substring(6, 8);

        return `${year}.${month}.${day}`;
    }

    FormatTime(time)
    {
        const hour = time.substring(0, 2);
        const min = time.substring(2, 4);

        return `${hour}:${min}`;
    }

    ExpandClick(comp, info, e)
	{
        if (!this.m_setImgHeight) {
            this.detailShow_view.setHeight('auto');
            this.chevron_icon.addClass('transform-180');

            this.m_setImgHeight = true;
        } else {
            this.detailShow_view.setHeight('400px');
            this.chevron_icon.removeClass('transform-180');

            this.m_setImgHeight = false;
        }
	}

    GoTopClick(comp, info, e)
	{
        window.scrollTo({ top: 0, left: 0 });
	}

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}

