
class ViewingMain extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.m_selectDate = {
            start_date: '',
            end_date: ''
        }

        this.SendListQuery(this.m_selectDate);

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    async SendListQuery(sendDate)
    {
        this.viewing_list.removeAllItems();

        const inblock = {
            start_date: sendDate.start_date,
            end_date: sendDate.end_date
        };

        const reData = await sendQuery('calendar', 'reviewList', inblock);

        if (reData) {
            console.log(reData)

            this.count_lbl.setText(reData.length + '회');

            let totalPoint = 0;

            reData.forEach(item => {
                totalPoint += item.review_earned_point;
            });

            this.totalPoint_lbl.setText(totalPoint + 'P');

            const sortList = reData.sort((a, b) => {
				return b.calendar_date.localeCompare(a.calendar_date);
			});

			sortList.forEach((item, index) => {
				if (index > 0 && sortList[index - 1].calendar_date === item.calendar_date) {
					item.calendar_date = '';
				}

				item.index = index;
				item.totalCount = sortList.length;
			});

            this.viewing_list.addItem('Source/ShowinPage/ViewingItem.lay', sortList);
        }
    }

    DateStateBtnClick(comp, info, e)
    {
        const stateGroup = this.stateBtn_view.findCompByGroup('state_btn');

        stateGroup.forEach(btn => {
            btn.removeClass('selectStyle');
            btn.addClass('defaultStyle');
        })

        comp.removeClass('defaultStyle');
        comp.addClass('selectStyle');

        const selectText = comp.getChild(0).getText();

        switch (selectText) {
            case '전체':
                this.m_selectDate = this.AllCalc();
                this.ResetBtn();
                this.SendListQuery(this.m_selectDate);
                break;

            case '1개월':
                this.m_selectDate = this.Month1Calc();
                this.ResetBtn();
                this.SendListQuery(this.m_selectDate);
                break;

            case '3개월':
                this.m_selectDate = this.Month3Calc();
                this.ResetBtn();
                this.SendListQuery(this.m_selectDate);
                break;

            case '6개월':
                this.m_selectDate = this.Month6Calc();
                this.ResetBtn();
                this.SendListQuery(this.m_selectDate);
                break;

            case '1년':
                this.m_selectDate = this.Year1Calc();
                this.ResetBtn();
                this.SendListQuery(this.m_selectDate);
                break;

            case '기간선택':
            default:
                openBottomSheet(this, {
                    title: '기간 선택',
                    path: 'Source/BottomSheet/ViewingFilter.lay',
                    data: this.m_selectDate,
                    onSelect: async (data) => {
                        this.m_selectDate = {
                            start_date: data.startDate,
                            end_date: data.endDate
                        };
                        this.UpdateDateLabel(data.startDate, data.endDate);

                        this.SendListQuery(this.m_selectDate);
                    },

                    onCancel: () => {
                        if (this.end_lbl.getText() === '') {
                            this.dateSelectBtn_view.removeClass('selectStyle');
                            this.dateSelectBtn_view.addClass('defaultStyle');

                            this.allBtn_view.removeClass('defaultStyle');
                            this.allBtn_view.addClass('selectStyle');
                        }
                    }
                });
                break;
        }
    }

    AllCalc()
    {
        return {
            start_date: '',
            end_date: ''
        };
    }

    Month1Calc()
    {
        const today = new Date();
        const oneMonthAgo = new Date(today);
        oneMonthAgo.setMonth(today.getMonth() - 1);

        return {
            start_date: this.FormatDate(oneMonthAgo),
            end_date: this.FormatDate(today)
        };
    }

    Month3Calc()
    {
        const today = new Date();
        const threeMonthsAgo = new Date(today);
        threeMonthsAgo.setMonth(today.getMonth() - 3);

        return {
            start_date: this.FormatDate(threeMonthsAgo),
            end_date: this.FormatDate(today)
        };
    }

    Month6Calc()
    {
        const today = new Date();
        const sixMonthsAgo = new Date(today);
        sixMonthsAgo.setMonth(today.getMonth() - 6);

        return {
            start_date: this.FormatDate(sixMonthsAgo),
            end_date: this.FormatDate(today)
        };
    }

    Year1Calc()
    {
        const today = new Date();
        const oneYearAgo = new Date(today);
        oneYearAgo.setFullYear(today.getFullYear() - 1);

        return {
            start_date: this.FormatDate(oneYearAgo),
            end_date: this.FormatDate(today)
        };
    }

    UpdateDateLabel(startDate, endDate)
    {
        const formatDot = (date) => {
            return date.slice(0, 4) + '.' + date.slice(4, 6);
        };

        this.start_lbl.setText(formatDot(startDate));

        this.end_lbl.setText(formatDot(endDate));

        this.select_view.removeClass('display-none');
    }

    ResetBtn()
    {
        this.start_lbl.setText('기간선택');

        this.end_lbl.setText('');

        this.select_view.addClass('display-none');
    }

    FormatDate(date)
    {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');

        return `${year}${month}`;
    }

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}

