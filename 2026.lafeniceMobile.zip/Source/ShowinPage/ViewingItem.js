
class ViewingItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.row.hide();
		this.thickRow.hide();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetData(this.getItemData());

	}

    // 데이터 맵핑
    SetData(data)
    {
        console.log(data);

		if (data.calendar_date) {
			this.date_lbl.setText(data.calendar_date);												// 리뷰 작성일
			this.thickRow.show();
			this.row.hide();
		} else {
			this.date_view.hide();
			this.thickRow.hide();
			this.row.show();
		}
                                           
        this.point_lbl.setText(data.review_earned_point);                                           // 적립 포인트
        this.title_lbl.setText(data.calendar_title);                                                // 제목
        this.address_lbl.setText(data.place_name);                                                  // 주소
        this.show_img.setImage(`${network.address.replace('/access', '')}${data.file_path}`);       // 이미지
        this.info_lbl.setText(data.review_comment);                                                 // 리뷰 내용

		if (data.index === data.totalCount - 1) {
			this.thickRow.hide();
			this.row.hide();
		}
    }
}

