
class ShowinItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        this.SetListData(this.getItemData());

	}

    SetListData(data)
    {
        this.show_img.setImage(`${network.address.replace('/access', '')}${data.thumbnail_path}`);

        if (data.status === 'PR') {
            this.status_view.addClass('ing-bg');
            this.status_lbl.addClass('color-white');

            this.status_lbl.setText('진행중');

        } else if (data.status === 'WT') {
            this.status_view.addClass('expected-bg');
            this.status_lbl.addClass('font-color-pink');

            this.status_lbl.setText('진행 예정');

        } else if (data.status === 'ED') {
            this.status_view.addClass('deadline-bg');
            this.status_lbl.addClass('font-color-gray-96');

            this.status_lbl.setText('마감');

        }

        this.title_lbl.setText(data.exhibition_title + ':' + data.exhibition_subtitle);

        this.subTitle_lbl.setText(data.place_name);

        this.startDate_lbl.setText(this.FormatDate(data.start_date));

        this.endDate_lbl.setText(this.FormatDate(data.end_date));
    }

    FormatDate(date)
    {
        const strDate = String(date);

        const year = strDate.substring(0, 4);
        const month = strDate.substring(4, 6);
        const day = strDate.substring(6, 8);

        return `${year}.${month}.${day}`;
    }

}

