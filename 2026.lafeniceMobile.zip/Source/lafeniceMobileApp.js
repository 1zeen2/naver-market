
class lafeniceMobileApp extends AApplication
{
	constructor()
	{
		super()

		this.active_page_id = '';
        this.history_count = 0;
	}

	onReady()
	{
		super.onReady();
        
        //theApp.mainContainer.closePage('MainView'); 화면 닫기 로직 적용해야함

                window.addEventListener('popstate', (e) => {

                    

                    // 1. 열려있는 윈도우(팝업/모달)가 있다면 최상위 윈도우를 닫는다.

                    if(AWindow.wndList && AWindow.wndList.length > 0) {

                        const topWnd = AWindow.wndList[AWindow.wndList.length - 1];

                        topWnd.close();

                        return;

                    }

        

                    const active_page = theApp.mainContainer.activePage;

                    const page_id = e?.state?.page;

                    const main_view_child = [

                        'MainPage',

                        'MarketMain',

                        'ShowinMain',

                        'MoreMain',

                        'CalendarPage',

                    ];

        

                                            // 2. MainView 내부 탭 전환인 경우

        

                                            let target_page_id = page_id;

        

                                            if(!target_page_id && active_page?.containerId === 'MainView') target_page_id = 'MainPage';

        

                                

        

                                            if(target_page_id && main_view_child.includes(target_page_id) && active_page?.containerId === 'MainView'){

        

                                                const id_view = active_page.view.nav_bar.ldView;

        

                                                if(id_view[target_page_id]) {

        

                                                    id_view.OnChangePage(id_view[target_page_id], null, null, true);

        

                                                }

        

                                            } 

        

                                            // 3. 그 외의 경우 (일반적인 페이지 뒤로가기)

                    else {

                        goPrevPage(null, true);

                    }

                });
        
        this.setMainContainer(new APage('main'))

        
        this.mainContainer.open('Source/Intro/Splash.lay')
            .then(res => {
                
            })

        // // 2. 특정 조건(데이터 로드 완료 등) 충족 시 Splash 제거 후 메인 오픈

        // //this.mainContainer.removeChildren();
		// this.mainContainer.open('Source/Main/MainPage.lay');
        this.SetPage();
    }

	unitTest(unitUrl)
	{
		//TODO:edit here
		this.onReady()
		super.unitTest(unitUrl)
	}

    SetPage()
    {

        theApp.mainContainer.navigator = new ANavigator();

        for(const key in page) {
            this.mainContainer.navigator.registerPage(key, page[key]); 
        }
    }

}

