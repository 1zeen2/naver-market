
class ShowinMainItem extends AView
{
	constructor()
	{
		super()

        this.list_data = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.list_data = data;

        this.newexh_img.setImage(network.address.replace('/access', '') + data.thumbnail_path);
        //this.newexh_state_lbl.setText(stateText);
        //this.newexh_state_lbl.addClass(stateClass);
        this.newexh_name_lbl.setText(data.exhibition_title);
        this.newexh_address_lbl.setText(data.place_name);
        //this.newexh_price_lbl.setText(data.price);
        //this.newexh_howbook_lbl.setText(data.book);
        this.newexh_start_date_lbl.setText(this.FormatDate(data.start_date));
        this.newexh_end_date_lbl.setText(this.FormatDate(data.end_date));
    }

    // TFUNCTION: OnWrapViewClick: 아이템 클릭 시 상품 상세내용으로 이동
    OnWrapViewClick(comp, info, e)
	{
		goPage('ShowinDetail', this.list_data);
	}

    // TFUNCTION: FormatDate: 날짜 데이터를 yyyy.mm.dd 형식으로 return하는 함수
    FormatDate(num)
    {
        if(!parseInt(num, 10)) return '';

        num+='';
        return num.substring(0,4)+'.'+num.substring(4,6)+'.'+num.substring(6,8); 
    }
}

