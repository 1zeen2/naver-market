
class MissionItem extends AView
{
	constructor()
	{
		super()
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        let img = '';

        switch(data.mission_status)
        {
            case 'CM' : img = 'Assets/calendar_pink_Icon.png'; break;   //미션완료
            case 'PR' : img = 'Assets/camera_Icon.png'; break;     //진행중
        }

        this.icon_img.setImage(img);
        this.title_lbl.setText(data.mission_title);
        this.inx_lbl.setText(data.completed_count);
        this.all_inx_lbl.setText(data.total_count);

        if(data.is_last)
        {
            this.wrap_view.setStyle('border','none');
        }
    }

    // TFUNCTION: WrapViewClick: 해당 리스트아이템 관련 화면으로 이동하는 클릭이벤트 함수
	WrapViewClick(comp, info, e)
	{

		//TODO:edit here

	}

}

