
class BannerItem extends AView
{
	constructor()
	{
		super()

        this.list_data = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}
    
    setData(data)
    {
        this.list_data = data;
        
        this.banner_img.setImage(network.address.replace('/access', '') + data.file_path);
    }

}

