class MainPage extends AView {
    constructor() {
        super();
        this.global = {
            INTERVAL_BANNER: null,
            INTERVAL_NEWEXH: null,
            INTERVAL_EVENT: null,
        };
        
        this.current_banner_idx = 1; // 배너의 현재 위치 (무조건 1부터 시작)
        this.banner_count = 0;       // 실제 데이터 개수
        this.is_handling_loop = false;
    }

    init(context, evtListener) {
        super.init(context, evtListener);
    }

    onInitDone() {
        super.onInitDone();

        this.SetData();
    }

    onActiveDone(isFirst) {
        super.onActiveDone(isFirst);

        // if(!isFirst)
        // {
        //     this.SetData();
        // }
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 시작
    // onDeactive(isFirst) {
    //     super.onDeactive(isFirst);
    //     Object.keys(this.global).forEach(key => this._clearInterval(key));
    // }

    // // TFUNCTION: SetData: 데이터 셋팅
    async SetData() {
        await Promise.all([
            this.GetBanner(), //배너
            // this.GetNewExhibit(), //신규전시
            // this.GetGoingEvent(), //진행중이벤트
            // this.GetWeekDate(), //일정  //this.GetSchedule()
            // this.GetGoingMission(), //진행중미션
            // this.GetNotice(), //공지사항
        ]);
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 끝
    // TFUNCTION: GetBanner: 배너 데이터를 가져온다.
    async GetBanner() {
        const res = await sendQuery("system", "advertisement");
        console.log(res);
        
        if (!res || res.length === 0) {
            if (this.banner_area) this.banner_area.hide();
            return;
        }
        this.banner_area?.show();

        this.banner_count = res.length;
        
        // 데이터 마지막, 1, 2, ..., n, 처음
        const data = (this.banner_count > 1) 
            ? [res[this.banner_count - 1], ...res, res[0]] 
            : res;

        this.banner_list.removeAllItems();
        await this.banner_list.addItem("Source/MainPage/BannerItem.lay", data);

        setTimeout(() => {
            const scroller = this.banner_list.element.children[0];
            const itemWidth = scroller.clientWidth;
            
            this.current_banner_idx = (this.banner_count > 1) ? 1 : 0;
            scroller.scrollTo({ left: itemWidth * this.current_banner_idx, behavior: 'auto' });
            
            this.SetBannerCount(this.current_banner_idx);
            if (this.banner_count > 1) this.StartBannerAutoSlide();
        }, 100);
    }

    OnBannerListScroll() {
        const scroller = this.banner_list.element.children[0];
        const itemWidth = scroller.clientWidth;
        if (itemWidth <= 0) return;

        const scrollLeft = scroller.scrollLeft;
        
        const currentIdx = Math.round(scrollLeft / itemWidth);

        if (currentIdx === this.banner_count + 1) {
            if (Math.abs(scrollLeft - (itemWidth * (this.banner_count + 1))) < 1) {
                this.current_banner_idx = 1;
                scroller.scrollTo({ left: itemWidth * 1, behavior: 'auto' });
            }
        } 
        else if (currentIdx === 0) {
            if (Math.abs(scrollLeft - 0) < 1) {
                this.current_banner_idx = this.banner_count;
                scroller.scrollTo({ left: itemWidth * this.banner_count, behavior: 'auto' });
            }
        } else {
            this.current_banner_idx = currentIdx;
        }

        this.SetBannerCount(this.current_banner_idx);
    }

    StartBannerAutoSlide() {
        if (this.global.INTERVAL_BANNER) clearInterval(this.global.INTERVAL_BANNER);

        this.global.INTERVAL_BANNER = setInterval(() => {
            const scroller = this.banner_list.element.children[0];
            const itemWidth = scroller.clientWidth;
            
            this.current_banner_idx++;
            
            scroller.scrollTo({ 
                left: itemWidth * this.current_banner_idx, 
                behavior: 'smooth' 
            });
        }, 5000);
    }

    // 4. 유저가 만질 때 자동 슬라이드 중지
    OnBannerListActionmove() {
    }

    OnBannerListActionup() {
        // 손을 떼고 1초 뒤에 다시 자동 슬라이드 시작
        setTimeout(() => this.StartBannerAutoSlide(), 1000);
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 시작
    // OnBannerListActionmove() {
    //     this.is_transitioning = true; // 조작 중 자동 이동 방지
    //     this._clearInterval('INTERVAL_BANNER');
    // }

    // OnBannerListActionup() {
    //     this.is_transitioning = false;
    //     // 즉시 시작하지 않고 약간의 유예를 두어 스냅이 걸릴 시간을 줌
    //     setTimeout(() => this.StartBannerAutoSlide(), 100);
    // }

    // _clearInterval(key) {
    //     if (this.global[key]) {
    //         clearInterval(this.global[key]);
    //         this.global[key] = null;
    //     }
    // }

    // TFUNCTION: SetBannerCount: 배너 갯수를 카운트하고 표시해준다.
    SetBannerCount(idx) {
        if (!this.banner_inx_lbl || !this.banner_all_inx_lbl) return;
        
        const all_cnt = this.banner_count;
        if (all_cnt <= 0) return;

        let display_idx = idx;
        if (idx <= 0) display_idx = all_cnt;
        else if (idx > all_cnt) display_idx = 1;

        const currentText = this.banner_inx_lbl.getText();
        if (currentText != display_idx) {
            this.banner_inx_lbl.setText(display_idx);
        }
        
        if (this.banner_all_inx_lbl.getText() != all_cnt) {
            this.banner_all_inx_lbl.setText(all_cnt);
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 끝
    /**
     * Helper function to initialize carousel data and UI, including cloning for infinite scroll.
     * @param {object} params
     * @param {Array|object} params.resData - The API response data, either an array for direct use or an object with a 'list' property.
     * @param {object} params.listComp - The list component (e.g., this.banner_list)
     * @param {string} params.originalCountVar - The name of the property to store the original count (e.g., 'banner_original_count')
     * @param {object} params.noDataView - The view to show when no data (e.g., this.banner_nodata_view)
     * @param {object} params.dataView - The view to show when data is present (e.g., this.banner_data_view)
     * @param {object} params.extraViewToHide - An optional extra view to hide when no data (e.g., this.banner_inx_flay)
     * @param {string} params.setItemLay - The layout file for list items (e.g., "Source/MainPage/BannerItem.lay")
     * @param {function} params.setCountFunc - Function to update the count display (e.g., this.SetBannerCount)
     * @param {function} params.startAutoSlideFunc - Function to start auto-slide (e.g., this.StartBannerAutoSlide)
     */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 시작
    // async _initCarouselDataAndUI({
    //     resData, listComp, originalCountVar, noDataView, dataView, 
    //     extraViewToHide, setItemLay, setCountFunc, startAutoSlideFunc, 
    //     isInfinite = true,
    //     indexVar // 현재 인덱스를 저장할 변수명 (예: 'current_banner_idx')
    // }) {
    //     listComp.removeAllItems();
    //     const dataList = Array.isArray(resData) ? resData : (resData?.list || []);

    //     // 1. 데이터 유무 방어 코드
    //     if (!dataList || dataList.length === 0) {
    //         if (extraViewToHide) extraViewToHide.hide();
    //         dataView.hide();
    //         noDataView.show();
    //         return;
    //     }

    //     if (extraViewToHide) extraViewToHide.show();
    //     dataView.show();
    //     noDataView.hide();

    //     // 2. 데이터 구성 및 개수 저장
    //     const originalCount = dataList.length;
    //     this[originalCountVar] = originalCount;

    //     const finalData = (isInfinite && originalCount > 1) 
    //         ? [dataList[originalCount - 1], ...dataList, dataList[0]] 
    //         : dataList;

    //     await listComp.addItem(setItemLay, finalData);

    //     // 3. 렌더링 후 초기 위치 설정 (핵심)
    //     requestAnimationFrame(() => {
    //         const startIdx = (isInfinite && originalCount > 1) ? 1 : 0;
            
    //         // 인덱스 변수 업데이트
    //         if (indexVar) this[indexVar] = startIdx;
            
    //         // 스크롤 위치 즉시 강제 이동
    //         const scroller = listComp.element.children[0];
    //         const itemWidth = $(scroller).width();
    //         $(scroller).scrollLeft(itemWidth * startIdx);

    //         // UI 및 인터벌 시작
    //         if (setCountFunc) setCountFunc.call(this, startIdx === 0 ? 1 : startIdx, originalCount);
    //         if (startAutoSlideFunc) startAutoSlideFunc.call(this);
    //     });
    // }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 끝

    // async _initCarouselDataAndUI({
    //     resData, listComp, originalCountVar, noDataView, dataView, 
    //     extraViewToHide, setItemLay, setCountFunc, startAutoSlideFunc, 
    //     isInfinite = true
    // }) {
    //     listComp.removeAllItems();
    //     let dataList = Array.isArray(resData) ? resData : (resData?.list || []);

    //     if (!dataList || dataList.length === 0) {
    //         if (extraViewToHide) extraViewToHide.hide();
    //         dataView.hide();
    //         noDataView.show();
    //         return;
    //     }

    //     if (extraViewToHide) extraViewToHide.show();
    //     dataView.show();
    //     noDataView.hide();

    //     // 원본 데이터 개수 저장 (예: 5)
    //     const originalCount = dataList.length;
    //     this[originalCountVar] = originalCount;

    //     // 무한 루프용 데이터 구성 (E A B C D E A)
    //     const finalData = isInfinite 
    //         ? [dataList[originalCount - 1], ...dataList, dataList[0]] 
    //         : dataList;

    //     await listComp.addItem(setItemLay, finalData);
    

    //     if (isInfinite) {
    //         setTimeout(() => {
    //             const firstItem = listComp.getItem(1);
    //             if (firstItem) {
    //                 const scroller = listComp.element.children[0];
    //                 scroller.scrollLeft = firstItem.offsetLeft;

    //                 listComp.setSelectItem(1);

    //                 if (setCountFunc) setCountFunc.call(this, 1, originalCount);
    //                 if (startAutoSlideFunc) startAutoSlideFunc.call(this)
    //             }
    //         }, 100)
            
    //     } else {
    //         listComp.setSelectItem(0);
    //         if (setCountFunc) setCountFunc.call(this, 1, originalCount);
    //     }

    //     // if (startAutoSlideFunc) startAutoSlideFunc.call(this);
    // }

    /**


             * Helper function to handle scroll events for carousels with infinite loop cloning.


             * @param {object} listComp - The list component (e.g., this.banner_list)


             * @param {number} originalCount - The original count of items (e.g., this.banner_original_count)


             * @param {function} setCountFunc - Function to update the count display (e.g., this.SetBannerCount)


             * @param {Event} e - The scroll event


             */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 시작
    // _handleCarouselScroll(listComp, originalCount, setCountFunc, e) {
    //     const scroller = listComp.element.children[0];

    //     const scroll_left = scroller.scrollLeft;

    //     const page_width = scroller.clientWidth;

    //     const total_items = listComp.getItemCount();

    //     let near_inx = Math.round(scroll_left / page_width);

    //     // Handle seamless jumping for cloned items

    //     if (near_inx === 0 && total_items > 1) {
    //         // If scrolled to the cloned last item

    //         scroller.scrollLeft = page_width * originalCount; // Jump to the actual last item

    //         near_inx = originalCount;
    //     } else if (near_inx === total_items - 1 && total_items > 1) {
    //         // If scrolled to the cloned first item

    //         scroller.scrollLeft = page_width; // Jump to the actual first item

    //         near_inx = 1;
    //     }

    //     // Adjust index for display

    //     let display_inx = near_inx;

    //     if (display_inx === 0) {
    //         // If it's the cloned last item

    //         display_inx = originalCount;
    //     } else if (display_inx === total_items - 1) {
    //         // If it's the cloned first item

    //         display_inx = 1;
    //     }

    //     listComp.setSelectItem(near_inx);

    //     setCountFunc.call(this, display_inx, originalCount);
    // }

    // /**
    // * Helper function to handle actionmove events for carousels (clears interval).
    // * @param {string} intervalIdName - Name of the global interval variable (e.g., 'INTERVAL_BANNER')
    // */

    // _handleCarouselActionmove(intervalIdName) {
    //     this._clearInterval(intervalIdName); // 중복 로직 통합
    // }

    // /**
    //  * Helper function to handle actionup events for carousels (starts auto-slide).
    //  * @param {function} startAutoSlideFunc - Function to start auto-slide (e.g., this.StartBannerAutoSlide)
    //  */

    // _handleCarouselActionup(startAutoSlideFunc) {
    //     startAutoSlideFunc.call(this);
    // }

    // async GetNewExhibit() {
    //     const inblock = {
    //         keyword: "",
    //         status: "AA",
    //         start_date: "",
    //         end_date: "",
    //         isHome: true,
    //         next_key: "",
    //     };

    //     // 2. 데이터 요청
    //     const res = await sendQuery("exhibition", "list", inblock);

    //     // 3. UI 처리 로직을 헬퍼 함수로 위임 (Spread Operation은 이 내부에서 처리됨)
    //     await this._initCarouselDataAndUI({
    //         resData: res,
    //         listComp: this.newexh_list,
    //         originalCountVar: "newexh_original_count",
    //         noDataView: this.banner_nodata_view,
    //         dataView: this.newexhibit_view,
    //         extraViewToHide: this.newexh_dot_flay,
    //         setItemLay: "Source/MainPage/ShowinMainItem.lay",
    //         isInfinite: true, // 디자이너 지정 위치 사수를 위해 false
    //         setCountFunc: (cnt, all_cnt) => this.MakeNewExhibitDot(cnt, all_cnt),
    //         startAutoSlideFunc: this.StartNewExhibitAutoSlide,
    //     });
    // }

    // // TFUNCTION: OnNewexhShowAllViewClick: 신규 전시 전체보기
    // OnNewexhShowAllViewClick(comp, info, e) {
    //     goPage("ShowinMain");
    // }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 끝

    // TFUNCTION: MakeNewExhibitDot: 신규전시 dot 버튼 동적 생성
    // MakeNewExhibitDot(select_inx, all_inx) {
    //     if (all_inx == 0) return;

    //     this.newexh_dot_flay.removeAllItems();

    //     for (let i = 0; i < all_inx; i++) {
    //         let btn = new AButton();
    //         let is_select = i == select_inx ? true : false;
    //         let style_class = is_select
    //             ? "newexh_dot_select"
    //             : "newexh_dot_noselect";

    //         btn.init();
    //         btn.addClass("transition-200");
    //         btn.setStyleObj({
    //             height: "4px",
    //             position: "relative",
    //             left: "0px",
    //             top: "0px",
    //             "border-radius": "100px",
    //             transition: "all",
    //         });

    //         btn.compId = `newexh_dot_${i + 1}_btn`;
    //         btn.setText("");
    //         btn.setData(is_select);
    //         btn.addEventListener("click", this, "OnSelectNewExhibit");

    //         btn.setDefStyle(style_class);
    //         btn.setBtnStyle(AButton.DOWN, style_class);
    //         btn.defaultBtnState();

    //         this[`newexh_dot_${i + 1}_btn`] = btn;
    //         this.newexh_dot_flay.layComponent(btn);
    //     }
    // }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 시작
    // MakeNewExhibitDot(select_inx, all_inx) {
    //     if (all_inx <= 0) return;
    //     this.newexh_dot_flay.removeAllItems();

    //     for (let i = 0; i < all_inx; i++) {
    //         const btn = new AButton();
    //         const is_select = (i === select_inx);
    //         const style = is_select ? "newexh_dot_select" : "newexh_dot_noselect";

    //         btn.init();
    //         btn.addClass("transition-200");
    //         btn.setStyleObj({ height: "4px", left: "0px", top: "0px", borderRadius: "100px", position: "relative", transition: "all" });
    //         btn.compId = `newexh_dot_${i + 1}_btn`;
    //         btn.setText("");
    //         btn.setData(is_select);
    //         btn.addEventListener("click", this, "OnSelectNewExhibit");
    //         btn.setDefStyle(style);
    //         btn.setBtnStyle(AButton.DOWN, style)
    //         btn.defaultBtnState();

    //         this[`newexh_dot_${i + 1}_btn`] = btn;
    //         this.newexh_dot_flay.layComponent(btn);
    //     }
    // }

    // // TFUNCTION: SetNewExhibitDot: 신규전시 dot 셋팅
    // SetNewExhibitDot(inx) {
    //     const dots = this.newexh_dot_flay.getAllLayoutComps();
    //     dots.forEach((dot, i) => {
    //         const isTarget = (i === inx);
    //         dot.setData(isTarget);
    //         dot.removeClass(isTarget ? "newexh_dot_noselect" : "newexh_dot_select");
    //         dot.addClass(isTarget ? "newexh_dot_select" : "newexh_dot_noselect");
    //     });
    // }

    // //TFUNCTION: OnSelectNewExhibit: 신규전시 dot 클릭 이벤트
    // OnSelectNewExhibit(comp, info, e) {
    //     const idx = Number(comp.compId.split("_")[2]);
    //     this._scrollToListIndex(this.newexh_list, idx);
    //     this.SetNewExhibitDot(idx);
    // }
    

    // //TFUNCTION: StartNewExhibitAutoSlide: 신규전시 자동 슬라이드 시작/종료 함수
    // StartNewExhibitAutoSlide() {
    //     if (this.global.INTERVAL_NEWEXH) clearInterval(this.global.INTERVAL_NEWEXH);
        
    //     this.global.INTERVAL_NEWEXH = setInterval(() => {
    //         const current = this.newexh_list.getSelectItem();
    //         const next = (current + 1) % this.newexh_original_count;
            
    //         this._scrollToListIndex(this.newexh_list, next);
    //         this.SetNewExhibitDot(next);
    //     }, 5000);
    // }

    // //TFUNCTION: OnNewexhListScroll: 신규전시 리스트 스크롤 이벤트
    // OnNewexhListScroll() {
    //     const scroller = this.newexh_list.element.children[0];
    //     const scroll_left = scroller.scrollLeft;
    //     const page_width = scroller.clientWidth || 1; // 0 나누기 방지
    //     const originalCount = this.newexh_original_count;
        
    //     // 현재 인덱스 계산
    //     let near_inx = Math.round(scroll_left / page_width);
    //     const total_items = this.newexh_list.getItemCount();

    //     // [Seamless Jump 로직]
    //     if (near_inx === 0) { // 맨 앞 더미(E)에 도달하면
    //         scroller.scrollLeft = page_width * originalCount; // 진짜 E로 점프
    //         near_inx = originalCount;
    //     } else if (near_inx === total_items - 1) { // 맨 뒤 더미(A)에 도달하면
    //         scroller.scrollLeft = page_width; // 진짜 A로 점프
    //         near_inx = 1;
    //     }

    //     // UI 상태 업데이트
    //     this.newexh_list.setSelectItem(near_inx);
        
    //     // 점 인덱스 보정 (1~originalCount 사이 값으로)
    //     let dotIdx = near_inx - 1; 
    //     this.SetNewExhibitDot(dotIdx);
    //     }

    // _scrollToListIndex(listComp, index) {
    //     const item = listComp.getItem(index);
    //     if (!item) return;

    //     const center = listComp.element.clientWidth / 2;
    //     const pos = item.offsetLeft - center + (item.clientWidth / 2);
        
    //     listComp.setSelectItem(index);
    //     listComp.scrollTo(Math.max(0, pos));
    // }

    // //TFUNCTION: OnNewexhListActionup: 신규전시 리스트 actionmove 이벤트
    // OnNewexhListActionmove(comp, info, e) {
    //     //if(this.global.INTERVAL_NEWEXH) clearInterval(this.global.INTERVAL_NEWEXH);
    //     //this.global.INTERVAL_NEWEXH = null;
    // }

    // //TFUNCTION: OnNewexhListActionup: 신규전시 리스트 actionup 이벤트
    // OnNewexhListActionup(comp, info, e) {
    //     //this.StartNewExhibitAutoSlide();
    // }

    // // TFUNCTION: GetGoingEvent: 진행중인 이벤트 데이터를 가져온다.
    // async GetGoingEvent() {
    //     const res = await sendQuery("promotion", "list");

    //     this._initCarouselDataAndUI({
    //         resData: res,
    //         listComp: this.evting_list,
    //         originalCountVar: "evting_original_count",
    //         noDataView: this.evting_nodata_view,
    //         dataView: this.evting_data_view,
    //         extraViewToHide: this.evting_inx_flay,
    //         setItemLay: "Source/MainPage/EventItem.lay",
    //         setCountFunc: this.SetGoingEventCount,
    //         startAutoSlideFunc: this.StartGoingEventAutoSlide,
    //     });
    // }

    // // TFUNCTION: SetGoingEventCount: 진행중인 이벤트 갯수를 카운트하고 표시해준다.
    // SetGoingEventCount(cnt, all_cnt) {
    //     this.evting_inx_lbl.setText(cnt);
    //     this.evting_all_inx_lbl.setText(all_cnt);
    // }

    // //TFUNCTION: StartGoingEventAutoSlide: 진행중인 이벤트 자동 슬라이드 시작/종료 함수
    // StartGoingEventAutoSlide() {
    //     this._setupAutoSlideCarousel({
    //         intervalIdName: "INTERVAL_EVENT",
    //         listComp: this.evting_list,
    //         originalCount: this.evting_original_count,
    //         isScrollingFlagName: "event_isScrolling",
    //         setCountFunc: this.SetGoingEventCount,
    //         intervalTime: 5000,
    //     });
    // }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 끝
    /**
     * Helper function to setup auto-sliding for carousels with infinite loop cloning.
     * @param {object} carouselParams
     * @param {string} carouselParams.intervalIdName - Name of the global interval variable (e.g., 'INTERVAL_BANNER')
     * @param {object} carouselParams.listComp - The list component (e.g., this.banner_list)
     * @param {number} carouselParams.originalCount - The original count of items (e.g., this.banner_original_count)
     * @param {boolean} carouselParams.isScrollingFlag - The component's isScrolling flag (e.g., this.banner_isScrolling)
     * @param {function} carouselParams.setCountFunc - Function to update the count display (e.g., this.SetBannerCount)
     * @param {number} carouselParams.intervalTime - The interval time in ms (e.g., 5000)
     */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 시작
//     _setupAutoSlideCarousel({
//         intervalIdName,
//         listComp,
//         originalCount,
//         isScrollingFlagName,
//         setCountFunc,
//         intervalTime,
//     }) {
//         if (this.global[intervalIdName]) {
//             clearInterval(this.global[intervalIdName]);
//             this.global[intervalIdName] = null;
//         }

//         this.global[intervalIdName] = setInterval(() => {
//             if (this[isScrollingFlagName]) return;
//             this[isScrollingFlagName] = true;

//             let select_item_inx = listComp.getSelectItem();
//             const total_items = listComp.getItemCount();

//             if (select_item_inx === originalCount && originalCount > 0) {
//                 const target_item_inx = originalCount + 1;
//                 const next_item_view = listComp.getItem(target_item_inx);
//                 const center = listComp.element.clientWidth / 2;
//                 const scroll_to_position =
//                     next_item_view.offsetLeft -
//                     center +
//                     next_item_view.clientWidth / 2;

//                 listComp.scrollTo(scroll_to_position, true, () => {
//                     listComp.scrollTo(
//                         listComp.getItem(1).offsetLeft,
//                         false,
//                         () => {
//                             listComp.setSelectItem(1);
//                             setCountFunc.call(this, 1, originalCount);
//                             this[isScrollingFlagName] = false;
//                         },
//                     );
//                 });
//             } else {
//                 const target_item_inx = select_item_inx + 1;
//                 const next_item_view = listComp.getItem(target_item_inx);
//                 const center = listComp.element.clientWidth / 2;
//                 const scroll_to_position =
//                     next_item_view.offsetLeft -
//                     center +
//                     next_item_view.clientWidth / 2;
//                 listComp.scrollTo(scroll_to_position, true, () => {
//                     this[isScrollingFlagName] = false;
//                 });
//                 listComp.setSelectItem(target_item_inx);

//                 let display_idx = target_item_inx;
//                 if (display_idx === 0) {
//                     display_idx = originalCount;
//                 }
//                 setCountFunc.call(this, display_idx, originalCount);
//             }
//         }, intervalTime);
//     }

//     // TFUNCTION: OnEvtingShowAllViewClick: 진행중인 이벤트 전체보기
//     OnEvtingShowAllViewClick(comp, info, e) {
//         goPage("Event");
//     }

//     // TFUNCTION: OnEvtingListScroll: 진행중인 이벤트 스크롤 이벤트
//     OnEvtingListScroll(comp, info, e) {
//         this._handleCarouselScroll(
//             this.evting_list,
//             this.evting_original_count,
//             this.SetGoingEventCount,
//             e,
//         );
//     }

//     // TFUNCTION: OnEvtingListActionmove: 진행중인 이벤트 actionmove 이벤트
//     OnEvtingListActionmove(comp, info, e) {
//         this._handleCarouselActionmove("INTERVAL_EVENT");
//     }

//     // TFUNCTION: OnEvtingListActionup: 진행중인 이벤트 actionup 이벤트
//     OnEvtingListActionup(comp, info, e) {
//         this._handleCarouselActionup(this.StartGoingEventAutoSlide);
//     }

//     // TFUNCTION: GetWeekDate: 이번 주 날짜 데이터를 구한다.
//     GetWeekDate() {
//         const today = new Date();
//         const day = today.getDay(); //0~6(일~토)

//         const sunday = new Date(today);
//         sunday.setDate(today.getDate() - day);

//         for (let i = 0; i < 7; i++) {
//             let compo = this[`cal_${i}_day_lbl`];
//             let date = new Date(sunday);
//             date.setDate(sunday.getDate() + i);

//             compo.parent.date = date;
//             compo.setText(date.getDate());

//             if (today.getDate() == date.getDate()) {
//                 this.OnCalViewClick(compo.parent);
//             }
//         }
//     }

//     // TFUNCTION: OnAddScheBtnClick: 일정 추가
//     OnAddScheBtnClick(comp, info, e) {
//         let win = new AWindow();

//         win.setData({
//             is_add: true,
//         });
//         win.setResultCallback((result) => {
//             if (result) {
//                 let check_date = this.calender_flay
//                     .getAllLayoutComps()
//                     .filter((item) => item.is_check)[0];

//                 this.sched_data_view.show();
//                 this.sched_nodata_view.hide();
//                 this.OnCalViewClick(check_date);
//             }
//         });
//         win.openFull(
//             "Source/CalendarPage/ScheduleRegist.lay",
//             this.getContainer(),
//         );
//     }

//     // TFUNCTION: OnCalViewClick: 일정 날짜 클릭 이벤트
//     OnCalViewClick(comp, info, e) {
//         if (!comp.date) return;

//         for (let i = 0; i < 7; i++) {
//             this[`cal_${i}_view`].is_check = false;
//             this[`cal_${i}_day_lbl`].removeClass("select_date");
//         }
//         comp.is_check = true;
//         comp.getChild(1).addClass("select_date");

//         const yy = String(comp.date.getFullYear());
//         const mm = String(comp.date.getMonth() + 1).padStart(2, "0");
//         const dd = String(comp.date.getDate()).padStart(2, "0");
//         const date = `${yy}${mm}${dd}`;

//         this.GetSchedule(date);
//     }

//     // TFUNCTION: GetSchedule: 일정 데이터를 가져온다.
//     async GetSchedule(date) {
//         if (!date) return;

//         const inblock = {
//             start_date: date,
//             end_date: date,
//         };

//         const res = await sendQuery("calendar", "list", inblock);

//         this.sched_list.removeAllItems();

//         if (res.error || res.length === 0) {
//             this.sched_data_view.hide();
//             this.sched_nodata_view.show();
//         } else {
//             res[res.length - 1].is_last = true;

//             this.sched_data_view.show();
//             this.sched_nodata_view.hide();
//             this.sched_list.addItem("Source/MainPage/SchDuleItem.lay", res);
//         }

//         console.log("calendar/list result : ", res);
//     }

//     // TFUNCTION: OnSchedShowAllViewClick: 일정 내일정보러가기
//     OnSchedShowAllViewClick(comp, info, e) {
//         const check_date = this.calender_flay
//             .getAllLayoutComps()
//             .filter((view) => view.is_check);
//         if (check_date.length == 0) return;

//         const full_date = check_date[0].date;

//         const yyyy = full_date.getFullYear();
//         const mm = full_date.getMonth() + 1;
//         const dd = full_date.getDate();
//         const send_data = {
//             year: yyyy,
//             month: mm,
//             day: dd,
//         };

//         goPage("CalendarPage", send_data);
//     }

//     // TFUNCTION: GetGoingMission: 진행중인 미션 데이터를 가져온다.
//     async GetGoingMission() {
//         const res = await sendQuery("mission", "list");

//         this.misning_list.removeAllItems();

//         if (res.error || res.length === 0) {
//             this.point_lbl.setText("0P");
//         } else {
//             let point = 0;
//             res.forEach((obj) => (point += obj.reward_point));
//             res[res.length - 1].is_last = true;

//             this.misning_list.addItem("Source/MainPage/MissionItem.lay", res);
//             this.point_lbl.setText(`${ADataMask.Number.money.func(point)}P`);
//         }

//         console.log("mission/list result : ", res);
//     }

//     // TFUNCTION: OnMisningShowViewClick: 진행중인미션 미션보러가기
//     OnMisningShowViewClick(comp, info, e) {
//         goPage("MissionInProgress");
//     }

//     // TFUNCTION: GetNotice: 공지사항 데이터를 가져온다.
//     async GetNotice() {
//         const inblock = {
//             // 'notice_type': 'SS',
//             // 'cursor': '',
//         };

//         const res = await sendQuery("board", "notice", inblock);

//         this.notice_list.removeAllItems();

//         if (res.error || res.list.length === 0) {
//         } else {
//             //res.list = res.list.filter(obj => obj.is_pinned == 'Y');
//             res.list[res.list.length - 1].is_last = true;

//             this.notice_list.addItem(
//                 "Source/MainPage/NotificationItem.lay",
//                 res.list,
//             );
//         }

//         console.log("board/notice result : ", res);
//     }

//     // TFUNCTION: OnNoticeShowAllViewClick: 공지사항 전체보기
//     OnNoticeShowAllViewClick(comp, info, e) {
//         goPage("NoticeMain");
//     }
// }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 잠시 주석 끝