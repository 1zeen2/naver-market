
class EventItem extends AView
{
	constructor()
	{
		super()
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.event_img.setImage(network.address.replace('/access', '') + data.thumbnail_path);
    }

    // TFUNCTION: OnWrapViewClick: 이벤트 상세보기 화면으로 이동
	OnWrapViewClick(comp, info, e)
	{
		goPage();
	}
}

