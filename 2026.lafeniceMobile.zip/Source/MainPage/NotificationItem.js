
class NotificationItem extends AView
{
	constructor()
	{
		super()

        this.m_list_data = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.m_list_data = data;

        let stateText='', stateClass='';

        switch(data.notice_type)
        {
            case 'UP' : stateText = '업데이트'; stateClass='notice_update'; break;
            case 'SS' : stateText = '시스템'; stateClass='notice_inspection'; break;
            case 'EV' : stateText = '이벤트'; stateClass='notice_event'; break;
            //case '' : stateText = '공지'; stateClass='notice_notice'; break;
            //case '' : stateText = '점검'; stateClass='notice_inspection'; break;
        }

        this.title_lbl.setText(data.notice_title);
        this.state_lbl.setText(stateText);
        this.state_lbl.addClass(stateClass);

        if(data.is_last)
        {
            this.wrap_view.setStyle('border','none');
        }
    }

    // TFUNCTION: OnWrapViewClick: 해당 공지사항 관련 화면으로 이동하는 클릭이벤트 함수
	OnWrapViewClick(comp, info, e)
	{
		goPage('NoticeDetail', this.m_list_data);
	}

}

