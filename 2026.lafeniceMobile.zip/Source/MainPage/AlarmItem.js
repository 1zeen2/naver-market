
class AlarmItem extends AView
{
	constructor()
	{
		super()

		this.m_alarm_uid = null; // 알림ID
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.m_alarm_uid = data.alarm_uid;
// *알림 구분
// *제목
// *내용
// *시간
// *알림  ID
// *이동 PATH
        let img = '';

        switch(data.ddd) //알림 구분
        {
            case '' : img = 'Assets/alarm_Icon_gray.png';
            case '' : img = 'Assets/calendar_icon_blue.png';
            case '' : img = 'Assets/event_icon.png';
            case '' : img = 'Assets/mission_icon.png';
            case '' : img = 'Assets/ticket_Icon_red.png';
        }

        this.icon_img.setImage(img);
        this.state_lbl.setText();
        this.title_lbl.setText(data.title);
        this.subtext_lbl.setText(data.subtitle);
        this.agotime_lbl.setText(data.time);

        if(data.is_first)
        {
            const today = new Date();
            const yyyy = String(today.getFullYear());
            const mm = String(today.getMonth() + 1).padStart(2, '0');
            const dd = String(today.getDate()).padStart(2, '0');
            const str_date = yyyy + mm + dd;

            if(str_date == data.date) this.today_lbl.show();
            else this.today_lbl.hide();

            this.date_lbl.setText(this.FormatDate(data.date));
            this.date_flay.show();
        }
        else this.date_flay.hide();

        if(data.is_last)
        {
            this.bottom_view.addClass('alarm_last_bottom_border');
            this.bottom_view.removeClass('alarm_bottom_border');
        }
        else
        {
            this.bottom_view.addClass('alarm_bottom_border');
            this.bottom_view.removeClass('alarm_last_bottom_border');
        }
    }

    // TFUNCTION: FormatDate: yy.mm.dd 형식으로 return
    FormatDate(num)
    {
        if(!parseInt(num, 10)) return '';

        num+='';
        return num.substring(2,4)+'.'+num.substring(4,6)+'.'+num.substring(6,8);
    }
}

