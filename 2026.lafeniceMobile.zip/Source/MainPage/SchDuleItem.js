
class SchDuleItem extends AView
{
	constructor()
	{
		super()

        this.list_data = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.list_data = data;
        
        this.state_view.setStyle('background-color', data.color||'transparent');
        this.title_lbl.setText(data.calendar_title);
        this.starttime_lbl.setText(this.FormatTime(data.start_time));
        if(data.end_time)
        {
            this.time_between_lbl.show();
            this.endtime_lbl.show();
            this.endtime_lbl.setText(data.end_time ? this.FormatTime(data.end_time) : '');
        }
        else
        {
            this.time_between_lbl.hide();
            this.endtime_lbl.hide();
        }
        this.address_lbl.setText(data.place_name||'');

        if(data.place_name) this.comma_lbl.show();
        else                this.comma_lbl.hide();

        if(data.is_last)
        {
            this.wrap_view.setStyle('border','none');
        }

        if(data.has_review === 0)
        {
            this.go_review_btn.addClass('write_review_btn');
            this.go_review_btn.removeClass('show_review_btn');
            this.go_review_btn.setText('관람 기록 작성하기');
            // if(전시일정) this.point_info_view.show();
        }
        else
        {
            this.go_review_btn.addClass('show_review_btn');
            this.go_review_btn.removeClass('write_review_btn');
            this.go_review_btn.setText('작성한 기록 보러가기');
        }
    }

    // TFUNCTION: OnGoReviewBtnClick: 관람 기록 작성하기 및 확인하기 버튼 클릭 이벤트
	OnGoReviewBtnClick(comp, info, e)
	{
        if(this.go_review_btn.getText() == '관람 기록 작성하기')
        {
            this.AddReview();
        }
        else
        {
            this.ShowReview();
        }
	}

    // TFUNCTION: AddReview: 관람기록을 작성 후 추가한다.
    AddReview()
    {
        let view = new AWindow();
        
        view.setData({
            is_add: true,
            data: this.list_data
        });
        view.setResultCallback( result => {
            if(!result) return;
            
            this.go_review_btn.addClass('show_review_btn');
            this.go_review_btn.removeClass('write_review_btn');
            this.go_review_btn.setText('작성한 기록 보러가기');
            this.point_info_view.hide();

            this.CallbackFunction(this.owner.getRootView().className);
        });
        view.openFull("Source/CalendarPage/ViewingRecord.lay", this.getContainer());
    }

    // TFUNCTION: ShowReview: 관람기록을 조회한다.
    ShowReview()
    {
        let view = new AWindow();
        
        view.setData({
            is_add: false,
            data: this.list_data
        });
        view.setResultCallback( result => {
            if(!result) return;

            this.CallbackFunction(this.owner.getRootView().className);
        });
        view.openFull("Source/CalendarPage/ViewingDetail.lay", this.getContainer());
    }

    // TFUNCTION: FormatTime: 시간을 hh:mm 형식으로 출력하는 함수
    FormatTime(num)
    {
        return num.slice(0,2) + ':' + num.slice(2,4)
    }

    // TFUNCTION: OnWrapViewClick: 일정 클릭 이벤트 함수, 일정 상세 화면으로 이동
	OnWrapViewClick(comp, info, e)
	{
		let win = new AWindow();
        
        win.setData(this.list_data);
        win.setResultCallback( result => {
            if(!result) return;

            this.CallbackFunction(this.owner.getRootView().className);
        });
        win.openFull("Source/CalendarPage/ScheduleDetail.lay", this.getContainer());
	}

    // TFUNCTION: CallbackFunction: 윈도우창 열었다 닫았을 때 callback 함수
    CallbackFunction(class_name)
    {
        if(class_name == 'MainPage')
        {
            const today = new Date();
            const yyyy = String(today.getFullYear());
            const mm = String(today.getMonth() + 1).padStart(2,'0');
            const dd = String(today.getDate()).padStart(2,'0');

            this.owner.getRootView().GetSchedule(yyyy+mm+dd);
        }
        else if(class_name== 'CalenderMain')
        {
            const owner = this.owner.getRootView();

            if(owner.m_is_month)
            {
                if(Object.keys(owner.m_is_month).length === 0) return;

                let sta_key = Object.keys(owner.m_month_cache)[0];
                let end_key = Object.keys(owner.m_month_cache).at(-1);
                let last_day = owner.GetLastDateOfMonth(end_key.slice(0,4), end_key.slice(4,6));

                let sta_date = sta_key + '01';
                let end_date = end_key + String(last_day);

                owner.GetScheduleData(sta_date, end_date, true, ()=>{});
                owner.SetMonthData(true);
            }
            else
            {
                if(Object.keys(owner.m_day_cache).length === 0) return;

                let sta_date = Object.keys(owner.m_day_cache)[0];
                let end_date = Object.keys(owner.m_day_cache).at(-1);

                owner.GetScheduleData(sta_date, end_date, true, ()=>{});
                owner.SetWeekData(true);
            }
        }
    }
}

