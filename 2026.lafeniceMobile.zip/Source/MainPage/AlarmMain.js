
class AlarmMain extends AView
{
	constructor()
	{
		super()
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    // TFUNCTION: PrevBtn: 뒤로가기 버튼 클릭 이벤트
	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}

    // TFUNCTION: GetAlarm: 알림 데이터를 가져온다.
    async GetAlarm()
    {
        const res = await sendQuery('', '');

        this.banner_list.removeAllItems();

        if(res.error || res.length === 0)
        {
            this.no_data_view.show();
            this.data_view.hide();
        }
        else
        {
            this.no_data_view.hide();
            this.data_view.show();
            
            const map_data = res.map((obj, inx, arr) => {
                const prev = arr[inx - 1];
                const next = arr[inx + 1];

                return {
                    ...obj,
                    is_first: inx == 0 || prev.date !== obj.date,
                    is_last:  inx == (arr.length - 1) || next.date !== obj.date
                };
            });

            this.banner_list.addItem("Source/MainPage/AlarmItem.lay", map_data);
        }

        //console.log('system/advertisement result : ', res);
    };

    // TFUNCTION: OnDelBtnClick: 전체 삭제 버튼 이벤트
	OnDelBtnClick(comp, info, e)
	{
        let win = new AWindow(); //삭제하시겠습니까? 팝업

        // win.setResultCallback( result => {
        //     if(result)
        //     {
                this.DeleteAlarm();
        //     }
        // });
        // win.openCenter();
	}

    // TFUNCTION: DeleteAlarm: 알림을 삭제한다.
    async DeleteAlarm()
    {
        const res = await sendQuery('', '', {});

        console.log(res);

        if(!res.success || res.error)
        {
            AToast.show('삭제에 실패했습니다');
            return;
        }
        else
        {
            AToast.show('삭제 했습니다');
        }
    }

}

