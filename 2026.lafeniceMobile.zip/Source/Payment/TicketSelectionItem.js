
class TicketSelectionItem extends AView
{
	constructor()
	{
		super()

		this.amount = 0;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.SetItemData();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    SetItemData()
    {

        const _data = this.getItemData();

        this.type_lbl.setText(_data.type);
        this.price_lbl.setText(fmt_rules.number(_data.price, '원'));
    }


	Decrease(comp, info, e)
	{
        // 숫자가 아니거나 0 이하일 경우 0을 반환하여 음수 발생 방지
        if (isNaN(Number(this.amount)) || Number(this.amount) <= 0) {
            return 0;
        }
        
        return Number(this.amount) - 1;
	}

	Increase(comp, info, e)
	{
        return isNaN(Number(this.amount)) ? 1 : Number(this.amount) + 1;
	}

    ClickDecrease(comp, info, e)
    {
        const amount = this.Decrease();
        this.amount = amount;
        this.amount_lbl.setText(amount);
    }

	ClickIncrease(comp, info, e)
	{
		const amount = this.Increase();
        this.amount = amount;
        this.amount_lbl.setText(amount);
	}
}

