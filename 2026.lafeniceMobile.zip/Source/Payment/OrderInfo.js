class OrderInfo extends AView
{
	constructor()
	{
		super()

		this.product_type = 'TICKET';

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		if(this.product_type === 'TICKET') {
			this.delivery_view.element.remove();
		} else if(this.product_type === 'GOODS') {
			this.ticket_info_view.element.remove();
			this.ticket_barcode_view.element.remove();
		}

		this.SetStyle();
		this.CreateBarCode();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetPrductList();

	}

    SetStyle()
    {
        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }

    SetPrductList()
    {
        this.prd_list.addItem('Source/Payment/ProductList.lay', [1, 2]);
    }

	CreateBarCode()
	{
		JsBarcode(
			this.barcode_img.element, 
			'574832075849375849032758493', 
			{
				format: "CODE128",
				lineColor: "#000",
				height: 100,
				displayValue: true,
				fontSize: 14,
				font: "Pretendard", // 적용하고자 하는 폰트명
				fontOptions: "bold", // 굵기 설정 (bold, italic 등)
				textMargin: 8
			}
		);
	}

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}

