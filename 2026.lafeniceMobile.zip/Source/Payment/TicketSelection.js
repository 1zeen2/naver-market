
class TicketSelection extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

        this.SetStyle();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		const dummy_items = [
            {
                type: '성인',
                price: '15000',
            },
            {
                type: '청소년',
                price: '10000',
            },
            {
                type: '어린이',
                price: '5000',
            }
        ]

        this.list.addItem('Source/Payment/TicketSelectionItem.lay', dummy_items);

	}

    SetStyle()
    {
        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }


	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}

