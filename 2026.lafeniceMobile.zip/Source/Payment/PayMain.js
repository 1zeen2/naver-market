
class PayMain extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.SetStyle();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.AddTermsItems();
        this.AddProductItems();

	}

    AddProductItems()
    {
        this.product_list.addItem('Source/Payment/ProductList.lay', [1, 2]);
    }

    AddTermsItems()
    {
        //this.terms_list.addItem('Source/Payment/items/PaymentTermsList.lay', theApp._terms.filter(item => item.terms_type === 'PAYMENT'));
    }

    SetStyle()
    {
        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
}

