
class OrderList extends AView
{
	constructor()
	{
		super()

		this.last_item = '';
        this.select_type = '';
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.SetStyle();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetOrderList();
        this.OnChangeType(this.all_lbl);
	}

    SetOrderList()
    {
        this.OrderList.addItem('Source/Payment/OrderItem.lay', [1, 2, 3]);

        setTimeout(() => {
            if(this.last_item){    
                this.last_item.lastChild.style.marginBottom = '8px';
            } else {
                this.last_item = this.OrderList.getLastItem();
                if(this.last_item) this.last_item.lastChild.style.marginBottom = '0px';
            }
        }, 0);

    }

    SetStyle()
    {
        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }

	OnChangeType(comp, info, e)
	{

        if(this.select_type) {
            this.select_type.addClass('text-metal-400');    
            this.select_type.removeClass('text-pink-500');
        }
        
        this.select_type = comp;
        this.select_type.addClass('text-pink-500');
        this.select_type.removeClass('text-metal-400');

        const rect = comp.element.getBoundingClientRect();
        const bar = this.underbar_view;

        bar.setWidth(rect.width);
        bar.setStyleObj({
            transform: `translateX(${rect.x - 20}px)`
        })

	}

	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
    
}

