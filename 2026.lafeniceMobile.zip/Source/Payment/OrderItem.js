
class OrderItem extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetOrderItems();

	}

    SetOrderItems()
    {
        this.OrderList.addItem('Source/Payment/ProductList.lay', [1, 2]);
    }

}

