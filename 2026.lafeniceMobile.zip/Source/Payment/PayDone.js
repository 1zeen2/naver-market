
class PayDone extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.SetStyle();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		this.SetProductItems();
	}

    SetStyle()
    {
        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }

    SetProductItems()
    {
        this.product_list.addItem('Source/Payment/ProductList.lay', [1, 2]);
    }


	PrevBtn(comp, info, e)
	{
		goPrevPage();
	}
}

