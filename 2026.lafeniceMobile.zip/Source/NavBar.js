
class NavBar extends AView
{
	constructor()
	{
		super()

		this.select_page = '';

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		if(!this.select_page) {
            this.select_page = this.MainPage;
            this.ChangeNavStyle('add');
        }
        
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    OnChangePage(comp, info, e, is_pop=false)
    {
        
        if(this.select_page) {
            this.ChangeNavStyle('remove');
        } 

        this.select_page = comp;
        this.ChangeNavStyle('add');

        const parent_view = this.getContainerView();
        
        if(
            parent_view &&
            parent_view.content_view &&
            parent_view.content_view.ldView &&
            parent_view.content_view.ldView.onDeactive
        ) parent_view.content_view.ldView.onDeactive();

        parent_view.MovePage(comp.compId, null, is_pop);
    }

    ChangeNavStyle(type)
    {

        const select_nav = this.select_page.getElement();
        if (!select_nav) return; // 부모 객체 부재 시 중단

        const elements = [
            select_nav.querySelector('.nav-icon'),
            select_nav.querySelector('.nav-text')
        ];

        elements.forEach(item => {
            // 요소가 존재할 때만 실행하여 TypeError 방지
            if (item) {
                if (type === 'add') item.classList.add('select');
                else if (type === 'remove') item.classList.remove('select');
            }
        });
    }

}

