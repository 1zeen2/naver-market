
class OnBoarding extends AView
{
	constructor()
	{
		super()

        this.page = 1;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()
        this.OnChangeDot();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}


	NextBtn(comp, info, e)
	{

        if(this.page === 3) {
            goPage('AccessPermission', {});
            return;
        }

		this.page++;
        this.OnChangeDot();
    }

	PrevBtn(comp, info, e)
	{

        if(this.page === 1) {
            return;
        }

		this.page--;
        this.OnChangeDot();
	}

    OnChangeDot()
    {
        const wide_dot_width = 14;
        const dot_width = 4;
        const dot = {
            1: this.dot_01,
            2: this.dot_02,
            3: this.dot_03
        }

        for(const key in dot) {
            if(key == this.page) {
                dot[key].setWidth(wide_dot_width);
                dot[key].element.style.borderRadius = '10px';
                dot[key].element.style.backgroundColor = '#616678';
            } else {
                dot[key].setWidth(dot_width);
                dot[key].element.style.borderRadius = '50%';
                dot[key].element.style.backgroundColor = '#B0B5C5';
            }
        }
    }
    

	CancelBtn(comp, info, e)
	{
		goPage('TermsAgree', {});
	}
}

