
class Login extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this._data = this.getContainer().getData();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}


	RunLogin(comp, info, e)
	{
        loginWithKakao(this._data)
            .then(res => {
                sendQuery(
                    'auth', 
                    'social/login', 
                    {
                        provider: res.provider,
                        provider_id: res.providerId,
                        access_token: res.accessToken,
                        notice_agree: 'Y',
                        terms: this._data,
                    }
                )
                .then(res => {
                    if(!res || !res.accessToken) {
                        new AToast().show('로그인 세션이 만료되었습니다. 다시 로그인 해주세요.');
                        goPage('Login', {});
                    } else {
                        localStorage.setItem('refreshToken', res.refreshToken);
                        theApp.auth_session = res.user; //유저정보
                        goPage(res.isNew ? 'SignUpComplete' : 'MainPage', {}); //회원가입 완료 화면으로 이동 or 홈 화면으로 이동
                    }
                });

            }); 
	}
}

