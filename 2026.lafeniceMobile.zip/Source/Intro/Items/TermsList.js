
class TermsList extends AView
{
	constructor()
	{
		super()

        this.is_checked = false;

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this._data = this.getItemData();
        this.SetListData();
        this.SetStyle();
    }

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    //
    SetListData()
    {
        this.title.setText(`(${fmt_rules.required[this._data.is_required]})` + this._data.terms_title);       
    }


    //약관 상세화면 이동
	OpenDetail(comp, info, e)
	{

		const wnd = new AWindow();
        const url = 'Source/Intro/TermsDetail.lay';

        wnd.setData({...this._data});
        wnd.openFull(url, this.getContainer());


	}

    //체크박스 클릭
	ClickCbx(comp, info, e)
	{
        this.is_checked = !this.is_checked;

        if(this.is_checked) {
            this.cbx.removeClass('cbx');
            this.cbx.addClass('cbx_checked');
        } else {
            this.cbx.removeClass('cbx_checked');
            this.cbx.addClass('cbx');
        }

		const terms_view = this.getContainerView();
        terms_view.OnChangeAgreeTerms(this._data, this.is_checked);
	}

    SetStyle()
    {
        this.element.parentElement.classList.remove('listview-row');
    }
}   

