
class TermsDetail extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        this.SetTermsData();

	}


	PrevBtn(comp, info, e)
	{
		this.getContainer().close();
	}

    SetTermsData()
    {
        const data = this.getContainer().getData();
        
        this.title.setText(data.terms_title);
    }
}

