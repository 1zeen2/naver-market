
class TermsAgree extends AView
{
	constructor()
	{
		super()

        this.is_checked_all = false;
        this.terms = []; //모든 약관
		this.agree_terms = []; // 동의 약관
        this.disagree_terms = []; //미동의 약관
        this.required_terms = []; //필수 약관
	}   

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.SetStyle();
		this.GetTerms();

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here
	}

    SetStyle()
    {
        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }


	NextBtn(comp, info, e)
	{

        const is_next = this.ValidateRequired();

        if(this.agree_terms.length < 1 || !is_next) {
            new AToast().show('필수 약관을 모두 동의해주세요');
        } else if(is_next) {
            this.disagree_terms = this.terms.filter( item => !this.agree_terms.includes(item.terms_uid));
            
            const user_terms = [];

            this.disagree_terms.forEach(item => {
                const obj = {};
                obj.terms_uid = item.terms_uid;
                obj.agree = 'N';
                user_terms.push(obj);
            });

            this.agree_terms.forEach(item => {
                const obj = {};
                obj.terms_uid = item;
                obj.agree = 'Y';
                user_terms.push(obj);
            })

            goPage('Login', [ ... user_terms ]);
        } else {
            //
        }
	}

    ValidateRequired()
    {
        const agree_uid = new Set(this.agree_terms);
        const validate = this.required_terms.every(item => agree_uid.has(item));
        return validate;
    }

    GetTerms()
    {
        this.terms = theApp._terms.filter(item => item.terms_type === 'SIGNUP');
        
        // 선택 약관이 먼저 추가되도록 정렬 (N -> Y)
        this.terms.sort((a, b) => {
            if (a.is_required !== 'Y' && b.is_required === 'Y') return -1;
            if (a.is_required === 'Y' && b.is_required !== 'Y') return 1;
            return 0;
        });

        this.terms.forEach(item => {
            if(item.is_required === 'Y') this.required_terms.push(item.terms_uid);
            this.terms_list.addItem('Source/Intro/Items/TermsList.lay', [item]);
        })
    }

    OnChangeAgreeTerms(terms, checked)
    {
        if(checked) {
            // 중복 방지 추가
            if(!this.agree_terms.includes(terms.terms_uid)) {
                this.agree_terms.push(terms.terms_uid);
            }
        } else {
            this.agree_terms = this.agree_terms.filter(item => item !== terms.terms_uid);
        }

        // 전체 동의 상태 판단
        this.is_checked_all = (this.terms.length > 0 && this.agree_terms.length === this.terms.length);

        if(this.is_checked_all) {
            this.every_cbx.removeClass('cbx');
            this.every_cbx.addClass('cbx_checked');
        } else {
            this.every_cbx.removeClass('cbx_checked');
            this.every_cbx.addClass('cbx');
        }
    }

	OnClickEveryTerms(comp, info, e)
	{
        this.is_checked_all = !this.is_checked_all;

        if(this.is_checked_all) {
            this.every_cbx.removeClass('cbx');
            this.every_cbx.addClass('cbx_checked');
        } else {
            this.every_cbx.removeClass('cbx_checked');
            this.every_cbx.addClass('cbx');
        }

        this.agree_terms = [];

        const items = this.terms_list.getItems();
        for(let i=0; i<items.length; i++)
        {
            const item = items[i];
            const cbx = item.view.cbx;

            if(this.is_checked_all) {
                this.agree_terms.push(item.itemData.terms_uid);
                cbx.removeClass('cbx');
                cbx.addClass('cbx_checked');
            } else {
                cbx.removeClass('cbx_checked');
                cbx.addClass('cbx');
            }
            
            // 아이템 내부 상태 변수도 있다면 동기화 필요 (TermsList.js 구현에 따라 다름)
            if(item.view.UpdateState) item.view.UpdateState(this.is_checked_all);
        }
	}
}

