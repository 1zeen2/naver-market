
class Splash extends AView
{
	constructor()
	{
		super()

		this.is_pending = true;
        this.min_time = 2000;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        setTimeout(() => {
            this.is_pending = false;
        }, this.min_time);

	}

	async onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        await Promise.all([
            this.GetBsnsCode(),
            this.GetTermsList()
        ])
        .then(([bsns_code, terms_list]) => { 
            theApp._terms = terms_list;
            theApp._bsnsCode = bsns_code;
        })
        .then(async () => {
            const refresh_token = localStorage.getItem('refreshToken');
    
            if(refresh_token) {
                const is_refresh = 
                    await sendQuery(
                        'auth', 
                        'refresh', 
                        {refresh_token: refresh_token}
                    );
            
                if(is_refresh.accessToken && is_refresh.refreshToken && is_refresh.user) {
                    theApp.auth_session = is_refresh;
                    this.PendingThenMovePage('MainView');
                } else {
                    this.PendingThenMovePage('OnBoarding');
                }

            } else {
                this.PendingThenMovePage('OnBoarding');
            }
        })
	}

    PendingThenMovePage(page_name)
    {
        if(!this.is_pending) {
            goPage(page_name, {});
            setTimeout(() => {
                this.removeFromView();
            }, 800);
        }
        else {
            setTimeout(() => {
                this.PendingThenMovePage(page_name);
            }, 500);
        }
    }

    //비즈니스 코드 가져오는 함수
    async GetBsnsCode()
    {
        return await sendQuery('system', 'businessCode');
    }
    
    
    //앱에서 취급하는 모든 약관 리스트
    async GetTermsList()
    {
        return await sendQuery('system', 'terms')
    }

    
}

