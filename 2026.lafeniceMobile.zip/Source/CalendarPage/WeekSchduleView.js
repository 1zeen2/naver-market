
class WeekSchduleView extends AView
{
	constructor()
	{
		super()

		this.list_data = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

        // 그리드 각 뷰 클릭이벤트 추가(동적 생성할 때 addEventListner하면 owner(slide view)의 슬라이드가 안 먹힘)
        this.calendar_flay.element.addEventListener('click', (event) => {
            const parent = this.owner.getRootView();
            if(!parent) return;
            
            const target = event.target.closest('[data-date]');
            if(!target) return;

            if(parent && parent.m_slide_moved) return; //스와이프 직후 탭 튀는 것 방지

            this.SelectDateByTarget(target);
        });
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
	{
        this.list_data = data; //{year: 2026, month: 1, day: 23}
        this.m_week_list = this.GetWeekRange(data.year, data.month, data.day);

        this.SetDateView(this.m_week_list);

        const parent = this.owner.getRootView();

        // 한 번 조회한 주는 CalenderMain에 저장 (yyyyddmm: [] 로 저장)
        let is_data = true;
        for(let i=0; i<7; i++) {
            const yyyy = String(this.m_week_list[i].year);
            const mm = String(this.m_week_list[i].month).padStart(2, '0');
            const dd = String(this.m_week_list[i].day).padStart(2, '0');

            if(!parent.m_day_cache[yyyy+mm+dd]) //하나라도 없으면,
            {
                is_data = false;
                break;
            }
        }

        // CalenderMain에 데이터 저장이 안되어 있을 경우 일주일 치 재조회
        if(!is_data)
        {
            for(let j=0; j<7; j++) {
                const date = this[`date_${j}_view`].element.getAttribute('data-date');
                parent.m_day_cache[date] = []; //빈 배열로 초기화
            }

            const s_yyyy = String(this.m_week_list[0].year);
            const s_mm = String(this.m_week_list[0].month).padStart(2, '0');
            const s_dd = String(this.m_week_list[0].day).padStart(2, '0');
            const start_date = `${s_yyyy}${s_mm}${s_dd}`;

            const e_yyyy = String(this.m_week_list[6].year);
            const e_mm = String(this.m_week_list[6].month).padStart(2, '0');
            const e_dd = String(this.m_week_list[6].day).padStart(2, '0');
            const end_date = `${e_yyyy}${e_mm}${e_dd}`;

            parent.GetScheduleData(start_date, end_date, false, (res, res_data)=>{
                if(res)
                {
                    res_data.forEach((obj) => parent.m_day_cache[obj.calendar_date].push(obj))
                }

                this.SetDateViewSchedule();
                this.AutoSelectDay(this.list_data);
            });
        }
        else
        {
            this.SetDateViewSchedule();
            this.AutoSelectDay(this.list_data);
        }
	}

    // TFUNCTION: SelectDateByTarget: 날짜 뷰 클릭 동작 함수
    SelectDateByTarget(target)
    {
        const parent = this.owner.getRootView();
        if(!parent || !target) return;

        const date = target.getAttribute('data-date');
        const day_cache = parent.m_day_cache[date]; // []

        let color;

        if(!day_cache || day_cache.length <= 0)
        {
            parent.GetScheduleData(date, date, false, ()=>{});
        }
        else
        {
            parent.AddScheduleList(day_cache, date);
        }

        const all_dates = this.calendar_flay.element.querySelectorAll('[data-date]');
        all_dates.forEach((el, inx) => {
            if(inx % 7 == 0) color = '#EB3E69'
            else if(inx % 7 == 6) color = '#6363E7'
            else color = '#4B4F5C'

            el.children[0].style.color = color;
            el.children[0].style.backgroundColor = 'transparent';
        })
        target.children[0].style.color = '#F4F5F7';
        target.children[0].style.backgroundColor = '#E91E63';

        parent.m_select_date = date;
    }

    // TFUNCTION: AutoSelectDay: 매개변수로 넘어오는 데이터 날짜 선택하는 함수
    AutoSelectDay(data)
    {
        if(!data || !data.day) return;

        const parent = this.owner.getRootView();
        const yyyy = String(data.year);
        const mm = String(data.month).padStart(2,'0');
        const dd = String(data.day).padStart(2,'0');
    
        let date = '';

        if(data.is_select)
        {
            date = yyyy + mm + dd;
        }
        else
        {
            if(parent.m_select_date) date = parent.m_select_date;
            else                     date = yyyy + mm + dd;
        }

        const target = this.calendar_flay.element.querySelector(`[data-date="${date}"]`);
        if(!target) return;
        
        this.SelectDateByTarget(target);
    }

    // TFUNCTION: SetDateView: 그리드에 날짜 데이터를 셋팅해준다.
    SetDateView(week_list)
    {
        for(let i=0; i<week_list.length; i++) { //week_list = [{year:num, month:num, day:num},{}...]
            const yyyy = String(week_list[i].year);
            const mm = String(week_list[i].month).padStart(2, '0');
            const dd = String(week_list[i].day).padStart(2, '0');
            const view_date = yyyy + mm + dd ;

            this[`date_${i}_view`].element.setAttribute('data-date', view_date);
            this[`date_${i}_lbl`].setText(week_list[i].day);
        }
    }

    // TFUNCTION: SetDateViewSchedule: 날짜 뷰 안의 아이콘(dot) 등 셋팅하는 함수.
    SetDateViewSchedule()
    {
        for(let i=0; i<7; i++) {
            if( !this[`date_${i}_view`] ) break;

            const parent = this.owner.getRootView();

            const date = this[`date_${i}_view`].element.getAttribute('data-date');
            const day_data = parent.m_day_cache[date];
            
            if(!day_data || day_data.length <= 0) continue;

            day_data.forEach((obj, inx)=>{
                if(obj.calendar_date == date) // 데이터로 넘어온 날짜 == 클라이언트에서 만든 뷰의 날짜 (비교)
                {
                    let view = new AView();

                    view.init();
                    view.setStyleObj({
                        'width': '4px',
                        'height': '4px',
                        'border-radius': '100px',
                        'background-color': obj.color
                    });

                    this[`date_${i}_flay`].layComponent(view);
                    this[`plus_${i}_lbl`].setText('');
                }
            });
        }
    }

    // TFUNCTION: GetWeekRange: 받은 매개변수의 일자가 속한 주 날짜 데이터를 return하는 함수.
    GetWeekRange(year, month, day)
    {
        if(!year || !month || !day) return;

        const base = new Date(year, month - 1, day);
        const day_week = base.getDay(); // 0:일 ~ 6:토

        const sunday = new Date(base);
        sunday.setDate(base.getDate() - day_week);

        const week = [];

        for(let i = 0; i < 7; i++) {
            const date = new Date(sunday);
            date.setDate(sunday.getDate() + i);

            week.push({
                year: date.getFullYear(),
                month: date.getMonth() + 1,
                day: date.getDate()
            });
        }

        return week;
    }
}

