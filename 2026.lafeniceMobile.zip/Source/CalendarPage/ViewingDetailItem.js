
class ViewingDetailItem extends AView
{
	constructor()
	{
		super()
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
    {
        this.list_data = data;

        this.review_img.setImage(network.address.replace('/access', '') + data.file_path);
    }
}

