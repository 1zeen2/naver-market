
class MonSchduleView extends AView
{
	constructor()
	{
		super()

		this.list_data = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

        // 그리드 각 뷰 클릭이벤트 추가(동적 생성할 때 addEventListner하면 owner(slide view)의 슬라이드가 안 먹힘)
        this.calendar_grid.element.addEventListener('click', (event) => {
            const parent = this.owner.getRootView();
            if(!parent) return;
            
            const target = event.target.closest('[data-date]');
            if(!target) return;

            if(parent && parent.m_slide_moved) return; //스와이프 직후 탭 튀는 것 방지

            this.SelectDateByTarget(target);
        });
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    setData(data)
	{
        this.list_data = data;

        const parent = this.owner.getRootView();
		const start_week = this.GetFirstDayOfWeek(data.year, data.month);
		const last_date = this.GetLastDateOfMonth(data.year, data.month);

        const yyyy = String(this.list_data.year);
        const mm = String(this.list_data.month).padStart(2, '0');
        const dd = String(last_date).padStart(2, '0');

        this.SetDateView(start_week, last_date, data.year, data.month);

        // 한 번 조회한 달은 CalenderMain에 저장
        if(!parent.m_month_cache[yyyy+mm])
        {
            parent.GetScheduleData(`${yyyy}${mm}01`, `${yyyy}${mm}${dd}`, false, (res, data)=>{
                if(res)
                {
                    parent.m_month_cache[yyyy+mm] = data||[];
                    this.SetDateViewSchedule(data||[])
                }
                else parent.m_month_cache[yyyy+mm] = [];
            });
        }
        else
        {
            this.SetDateViewSchedule(parent.m_month_cache[yyyy+mm])
        }

        this.AutoSelectDay(data);
	}

    // TFUNCTION: SelectDateByTarget: 날짜 뷰 클릭 동작 함수
    SelectDateByTarget(target)
    {
        const parent = this.owner.getRootView();
        if(!parent || !target) return;

        const date = target.getAttribute('data-date');
        const month_cache = parent.m_month_cache[date.slice(0,6)];

        let color;

        if(!month_cache)
        {
            parent.GetScheduleData(date, date, true, ()=>{});
        }
        else
        {
            const filtering = month_cache.filter((obj) => obj.calendar_date == date);
            parent.AddScheduleList(filtering, date);
        }

        const all_dates = this.calendar_grid.element.querySelectorAll('[data-date]');
        all_dates.forEach((el, inx) => {
            if(inx % 7 == 0) color = '#EB3E69'
            else if(inx % 7 == 6) color = '#6363E7'
            else color = '#4B4F5C'

            el.children[0].style.color = color;
            el.children[0].style.backgroundColor = 'transparent';
        })
        target.children[0].style.color = '#F4F5F7';
        target.children[0].style.backgroundColor = '#E91E63';

        parent.m_select_date = date;
    }

    // TFUNCTION: AutoSelectDay: 매개변수로 넘어오는 데이터 날짜 선택하는 함수
    AutoSelectDay(data)
    {
        if(!data || !data.day) return;

        const yyyy = String(this.list_data.year);
        const mm = String(this.list_data.month).padStart(2,'0');
        const dd = String(this.list_data.day).padStart(2,'0');
        const date = yyyy + mm + dd;

        setTimeout(() => {
            const target = this.calendar_grid.element.querySelector(`[data-date="${date}"]`);
            if(!target) return;

            this.SelectDateByTarget(target);
        }, 0);
    }

    // TFUNCTION: SetDateView: 그리드에 날짜 뷰를 추가해준다.
    SetDateView(start_inx, last_inx, year, month)
    {
        const td_list = this.calendar_grid.element.querySelectorAll("tbody td");
        td_list.forEach(td => td.innerHTML = ""); // td 전체 비우기

        const limit = ((start_inx + last_inx) <= 35) ? 35 : td_list.length; // 달력이 5칸에서 끝나는 경우 6번째 줄에는 td추가X

        const prev = this.GetPrevYearMonth(year, month);
        const prev_last = this.GetLastDateOfMonth(prev.year, prev.month);

        const next = this.GetNextYearMonth(year, month);
        
        // 이전 달
        for(let previ = 0; previ < start_inx; previ++)
        {
            const day = prev_last - (start_inx - 1 - previ);
            const wrap_view = this.MakeDateView(day, previ, prev.year, prev.month, true, limit);

            td_list[previ].appendChild(wrap_view.element);
        }

        // 현재 달
        for(let nowi = 1; nowi <= last_inx; nowi++)
        {
            const td_inx = start_inx + nowi - 1;
            if(td_inx >= limit) break;
            if(!td_list[td_inx]) break;

            const wrap_view = this.MakeDateView(nowi, td_inx, year, month, false, limit);
            td_list[td_inx].appendChild(wrap_view.element);
        }

        // 다음 달
        let next_day = 1;
        for(let nexti = start_inx + last_inx; nexti < limit; nexti++)
        {
            const wrap_view = this.MakeDateView(next_day, nexti, next.year, next.month, true, limit);
            td_list[nexti].appendChild(wrap_view.element);
            next_day++;
        }
    }

    // TFUNCTION: MakeDateView: 그리드에 들어갈 날짜 뷰를 동적생성해준다.
    MakeDateView(day, week, year, month, is_other_month, limit)
    {
        const yy = String(year);
        const mm = String(month).padStart(2, '0');
        const dd = String(day).padStart(2, '0');

        const view_date = yy+mm+dd;

        let color = '#4B4F5C';
            if(week % 7 == 0) color = '#EB3E69'
            else if(week % 7 == 6) color = '#6363E7'
        
        let height = '54px';
            if(limit <= 35) height = '64px';
        
        let opacity = '1';
            if(is_other_month) opacity = '0.3';

        let wrap_view = new AView();
            wrap_view.init();
            wrap_view.setStyleObj({
                'width': '100%',
                'height': height,
                'position': 'relative',
                'left': '0px',
                'top': '0px',
                'background-color': 'rgba(0, 0, 0, 0)',
                'opacity': opacity
            });
            wrap_view.element.setAttribute('data-date', view_date);
            wrap_view.element.setAttribute('data-week', week);

        let date_lbl = new ALabel();
            date_lbl.init();
            date_lbl.setStyleObj({
                'width': '22px',
                'height': '22px',
                'color': color,
                'position': 'absolute',
                'left': 'calc(50% - 10px)',
                'top': '6px',
                'text-align': 'center',
                'font-size': '13px',
                'font-weight': '600',
                'line-height': '24px',
                'border-radius': '100px'
            });
            date_lbl.setText(day);
            
        let date_flay = new AFlexLayout();
            date_flay.init();
            date_flay.setStyleObj({
                'width': '100%',
                'height': 'auto',
                'min-height': '10px',
                'position': 'absolute',
                'align-items': 'center',
                'justify-content': 'center',
                'left': '0px',
                'bottom': '18px',
                'gap': '2px',
                'flex-wrap': 'wrap'
            });

        let plus_lbl = new ALabel();
            plus_lbl.init();
            plus_lbl.setStyleObj({
                'width': '100%',
                'height': 'auto',
                'position': 'absolute',
                'left': '0px',
                'bottom': '4px',
                'text-align': 'center',
                'font-size': '8px',
                'color': 'rgb(150, 156, 172)'
            });
            plus_lbl.setText('');

            if(!is_other_month)
            {
                wrap_view.compId = `date_${day}_view`;
                this[`date_${day}_view`] = wrap_view;

                date_lbl.compId = `date_${day}_lbl`;
                this[`date_${day}_lbl`] = date_lbl;

                date_flay.compId = `date_${day}_flay`;
                this[`date_${day}_flay`] = date_flay;

                plus_lbl.compId = `plus_${day}_lbl`;
                this[`plus_${day}_lbl`] = plus_lbl;
            } 

            wrap_view.addComponent(date_lbl);
            wrap_view.addComponent(date_flay);
            wrap_view.addComponent(plus_lbl);

            return wrap_view;
    }

    // TFUNCTION: SetDateData: 선택한 일자 데이터 조회 및 셋팅하는 함수.
    SetDateData()
    {

    }
    
    // TFUNCTION: SetDateViewSchedule: 날짜 뷰 안의 아이콘(dot) 등 셋팅하는 함수.
    SetDateViewSchedule(data)
    {
        if(!data || data.length === 0) return;

        for(let i=0; i<31; i++) {
            if( !this[`date_${i+1}_view`] ) break;

            const view_id = this[`date_${i+1}_view`];
            const date = view_id.element.getAttribute('data-date');

            data.forEach((obj, inx)=>{
                if(obj.calendar_date == date) // 데이터로 넘어온 날짜 == 클라이언트에서 만든 뷰의 날짜 (비교)
                {
                    let view = new AView();

                    view.init();
                    view.setStyleObj({
                        'width': '4px',
                        'height': '4px',
                        'border-radius': '100px',
                        'background-color': obj.color
                    });

                    this[`date_${i+1}_flay`].layComponent(view);
                    this[`plus_${i+1}_lbl`].setText('');
                }
            });
        }
    }

    // TFUNCTION: GetFirstDayOfWeek: 각 연도/월의 첫째날 요일을 구하는 함수.
    GetFirstDayOfWeek(year, month)
    {
        if(!year || !month) return;

        return new Date(year, month - 1, 1).getDay();
    }

    // TFUNCTION: GetLastDateOfMonth: 각 연도/월의 마지막 일자를 구하는 함수.
    GetLastDateOfMonth(year, month)
    {
        if(!year || !month) return;

        return new Date(year, month, 0).getDate();
    }

    // TFUNCTION: GetPrevYearMonth: 이전 달의 연도와 달을 구하는 함수
    GetPrevYearMonth(year, month)
    {
        if(month === 1) return { year: year - 1, month: 12 };

        return { year, month: month - 1 };
    }

    // TFUNCTION: GetNextYearMonth: 다음 달의 연도와 달을 구하는 함수
    GetNextYearMonth(year, month)
    {
        if(month === 12) return { year: year + 1, month: 1 };

        return { year, month: month + 1 };
    }

}

