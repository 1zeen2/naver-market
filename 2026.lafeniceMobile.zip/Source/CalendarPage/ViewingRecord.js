
class ViewingRecord extends AView
{
	constructor()
	{
		super()

        this.m_get_data = null;     // 받은 데이터 저장
        this.m_is_add = true;       // 등록/수정여부 true:등록(추가), false:수정
		this.m_old_pictures = [];   // 기존 첨부 이미지 목록
		this.m_pictures = [];       // 첨부 이미지 목록
        this.m_pic_max = 5;         // 최대 첨부 이미지 개수
        this.m_calendar_uid = null; // 일정ID
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

        this.m_get_data = this.getContainer().getData();
        this.m_is_add = this.m_get_data.is_add;
        this.m_calendar_uid = this.m_get_data.data.calendar_uid;
        this.m_old_pictures = this.m_get_data; //.@@@@@@@@@@@@@@@@@@

        if(this.m_is_add)
        {
            this.title_lbl.setText('관람 기록 작성');
            this.ok_btn.setText('등록하기');
            this.point_info_view.show();
        }
        else
        {
            this.title_lbl.setText('관람 기록 수정');
            this.ok_btn.setText('수정하기');
            this.point_info_view.hide();
        }
        this.SetData(this.m_get_data);

        this.pic_upload_txf.element.setAttribute('type', 'file');
        this.pic_upload_txf.element.setAttribute('accept', 'image/*');
        this.pic_upload_txf.element.setAttribute('multiple', 'multiple'); // 여러 장 선택 가능
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    // TFUNCTION: SetData: 전시 데이터 및 기존 데이터를 셋팅하는 함수
    SetData(data)
    {
        this.thumbnail_img.setImage();
        this.title_lb.setText();
        this.subtext_lbl.setText();

        if(!this.m_is_add)
        {
            this.RenderPictures();
            this.memo_txa.setText(data.memo);
        }
    }
    
	// TFUNCTION: OnBackBtnClick: 뒤로가기 버튼
	OnBackBtnClick(comp, info, e)
	{
		this.getContainer().close();
	}

    // TFUNCTION: OnAddpicBtnClick: 사진 추가하기 버튼 클릭 이벤트
	OnAddpicBtnClick(comp, info, e)
	{
		this.pic_upload_txf.setText('');
        this.pic_upload_txf.element.value = '';;

        if(this.m_pictures.length >= 5) return new AToast().show('최대 첨부 개수는 5개입니다');

        this.pic_upload_txf.element.click();
	}

    // TFUNCTION: OnPicUploadTxfChange: 이미지 추가하기
	OnPicUploadTxfChange(comp, info, e)
	{
		const input = this.pic_upload_txf.element;

        const files = Array.from(input.files || []);
        if(files.length === 0) return;

        const remain = this.m_pic_max - this.m_pictures.length;

        if(remain <= 0)
        {
            AToast.show('최대 첨부 개수는 5개입니다');
            input.value = '';
            return;
        }

        const picked = files.slice(0, remain);

        picked.forEach((file) => {
            if(!file.type || !file.type.startsWith('image/')) // 이미지 파일만
            {
                AToast.show('이미지 파일만 첨부할 수 있어요');
                return;
            }

            // (선택) 용량 제한 예: 10MB
            const limit = 10 * 1024 * 1024;
            if(file.size > limit)
            {
                AToast.show('10MB 이하 이미지만 첨부할 수 있어요');
                return;
            }

            const is_same_pic = this.m_pictures.some(pic =>
                pic.name === file.name &&
                pic.size === file.size &&
                pic.file.lastModified === file.lastModified
            );
            if(is_same_pic)
            {
                AToast.show('중복된 사진은 첨부할 수 없습니다');
                return;
            }

            const url = URL.createObjectURL(file);
            if(!is_same_pic)
            {
                this.m_pictures.push({
                    file,
                    url,
                    name: file.name,
                    size: file.size,
                    type: file.type
                });

                this.RenderPictures(file, url);
            }
        });

        input.value = '';
	}

    // TFUNCTION: RenderPictures: 첨부한 이미지 미리보기 뷰에 셋팅해주는 함수
    RenderPictures(file, url)
    {
        file.url = url;

        let view = new AView();
            view.init();
            view.setStyleObj({
                'width': '100px',
                'height': '100px',
                'position': 'relative',
                'left': '0px',
                'top': '0px',
                'margin': '0 10px 10px 0'
            });
            view.addClass('border-metal-100 radius-8');
            view.file_data = file;

        let img = new AImage();
            img.init();
            img.setStyleObj({
                'width': '100%',
                'height': '100%',
            });
            img.setImage(url);
            img.file_data = file;
        
        let btn = new AButton();
            btn.init();
            btn.setStyleObj({
                'width': '18px',
                'height': '18px',
                'top': '5px',
                'right': '5px',
            });
            btn.setText('');
            btn.addClass('pic_delete_btn');
            btn.addEventListener('click', this, 'OnDeletePicture');

        view.addComponent(img);
        view.addComponent(btn);
        
        if(this.pic_flay.getAllLayoutComps().length <= 1)
        {
            this.pic_flay.layComponent(view);
        }
        else
        {
            this.pic_flay.layComponent(view, 1);
        }
        
        const cnt = this.m_pictures.length;

        this.pic_cnt_lbl.setText(cnt);
        if(cnt == this.m_pic_max) this.addpic_btn.hide();
        else this.addpic_btn.show();
    }

    // TFUNCTION: OnDeletePicture: 첨부 이미지 삭제 버튼 클릭 이벤트
    OnDeletePicture(comp, info, e)
    {
        const inx = this.pic_flay.getCompIndex(comp.getParent());
        const del_ele = this.pic_flay.element.children[inx];
        const del_view = this.pic_flay.getAllLayoutComps()[inx];
        const del_url = del_view.file_data.url;

        this.pic_flay.element.removeChild(del_ele);
        this.addpic_btn.show();

        URL.revokeObjectURL(del_url);
        this.m_pictures = this.m_pictures.filter(obj => del_view.file_data.url !== obj.url ); // 배열에서 삭제

        this.pic_cnt_lbl.setText(this.m_pictures.length);
    }

    // TFUNCTION: Validation: 유효성 검사
    Validation()
    {
        if(this.m_pictures.length === 0)
        {
            AToast.show('이미지를 한 장 이상 첨부해주세요');
            return false;
        }
        else if(!this.memo_txa.getText())
        {
            AToast.show('메모를 입력해주세요');
            return false;
        }
        else return true;
    }

    // TFUNCTION: OnOkBtnClick: 등록 및 수정 버튼 클릭
	OnOkBtnClick(comp, info, e)
	{
		let validation =  this.Validation();

        if(validation)
        {
            if(this.m_is_add) this.AddViewing();
            else this.UpdateViewing();
        }
	}

    // TFUNCTION: AddViewing: 관람기록을 등록한다.
    async AddViewing()
    {
        const form_data = new FormData();

        this.m_pictures.forEach((pic) => {
            form_data.append('files', pic.file);
        });
        form_data.append('review_comment', this.memo_txa.getText());
        form_data.append('calendar_uid', this.m_calendar_uid);

        const res = await sendQuery('calendar', 'reviewReg', {}, form_data);

        console.log(res);

        if(res.error || !res.success)
        {
            AToast.show('등록에 실패했습니다');
            return;
        }
        else
        {
            AToast.show('등록되었습니다');
            this.getContainer().close(true, res);
        }
    }

    // TFUNCTION: UpdateViewing: 관람기록을 수정한다.
    async UpdateViewing()
    {
        const form_data = new FormData();

        this.m_pictures.forEach((pic) => {
            form_data.append('newFiles', pic.file);
            form_data.append('deleteFilesUid', pic.file);
        });
        form_data.append('review_comment', this.memo_txa.getText());
        form_data.append('calendar_uid', this.m_calendar_uid);

        const res = await sendQuery('calendar', 'reviewUpd', {}, form_data);

        if(res.error || !res.success)
        {
            AToast.show('수정에 실패했습니다');
            return;
        }
        else
        {
            AToast.show('수정되었습니다');
            this.getContainer().close(true, res);
        }
    }
}

