
class ScheduleDetail extends AView
{
	constructor()
	{
		super()

        this.m_data = null;             // 조회한 데이터
        this.m_get_data = null;         // 받은 데이터
        this.m_is_showin = false;       // 전시일정 여부 true:전시 false:캘린더
        this.m_calendar_uid = null;     // 일정ID
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

        this.m_get_data = this.getContainer().getData();
        this.m_calendar_uid = this.m_get_data.calendar_uid;

        if(false/*showin*/) //전시 일정 등록
        {
            this.m_is_showin = true;
            this.showin_view.show();
            this.shiwinline_view.show();
            this.review_btn.show();
        }
        else
        {
            this.m_is_showin = false;
            this.showin_view.hide();
            this.shiwinline_view.hide();
            this.review_btn.hide();
        }
        
		this.GetDetailScheduleData();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        if(this.m_map)
        {
            this.m_map.relayout();

            const pos = this.m_marker ? this.m_marker.getPosition() : this.m_map.getCenter();
            this.m_map.setCenter(pos);
        }
	}

    // TFUNCTION: OnBackBtnClick: 뒤로가기 버튼
	OnBackBtnClick(comp, info, e)
	{
		this.getContainer().close();
	}

    // TFUNCTION: GetDetailScheduleData: 일정 상세 데이터를 조회한다.
    async GetDetailScheduleData()
    {
        const res = await sendQuery('calendar', 'detail', {calendar_uid : this.m_calendar_uid});

        console.log(res);

        if(res.error || res.length === 0)
        {
            AToast.show('조회에 실패했습니다');
            return;
        }
        else
        {
            this.m_data = res;
            this.title_lb.setText(res.calendar_title);
            this.subtext_lbl.setText(res.road_address_name + res.address_detail);
            this.date_lbl.setText(res.calendar_date);
            this.week_lbl.setText(this.GetDayOfWeek(res.calendar_date));
            this.sta_time_lbl.setText(this.FormatTime(res.start_time));
            if(res.end_time)
            {
                this.between_time_lbl.show();
                this.end_time_lbl.show();
                this.end_time_lbl.setText(this.FormatTime(res.end_time));
            }
            else
            {
                this.between_time_lbl.hide();
                this.end_time_lbl.hide();
            }
            this.address_lbl.setText(res.place_name);
            this.memo_txb.setText(res.memo);
            this.InitMap(res.latitude, res.longitude);

            if(this.m_is_showin)
            {
                this.sta_date.setText();
                this.end_date.setText();
                this.price_lbl.setText();
                this.infotext_txb.setText();

                if(res.has_review){}
            }
        }
    }

    // TFUNCTION: InitMap: 지도 셋팅
    InitMap(lat, lng)
    {
        if(!window.kakao || !kakao.maps || !kakao.maps.LatLng || !kakao.maps.Map)
        {
            console.log('Kakao Map SDK 미로드: 지도 스킵');
            return;
        }

        const container = this.map_view.element;
        const center = new kakao.maps.LatLng(lat, lng);

        this.m_map = new kakao.maps.Map(container, {
            center,
            level: 3
        });

        // 마커
        //this.m_marker = new kakao.maps.Marker({ position: center });
        //this.m_marker.setMap(this.m_map);
    }

    // TFUNCTION: OnDelBtnClick: 삭제하기 버튼 클릭 이벤트
	OnDelBtnClick(comp, info, e)
	{
		let win = new AWindow(); //삭제하시겠습니까? 팝업

        // win.setResultCallback( result => {
        //     if(result)
        //     {
                this.DeleteSchedule();
        //     }
        // });
        // win.openCenter();
	}

    // TFUNCTION: DeleteSchedule: 일정을 삭제한다.
    async DeleteSchedule()
    {
        const res = await sendQuery('calendar', 'delete', {calendar_uid : this.m_calendar_uid});

        console.log(res);

        if(!res.success || res.error)
        {
            AToast.show('삭제에 실패했습니다');
            return;
        }
        else
        {
            AToast.show('일정을 삭제 했습니다');
            this.getContainer().close(true);
        }
    }

    // TFUNCTION: OnUpdateBtnClick: 수정하기 버튼 클릭 이벤트
	OnUpdateBtnClick(comp, info, e)
	{
        let win = new AWindow();

        win.setData({
            is_add: false,
            data : this.m_data
        });
        win.setResultCallback( result => {
            if(result)
            {
                this.GetDetailScheduleData();
            }
        });
        win.openFull("Source/CalendarPage/ScheduleRegist.lay", this.getContainer());
	}

    // TFUNCTION: FormatTime: 시간을 hh:mm 형식으로 출력한다.
    FormatTime(time)
    {
        return time.slice(0, 2) + ':' + time.slice(2, 4);
    }

    // TFUNCTION: GetDayOfWeek: 매개변수(ymd) 일자의 요일을 구한다.
    GetDayOfWeek(ymd)
    {
        const y = Number(ymd.slice(0, 4));
        const m = Number(ymd.slice(4, 6)) - 1;
        const d = Number(ymd.slice(6, 8));

        const date = new Date(y, m, d);
        const days = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];

        return days[date.getDay()];
    }
}

