
class ViewingDetail extends AView
{
	constructor()
	{
		super()

		this.m_data = null;             // 조회한 데이터
        this.m_get_data = null;         // 받은 데이터
        this.m_calendar_uid = null;     // 일정ID
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

		this.m_get_data = this.getContainer().getData().data;
        this.m_calendar_uid = this.m_get_data.calendar_uid;

        this.thumbnail_img.setImage();
        this.title_lb.setText();
        this.subtext_lbl.setText();

        this.GetDetailReviewData();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}
	
    // TFUNCTION: OnBackBtnClick: 뒤로가기 버튼
	OnBackBtnClick(comp, info, e)
	{
		this.getContainer().close();
	}

    // TFUNCTION: GetDetailReviewData: 관람 기록 데이터를 조회한다.
    async GetDetailReviewData()
    {
        const res = await sendQuery('calendar', 'review', {calendar_uid : this.m_calendar_uid});

        console.log(res);

        if(res.error || res.length === 0)
        {
            AToast.show('조회에 실패했습니다');
            return;
        }
        else
        {
            this.m_data = res[0];
            // this.thumbnail_img.setImage(this.m_data.);
            // this.title_lb.setText(this.m_data.);
            //this.subtext_lbl.setText(this.m_data.);
            this.review_txb.setText(this.m_data.review_comment);
            this.point_lbl.setText(`+${ADataMask.Number.money.func(this.m_data.review_earned_point)}P`);
            this.SetImg(this.m_data.files, 0);
        }
    }

    // TFUNCTION: SetImg: 조회된 이미지 셋팅
    SetImg(files, sel_inx)
    {
        files.forEach((obj, inx) => {
    console.log('obj : ',obj);
            // // 이미지 셋팅
            this.img_list.removeAllItems();
            this.img_list.addItem("Source/CalendarPage/ViewingDetailItem.lay", [obj]);

            // 이미지 하단 dot 셋팅
            let select_inx = sel_inx ? sel_inx : 0;
            let style_class = (inx == select_inx) ? 'newexh_dot_select' : 'newexh_dot_noselect';
            let btn = new AButton();
                btn.init();
                btn.setStyleObj({
                    'height': '4px',
                    'position': 'relative',
                    'left': '0px',
                    'top': '0px',
                    'border-radius': '100px',
                    'transition': 'all'
                });
                btn.compId = `dot_${inx+1}_btn`;
                this[`dot_${inx+1}_btn`] = btn;
                btn.setText('');
                btn.addEventListener('click', this, 'OnSelectImg');
                btn.setDefStyle(style_class);
                btn.setBtnStyle(AButton.DOWN, style_class);
                btn.defaultBtnState();

            this.img_dot_flay.layComponent(btn);
        })
    }

    //TFUNCTION: OnSelectImg: 이미지 dot 클릭 이벤트
    OnSelectImg(comp, info, e)
    {
        let comp_inx = Number(comp.compId.split('_')[1]) - 1;
        let comp_left = this.img_list.getItem(comp_inx).offsetLeft;

        this.img_list.setSelectItem(comp_inx);
        this.img_list.scrollTo(comp_left);

        this.SetNewImgDot(comp_inx);
    }

    //TFUNCTION: OnImgListScroll: 이미지 리스트 스크롤 이벤트
    OnImgListScroll(comp, info, e)
	{
		const scroller = this.img_list.element.children[0];
        const scroll_left = scroller.scrollLeft;
        const page_width = scroller.clientWidth;
        
        let near_inx = Math.round(scroll_left / page_width);

        const max_inx = this.img_list.getItemCount() - 1;
        near_inx = Math.max(0, Math.min(near_inx, max_inx)); // 인덱스가 범위를 벗어나지 않도록.

        this.img_list.setSelectItem(near_inx);
        this.SetNewImgDot(near_inx);
	}

    // TFUNCTION: SetNewImgDot: 이미지 dot 셋팅
    SetNewImgDot(inx)
    {
        this.img_dot_flay.getAllLayoutComps().filter((item,index)=>{
            if(inx == index)
            {
                //item.setData(true);
                item.removeClass('newexh_dot_noselect');
                item.addClass('newexh_dot_select');
            }
            else
            {
                //item.setData(false);
                item.removeClass('newexh_dot_select');
                item.addClass('newexh_dot_noselect');
            }
        })
    }

    // TFUNCTION: OnDelBtnClick: 삭제하기 버튼 클릭 이벤트
	OnDelBtnClick(comp, info, e)
	{
		let win = new AWindow(); //삭제하시겠습니까? 팝업

        // win.setResultCallback( result => {
        //     if(result)
        //     {
                this.DeleteReview();
        //     }
        // });
        // win.openCenter();
	}

    // TFUNCTION: DeleteReview: 관람내역을 삭제한다.
	async DeleteReview(comp, info, e)
	{
		const res = await sendQuery('calendar', 'delete', {calendar_uid : this.m_calendar_uid});

        console.log(res);

        if(!res.success || res.error)
        {
            AToast.show('삭제에 실패했습니다');
            return;
        }
        else
        {
            AToast.show('관람내역을 삭제 했습니다');
            this.getContainer().close(true);
        }
	}

    // TFUNCTION: OnUpdateBtnClick: 수정하기 버튼 클릭 이벤트
	async OnUpdateBtnClick(comp, info, e)
	{
		let win = new AWindow();

        win.setData({
            is_add: false,
            data : this.m_data
        });
        win.setResultCallback( result => {
            if(result)
            {
                this.GetDetailReviewData();
            }
        });
        win.openFull("Source/CalendarPage/ViewingRecord.lay", this.getContainer());
	}

}

