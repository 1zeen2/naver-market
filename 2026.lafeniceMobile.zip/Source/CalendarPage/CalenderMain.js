
class CalenderMain extends AView
{
	constructor()
	{
		super()

        this.m_slide_moved = false;
        this.m_slideReset_timer = null;

        this.m_month_cache = {};        //'202601':[]... 조회한 월별 데이터 저장
        this.m_day_cache = {};          //'20260101':[]... 조회한 일별 데이터 저장

        this.m_startY = null;           //슬라이드바 시작 y값
        this.m_start_height = null;     //슬라이드바 시작 height값

        this.m_is_month = true;         //true면 월별, false면 주별
        this.m_select_date = '';        //현재 선택 중인 날짜 'yyyymmdd'
        this.m_is_bottom_sheet_open = false; // Add this line
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

        this.SetMonthData();
        //this.SetWeekData();
        this.m_is_bottom_sheet_open = false;
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        if(!isFirst && this.getContainer().getData())
        {
            this.SetMonthData();
            this.SetWeekData();
        }
        //this.schedule_view.setStyle('height', `calc(100% - ${this.month_slide.getHeight()}px)`);
	}

    // TFUNCTION: SetMonthData: 월별 데이터 셋팅
    SetMonthData(select)
    {
        const today = new Date();
        const get_data = this.getContainer().getData(); //{year:num, month:num, day:num}
        let ym = {};

        if(select) // 월별 버튼 클릭 시
        {
            let sel_date = this.m_select_date;

            if(sel_date)
            {
                ym.year = Number(sel_date.slice(0,4));
                ym.month = Number(sel_date.slice(4,6));
                ym.day = Number(sel_date.slice(6,8));
            }
            else
            {
                ym.year = today.getFullYear();
                ym.month = today.getMonth() + 1;
                ym.day = today.getDate();
            }
        }
        else
        {
            ym.year = today.getFullYear();
            ym.month = today.getMonth() + 1;

            if(get_data && get_data.day)
            {
                if((ym.year == get_data.year) && (ym.month == get_data.month)) ym.day = get_data.day;
            }
            else ym.day = today.getDate();
        }

        const yms_data = [
            this.GetTodayYM(ym, -2),
            this.GetTodayYM(ym, -1),
            ym,
            this.GetTodayYM(ym, +1),
            this.GetTodayYM(ym, +2),
        ];
        
        // 월별 달력 셋팅
        this.month_slide.removeAllItems();
		this.month_slide.addItem("Source/CalendarPage/MonSchduleView.lay", yms_data, false);
        this.month_slide.slideTo(2);
    }

    // TFUNCTION: SetWeekData: 주별 데이터 셋팅
    SetWeekData(select)
    {
        const today = new Date();
        const get_data = this.getContainer().getData(); //{year:num, month:num, day:num}
        let ymd = {};

        if(select) // 주별 버튼 클릭 시
        {
            let sel_date = this.m_select_date;

            if(sel_date)
            {
                ymd.year = Number(sel_date.slice(0,4));
                ymd.month = Number(sel_date.slice(4,6));
                ymd.day = Number(sel_date.slice(6,8));
            }
            else
            {
                ymd.year = today.getFullYear();
                ymd.month = today.getMonth() + 1;
                ymd.day = today.getDate();
            }
        }
        else
        {
            ymd.year = today.getFullYear();
            ymd.month = today.getMonth() + 1;
            ymd.day = today.getDate();

            if(get_data && get_data.day)
            {
                if((ymd.year == get_data.year) && (ymd.month == get_data.month)) ymd.day = get_data.day;
            }

            ymd.is_select = true;
        }

        const ymd_data = [
            this.GetWeekYM(ymd, -1),
            ymd,
            this.GetWeekYM(ymd, +1),
        ];

        // 주별 달력 셋팅
        this.week_slide.removeAllItems();
		this.week_slide.addItem("Source/CalendarPage/WeekSchduleView.lay", ymd_data, false);
        this.week_slide.slideTo(1);
    }

    // TFUNCTION: GetTodayYM: ym(year, month)의 값을 가져와서 해당 연월의 delta 전/후 만큼의 연월 데이터를 가져온다.
    GetTodayYM(ym, delta)
    {
        let year    = Number(ym.year);
        let month   = Number(ym.month) + delta;

        while(month <= 0) {
            month += 12;
            year -= 1;
        }

        while(month > 12) {
            month -= 12;
            year += 1;
        }

        return {year, month}
    }

    // TFUNCTION: GetWeekYM: ym(year, month)의 값을 가져와서 해당 일자가 속한 주 데이터를 가져온다.
    GetWeekYM(ymd, delta)
    {
        const year  = Number(ymd.year);
        const month = Number(ymd.month) - 1;
        const day   = Number(ymd.day);

        const base = new Date(year, month, day);
        base.setDate(base.getDate() + (delta * 7));

        return {
            year: base.getFullYear(),
            month: base.getMonth() + 1,
            day: base.getDate()
        };
    }

    // TFUNCTION: OnShowCalBtnClick: 타이틀(calendarpiker) change 이벤트
	OnDateCalChange(comp, info, e)
	{
        const date = comp.getDate();
        const yyyy = String(date.year); 
        const mm = String(date.month);

		this.date_title_lbl.setText(`${yyyy}년 ${mm}월`);
	}

    // TFUNCTION: OnMonthSlideChange: 월별 달력 slide change이벤트
	OnMonthSlideChange(comp, info, e)
	{
        this.m_slide_moved = true;
        clearTimeout(this.m_slideReset_timer);
            this.m_slideReset_timer = setTimeout(() => {
            this.m_slide_moved = false;
        }, 200);

        const all_leng = this.month_slide.getItems().length;
        const now_inx = this.month_slide.indexOfItem( this.month_slide.getCurrentView().element.parentElement );    // 현재 선택된 index
        const now_data = this.month_slide.getItem(now_inx).view.list_data;                                          // 현재 선택된 아이템의 데이터
        const ym = {
            year : now_data.year,
            month : now_data.month
        };

        let last_data;

        if(now_inx == 1)
        {
            last_data = this.GetTodayYM(ym, -2);

            this.month_slide.element.removeChild( this.month_slide.getItem(all_leng - 1) );         // 마지막 인덱스 지우기
            this.month_slide.addItem("Source/CalendarPage/MonSchduleView.lay", [last_data], true);  // 앞에 추가

            setTimeout(()=>{
                this.month_slide.slideTo(2);
            }, 16)
        }
        else if(now_inx == 3)
        {
            last_data = this.GetTodayYM(ym, +2);

            this.month_slide.element.removeChild( this.month_slide.getItem(0) );                    // 처음 인덱스 지우기
            this.month_slide.addItem("Source/CalendarPage/MonSchduleView.lay", [last_data], false); // 뒤에 추가

            setTimeout(()=>{
                this.month_slide.slideTo(2);
            }, 16)
        }
        
        this.date_title_lbl.setText(`${now_data.year}년 ${now_data.month}월`);
	}

    // TFUNCTION: OnWeekSlideChange: 주별 달력 slide change이벤트
	OnWeekSlideChange(comp, info, e)
	{
		this.m_slide_moved = true;
        clearTimeout(this.m_slideReset_timer);
            this.m_slideReset_timer = setTimeout(() => {
            this.m_slide_moved = false;
        }, 200);

        const all_leng = this.week_slide.getItems().length;
        const now_inx = this.week_slide.indexOfItem( this.week_slide.getCurrentView().element.parentElement );    // 현재 선택된 index
        const now_data = this.week_slide.getItem(now_inx).view.list_data;                                          // 현재 선택된 아이템의 데이터
        const ymd = {
            year : now_data.year,
            month : now_data.month,
            day: now_data.day
        };

        let last_data;        

        if(now_inx == 0)
        {
            last_data = this.GetWeekYM(ymd, -1);
            last_data.state = 'change';

            this.week_slide.element.removeChild( this.week_slide.getItem(all_leng - 1) );         // 마지막 인덱스 지우기
            this.week_slide.addItem("Source/CalendarPage/WeekSchduleView.lay", [last_data], true);  // 앞에 추가

            setTimeout(()=>{
                this.week_slide.slideTo(1);
            }, 16)
        }
        else if(now_inx == 2)
        {
            last_data = this.GetWeekYM(ymd, +1);
            last_data.state = 'change';

            this.week_slide.element.removeChild( this.week_slide.getItem(0) );                    // 처음 인덱스 지우기
            this.week_slide.addItem("Source/CalendarPage/WeekSchduleView.lay", [last_data], false); // 뒤에 추가

            setTimeout(()=>{
                this.week_slide.slideTo(1);
            }, 16)
        }
        
        this.date_title_lbl.setText(`${now_data.year}년 ${now_data.month}월`);
	}

    // TFUNCTION: OnKindBtnClick: 월별/주별 버튼 클릭 이벤트
	OnKindBtnClick(comp, info, e)
	{
        let sel_date = this.m_select_date;

		if(comp.compId == 'month_btn')
        {
            this.m_is_month = true;
            this.m_is_bottom_sheet_open = false;

            this.month_btn.enable(false);
            this.week_btn.enable(true);
            this.kind_btn_view.setStyle('left','3px');
            this.month_btn.setStyle('color','#1F2129');
            this.week_btn.setStyle('color','#969CAC');

            this.month_slide.show();
            this.week_slide.hide();
            this.schedule_view.setStyle('box-shadow','rgba(0, 0, 0, 0.1) 0px -2px 8px 0px');
            this.schedule_view.setStyle('height','150px');

            this.scroll_bar_view.setStyleObj({
                'width': '68px',
                'height': '4px',
                'background-color': '#D9D9D9',
                'top': '12px',
                'left': 'calc(50% - 34px)',
                'border-radius': '50px'
            });

            if(sel_date)
            {
                this.SetMonthData(true);
            }
        }
        else if(comp.compId == 'week_btn')
        {
            this.m_is_month = false;
            this.m_is_bottom_sheet_open = true;

            this.month_btn.enable(true);
            this.week_btn.enable(false);
            this.kind_btn_view.setStyle('left','36px');
            this.month_btn.setStyle('color','#969CAC');
            this.week_btn.setStyle('color','#1F2129');

            this.week_slide.show();
            this.month_slide.hide();
            this.schedule_view.setStyle('box-shadow','none');
            this.schedule_view.setStyle('height','400px');

            this.scroll_bar_view.setStyleObj({
                'width': 'calc(100% + 40px)',
                'height': '8px',
                'background-color': '#F4F5F7',
                'top': '0px',
                'left': '-20px',
                'border-radius': '0px'

            });

            if(sel_date)
            {
                this.SetWeekData(true);
            }            
        }
	}

    // TFUNCTION: GetScheduleData: 스케쥴(일정) 데이터 조회
    async GetScheduleData(s_date, e_date, is_add, callback)
    {
        if(!s_date || !e_date) return;

        const inblock = { start_date: s_date, end_date: e_date };
        const res = await sendQuery('calendar', 'list', inblock);
        
        if(res.error || res.length === 0)
        {
            this.schedule_list.removeAllItems();
            
            if(s_date == e_date)
            {
                let mm = s_date.slice(4,6);
                let dd = s_date.slice(6,8);

                if (mm.startsWith('0')) mm = mm.slice(1);
                if (dd.startsWith('0')) dd = dd.slice(1);

                this.sched_date_lbl.setText(`${mm}월 ${dd}일 일정`);
            }

            if(callback) callback(false);
        }
        else
        {
            if(s_date == e_date || is_add)
            {
                res[res.length-1].is_last = true;
                this.AddScheduleList(res, s_date);
            }

            if(callback) callback(true, res);
        }
        
        console.log('calendar/list result : ', res);
    }

    // TFUNCTION: AddScheduleList: 스케쥴(일정) 리스트 추가하는 함수
    AddScheduleList(data, date)
    {
        this.schedule_list.removeAllItems();

        if(!data) return;
        
        let dd = date.slice(4,6);
        let mm = date.slice(6,8);

        if (dd.startsWith('0')) dd = dd.slice(1);
        if (mm.startsWith('0')) mm = mm.slice(1);

        this.sched_date_lbl.setText(`${dd}월 ${mm}일 일정`);

        if(data.length > 0)
        {
            this.schedule_list.addItem("Source/MainPage/SchDuleItem.lay", data);
        }
    }

    // TFUNCTION: OnScrollbarViewActiondown: 스케쥴(일정) 리스트 actiondown이벤트 함수(스와이프 이벤트 구현하기 위해)
	OnScrollbarViewActiondown(comp, info, e)
	{
        this.schedule_view.setStyle('transition','none');

		this.m_startY = e.changedTouches[0].clientY;
        this.m_start_height = this.schedule_view.getHeight();
	}

    // TFUNCTION: OnScrollbarViewActionmove: 스케쥴(일정) 리스트 actionmove이벤트 함수(스와이프 이벤트 구현하기 위해)
	OnScrollbarViewActionmove(comp, info, e)
	{
		const moveY = e.changedTouches[0].clientY;
        const diff = moveY - this.m_startY;

        let height = this.m_start_height - diff;
        height = Math.max(130, Math.min(height, 450));

        this.schedule_view.setStyle('height', height+'px');
	}

    // TFUNCTION: OnScrollbarViewActionup: 스케쥴(일정) 리스트 actionup이벤트 함수(스와이프 이벤트 구현하기 위해)
	OnScrollbarViewActionup(comp, info, e)
	{
        const currentHeight = this.schedule_view.getHeight();
        const closedHeight = 150;
        const openHeight = 450;
        const threshold = (closedHeight + openHeight) / 2; // Midpoint

        if (currentHeight > threshold) {
            this.SlideView('up', () => {
                this.m_is_bottom_sheet_open = true;
            });
        } else {
            this.SlideView('down', () => {
                this.m_is_bottom_sheet_open = false;
            });
        }
	}

    SlideView(state, callback)
    {
        const current_height = this.schedule_view.getHeight();
        let target_height;

        if (state == 'up') {
            target_height = 450; // Open height
        } else if (state == 'down') {
            target_height = 150; // Closed height
        } else {
            console.warn('Invalid state for SlideView:', state);
            if(callback) callback();
            return;
        }

        const animation = this.schedule_view.element.animate([
            {  height: `${current_height}px`},
            {  height: `${target_height}px`}
        ], {
            delay: 0,
            duration: 300,
            easing: 'ease-in-out',
            fill: 'forwards'
        });

        animation.onfinish = () => {
            if(callback) callback();
        };
    }

    // TFUNCTION: OnAddBtnClick: 일정 추가 버튼 클릭 이벤트
	OnAddBtnClick(comp, info, e)
	{
		let view = new AWindow();
        
        comp.hide();
        view.setData({
            is_add: true
        });
        view.setResultCallback( result => {
            let sta_date, end_date;

            comp.show();

            if(!result) return;

            if(this.m_is_month)
            {
                if(Object.keys(this.m_month_cache).length === 0) return;

                let sta_key = Object.keys(this.m_month_cache)[0];
                let end_key = Object.keys(this.m_month_cache).at(-1);
                let last_day = this.GetLastDateOfMonth(end_key.slice(0,4), end_key.slice(4,6));

                sta_date = sta_key + '01';
                end_date = end_key + String(last_day).padStart(2,'0');
            }
            else
            {
                if(Object.keys(this.m_day_cache).length === 0) return;

                sta_date = Object.keys(this.m_day_cache)[0];
                end_date = Object.keys(this.m_day_cache).at(-1);
            }
            
            this.GetScheduleData(sta_date, end_date, true, (res, data)=>{
                if(res)
                {
                    // 기존 m_month_cache, m_day_cache에 저장한 데이터와 조회 data 겹치는 객체 삭제 후 다시 할당함
                    const month_key = new Set();
                    const day_key = new Set();

                    data.forEach(obj => {
                        const date = String(obj.calendar_date);

                        month_key.add(date.slice(0, 6)); // yyyymm
                        day_key.add(date); // yyyymmdd
                    });

                    month_key.forEach(m_key => {
                        if(m_key in this.m_month_cache) delete this.m_month_cache[m_key];
                    });

                    day_key.forEach(d_key => {
                        if(d_key in this.m_day_cache) delete this.m_day_cache[d_key];
                    });

                    this.SetMonthData(true);
                    this.SetWeekData(true);
                }
            });
        });
        view.openFull("Source/CalendarPage/ScheduleRegist.lay", this.getContainer());
	}

    // TFUNCTION: GetLastDateOfMonth: 각 연도/월의 마지막 일자를 구하는 함수.
    GetLastDateOfMonth(year, month)
    {
        if(!year || !month) return;

        return new Date(year, month, 0).getDate();
    }
}
