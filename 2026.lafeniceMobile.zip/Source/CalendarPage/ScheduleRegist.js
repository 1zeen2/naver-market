
class ScheduleRegist extends AView
{
	constructor()
	{
		super()

        this.m_get_data = null;     // 받은 데이터 저장
        this.m_is_add = null;       // 등록/수정 여부, true:등록 false:수정
        this.m_calendar_uid = null; // 일정ID
        this.m_time = {}
        this.m_address = {
            road : '',  //도로명주소
            jibun : '', //지번주소
            lat: null,  //위도
            lng: null,  //경도
        };
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

        this.m_get_data = this.getContainer().getData().data;
        this.m_is_add   = this.getContainer().getData().is_add;
        
        if(this.m_is_add)
        {
            this.title_lbl.setText('일정 등록');
            this.ok_btn.setText('등록하기');
        }
        else
        {
            this.title_lbl.setText('일정 수정');
            this.ok_btn.setText('수정하기');
            this.SetData(this.m_get_data);
        }

        this.SetCalendarPickerStyle();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    // TFUNCTION: SetCalendarPickerStyle: 켈린더피커 스타일 설정해주는 함수.
    SetCalendarPickerStyle()
    {
        this.date_cal.setCalendarPickerStyle({
            'border-radius': '8px',
            'border': '1px solid #E2E4EB',
            'color': '#1F2129'
        });
        this.date_cal.setCalendarPickerSelectedStyle({
            'border': '2px solid #E91E63',
        });  
        this.date_cal.element.children[0].children[0].acomp.textfield.element.blur();
        this.date_cal.element.children[0].children[0].acomp.textfield.$ele.css({
            'width': '100%',
            'left': '0px',
            'padding': '0 12px',
            'background-image': 'none'
        });
        this.date_cal.element.children[0].children[0].acomp.calBtn.$ele.css({
            'width': '100%',
            'background-image': 'none'
        });
    }

    // TFUNCTION: SetData: 수정하는 경우, 기존 데이터를 셋팅하는 함수
    SetData(data)
    {
        this.m_calendar_uid = data.calendar_uid;
        this.m_address = {
            road : data.road_address_name,
            jibun : data.address_name,
            lat: Number(data.latitude),
            lng: Number(data.longitude),
        };

        this.title_txf.setText(data.calendar_title);
        //this.date_cal.setDate(data.calendar_date);
        this.add_name_txf.setText(data.place_name);
        this.sta_time_lbl.setText(data.start_time);
        this.end_time_lbl.setText(data.end_time);
        this.add_default_txf.setText(data.address_name);
        this.add_detail_txf.setText(data.address_detail);
        this.memo_txa.setText(data.memo);
    }

    // TFUNCTION: OnBackBtnClick: 뒤로가기 버튼
	OnBackBtnClick(comp, info, e)
	{
		this.getContainer().close();
	}

    // TFUNCTION: OnSTimeViewClick: 시작/종료 시간 뷰 클릭(시작시간선택) 함수
    OnSETimeViewClick(comp, info, e)
	{
		openBottomSheet(this, {
            title: '시간 설정',
            path: 'Source/BottomSheet/TimeBottomSheetPopup.lay',
            data: this.ChangeTime(comp),
            onSelect:(data)=>{
                if(data.start_time)
                {
                    const s_data = data.start_time;

                    if( (s_data.apm != null) && (s_data.hour != null) && (s_data.minute != null) )
                    {
                        const hh = String(s_data.hour).padStart(2, '0');
                        const mm = String(s_data.minute).padStart(2, '0');

                        this.sta_time_lbl.setText(`${s_data.apm} ${hh}:${mm}`);
                    }
                }

                if(data.end_time)
                {
                    const e_data = data.end_time;

                    if( (e_data.apm != null) && (e_data.hour != null) && (e_data.minute != null) )
                    {
                        const hh = String(e_data.hour).padStart(2, '0');
                        const mm = String(e_data.minute).padStart(2, '0');

                        this.end_time_lbl.setText(`${e_data.apm} ${hh}:${mm}`);
                    }
                }
            }
        })
	}

    // TFUNCTION: OnAddSearchBtnClick: 주소 검색 버튼
	OnAddSearchBtnClick(comp, info, e)
	{
        new daum.Postcode({
            oncomplete: (data) => {
                // data.zonecode: 우편번호
                // data.roadAddress / data.jibunAddress: 도로명/지번
                // data.userSelectedType: R(도로명) / J(지번)

                var addr = '';      // 최종 주소
                var extraAddr = ''; // 참고항목

                // 사용자가 선택한 타입에 따라 주소 선택
                if (data.userSelectedType === 'R') addr = data.roadAddress; //도로명
                else addr = data.jibunAddress;

                this.m_address = {
                    road : data.roadAddress||address,
                    jibun : data.jibunAddress||data.autoJibunAddress,
                };

                // 도로명 선택 시 참고항목 조립(법정동/건물명 등)
                if (data.userSelectedType === 'R')
                {
                    if (data.bname && /[동|로|가]$/g.test(data.bname)) extraAddr += data.bname;
                    if (data.buildingName && data.apartment === 'Y') extraAddr += (extraAddr ? ', ' : '') + data.buildingName;
                    if (extraAddr) extraAddr = ' (' + extraAddr + ')';
                }

                this.add_default_txf.setText(addr + extraAddr);
                this.add_detail_txf.element.focus();

                this.GetLatLngByAddress(addr, (pos) => {
                    if(!pos) {
                        console.log('좌표 변환 실패:', addr);
                        this.m_address.lat = null;
                        this.m_address.lng = null;
                        return;
                    }

                    this.m_address.lat = pos.lat;
                    this.m_address.lng = pos.lng;

                    console.log('lat/lng:', this.m_address.lat, this.m_address.lng);
                });
            }
        }).open();
	}

    // TFUNCTION: GetLatLngByAddress: 주소-좌표 변환 함수
    GetLatLngByAddress(addr, cb)
    {
        if(!window.kakao || !kakao.maps || !kakao.maps.services)
        {
            console.log('Kakao maps services 로드 필요 (libraries=services)');
            cb(null);
            return;
        }

        const geocoder = new kakao.maps.services.Geocoder();

        geocoder.addressSearch(addr, (result, status) => {
            if (status !== kakao.maps.services.Status.OK || !result || !result.length)
            {
                cb(null);
                return;
            }

            // Kakao Geocoder 결과: x = 경도(lng), y = 위도(lat)
            const lng = Number(result[0].x);
            const lat = Number(result[0].y);

            cb({ lat, lng });
        });
    }

    // TFUNCTION: OnColorSelectViewClick: 색상 선택 뷰 클릭(색상선택) 함수
    OnColorSelectViewClick(comp, info, e)
	{
        openBottomSheet(this, {
            title: '시간 설정',
            path: 'Source/BottomSheet/ColorBottomSheetPopup.lay',
            data: {},
            onSelect: (data)=>{
                let text = '';

                switch(data){
                    case 'E91E63' : text = '핑크'; break;
                    case 'E96840' : text = '주황'; break;
                    case 'F7BD11' : text = '노랑'; break;
                    case '3D71E7' : text = '파랑'; break;
                    case '7F40E7' : text = '보라'; break;
                    case '14A989' : text = '초록'; break;
                    case '717A81' : text = '회색'; break;
                }

                this.color_view.setName(data);
                this.color_view.setStyle('background-color',`#${data}`);
                this.color_lbl.setText(text);
            } //콜백
        })
	}

    // TFUNCTION: Validation: 유효성 검사
    Validation()
    {
        if(!this.title_txf.getText() || this.title_txf.getText().trim().length === 0)
        {
            AToast.show('제목을 입력해주세요');
            return false;
        }
        else if(!this.date_cal.getDate())
        {
            AToast.show('날짜를 입력해주세요');
            return false;
        }
        else if(!this.add_default_txf.getText())
        {
            AToast.show('주소를 입력해주세요');
            return false;
        }
        else if(!this.add_name_txf.getText())
        {
            AToast.show('장소 이름을 입력해주세요');
            return false;
        }
        else if(!this.memo_txa.getText())
        {
            AToast.show('메모를 입력해주세요');
            return false;
        }
        else return true;
    }

    // TFUNCTION: OnOkBtnClick: 등록 및 수정 버튼 클릭
    OnOkBtnClick(comp, info, e)
    {
        let validation =  this.Validation();

        if(validation)
        {
            if(this.m_is_add) this.AddSchedule();
            else this.UpdateSchedule();
        }
    }

    // TFUNCTION: AddSchedule: 스케줄을 등록한다.
    async AddSchedule()
    {
        const inblock = this.GetScheduleData();
        const res = await sendQuery('calendar', 'register', inblock);

        console.log(inblock);
        console.log(res);

        if(res.error || !res.success)
        {
            AToast.show('등록에 실패했습니다');
            return;
        }
        else
        {
            AToast.show('등록되었습니다');
            this.getContainer().close(true, res);
        }
    }

    // TFUNCTION: UpdateSchedule: 스케줄을 수정한다.
    async UpdateSchedule()
    {
        const inblock = this.GetScheduleData();
        const res = await sendQuery('calendar', 'update', inblock);

        if(res.error || !res.success)
        {
            AToast.show('수정에 실패했습니다');
            return;
        }
        else
        {
            AToast.show('수정되었습니다');
            this.getContainer().close(true, res);
        }
    }

    // TFUNCTION: GetScheduleData: 입력한 일정 데이터 가져오기
    GetScheduleData()
    {
        let obj = {
            calendar_title      : this.title_txf.getText(),                         //일정 제목
            calendar_date       : this.date_cal.getDateString(),                    //일정 날짜
            start_time          : this.ChangeTime24(this.sta_time_lbl.getText()),   //시작 시간
            end_time            : this.ChangeTime24(this.end_time_lbl.getText()),   //종료 시간
            memo                : this.memo_txa.getText(),                          //메모
            color               : '#' + this.color_view.getName(),                  //색상코드
            place_name          : this.add_name_txf.getText(),                      //장소이름
            address_name        : this.m_address.jibun ? this.m_address.jibun : '', //번지 주소
            road_address_name   : this.m_address.road ? this.m_address.road : '',   //도로명 주소
            address_detail      : this.add_detail_txf.getText(),                    //상세주소
            longitude           : 37.5665, //this.m_address.lng || 0, //경도 테스트값, 지도 연결 후 테스트값 주석처리 해야함
            latitude            : 126.9780 //this.m_address.lat || 0, //위도 테스트값, 지도 연결 후 테스트값 주석처리 해야함
        };
        if(this.m_calendar_uid) obj.calendar_uid = this.m_calendar_uid;
        
        return obj;
    }

    // TFUNCTION: ChangeTime: 현재 셋팅되어 있는 시간 정보를 내보낸다.
    ChangeTime(comp)
    {
        let s_text = this.sta_time_lbl.getText().split(/[ :]/);
        let e_text = this.end_time_lbl.getText().split(/[ :]/);

        let send_data = {
            start_time:{
                apm : s_text[0],
                hour : s_text[1],
                minute : s_text[2]
            },
            end_time:{
                apm : e_text[0],
                hour : e_text[1],
                minute : e_text[2]
            },
            is_start : Boolean(comp.compId == 's_time_view'),
        };

        return send_data;
    }

    // TFUNCTION: ChangeTime24: 시간을 매개변수로 받으면, 24시간 형식으로 내보낸다.
    ChangeTime24(time_text)
    {
        const text_arr  = time_text.split(/[ :]/);
        const apm       = text_arr[0];
        const hour      = Number(text_arr[1]);
        const minute    = String(text_arr[2]).padStart(2, '0');

        if(apm == '오후')
        {
            hour += 12;
            if(hour == 24) hour = 0
        }

        return `${String(hour).padStart(2, '0')}${minute}`
    }
}

