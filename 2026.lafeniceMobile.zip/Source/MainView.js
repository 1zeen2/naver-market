
class MainView extends AView
{
	constructor()
	{
		super()

		this.page_history = [];

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

	}

	onInitDone()
	{
		super.onInitDone()
		this.SetStyle();
        theApp.mainContainer.navigator.setSlideDir('left');
        theApp.mainContainer.navigator.setFlipType('slide');
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

        const data = this.getContainer().getData();
        if(data && data.targetTab) {
            this.SwitchTab(data.targetTab);
            this.getContainer().setData(null);
        } else if(isFirst) {
            this.MovePage('MainPage');
        }
    }

    SwitchTab(pageId, is_pop = false) {
        if(this.nav_bar && this.nav_bar.ldView) {
            const navView = this.nav_bar.ldView;
            if(navView[pageId]) {
                navView.OnChangePage(navView[pageId], null, null, is_pop);
            }
        }
    }

    SetStyle()
    {
        this.content_view.element.parentElement.classList.add('min-height-0'); // flex content 스크롤 가능하게
    }

    MovePage(page_id, data, is_pop)
    {
        
        const main_pages = {
            MainPage    : 'Source/MainPage/MainPage.lay', //홈
            CalendarPage: 'Source/CalendarPage/CalenderMain.lay', //캘린더
            ShowinMain  : 'Source/ShowinPage/ShowinMain.lay', //전시
            MarketMain  : 'Source/MarketPage/MarketMain.lay', //마켓
            MoreMain    : 'Source/MorePage/MoreMain.lay' // 더보기
        }

        this.page_history.push(page_id);
        
        if(!is_pop) {
            history.pushState({ page: page_id }, '', `#${page_id}`);
        }
        
        this.content_view.loadView(main_pages[page_id]);
        //history.forward() 히스토리 롤백
    }


	ScrollContentView(comp, info, e)
	{

		console.log(e);

	}
}

