
class BottomSheet extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        const wnd = this.getContainer();
        const options = wnd.wndOptions;

        this.load_view.loadView(options.path);
        this.title_lbl.setText(options.title);

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

	CloseBtnClick(comp, info, e)
	{
		this.getContainer().close();
	}
}

