
class ProductItemPopup extends AView
{
	constructor()
	{
		super()

        this.m_get_data = null;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()

        this.m_get_data = this.getContainer().getData()
        this.AddList();
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    AddList()
    {
        this.list.removeAllItems();
        this.list.addItem("Source/MarketPage/ProductItemPopupItem.lay", this.m_get_data||[]);
    }
}

