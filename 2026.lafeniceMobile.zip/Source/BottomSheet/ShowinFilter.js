
class ShowinFilter extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		this.input_view.addClass('display-none');

        this.calendarPickerS.setCalendarIconRight();
        this.calendarPickerE.setCalendarIconRight();

        this.calendarPickerS.setCalendarIconImage('Assets/calendar_icon.png');
        this.calendarPickerE.setCalendarIconImage('Assets/calendar_icon.png');

        this.calendarPickerS.setCalendarIconStyle({
            'background-size': '16px 16px',
            'right': '4px'
        });
        this.calendarPickerE.setCalendarIconStyle({
            'background-size': '16px 16px',
            'right': '4px'
        });

        this.calendarPickerS.setCalendarPickerStyle({
            'border-radius': '6px',
            'border-color': '#CACED9'
        });
        this.calendarPickerE.setCalendarPickerStyle({
            'border-radius': '6px',
            'border-color': '#CACED9'
        });

        this.calendarPickerS.setCalendarPickerSelectedStyle({
            'border-color': '#E91E63'
        });
        this.calendarPickerE.setCalendarPickerSelectedStyle({
            'border-color': '#E91E63'
        });

        this.calendarPickerS.setCalendarInputStyle({
            'font-size': '13px',
            'font-weight': '500',
            'color': '#1F2129',
            'padding': '9px 0px 9px 12px',
            'font-family': 'Pretendard Variable'
        });
        this.calendarPickerE.setCalendarInputStyle({
            'font-size': '13px',
            'font-weight': '500',
            'color': '#1F2129',
            'padding': '9px 0px 9px 12px',
            'font-family': 'Pretendard Variable'
        });

        this.m_selectStatus = '전체';
        this.m_selectPeriod = '전체';

        const wnd = this.getContainer();
        const filterData = wnd.wndOptions.data;

        if (filterData) {
            if (filterData.statusText === '대기') {
                filterData.statusText = '진행 예정';
            }
            this.m_selectStatus = filterData.statusText || '전체';
            this.m_selectPeriod = filterData.periodText || '전체';
            
            this.StatusButton(this.m_selectStatus);
            this.PeriodButton(this.m_selectPeriod);
            
            if (this.m_selectPeriod === '직접입력' && filterData.start_date) {
                this.input_view.removeClass('display-none');
                
                this.calendarPickerS.setDate(filterData.start_date);
                this.calendarPickerE.setDate(filterData.end_date);
            }
        }

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

    StateBtnClick(comp, info, e)
    {
        const findGroup = this.stateBtn_view.findCompByGroup('state_btn');

        this.UpdateSelectBtn(findGroup, comp);

        this.m_selectStatus = comp.getChild(0).getText();
    }

    PeriodBtnClick(comp, info, e)
    {
        const findGroup = this.periodBtn_view.findCompByGroup('period_btn');

        this.UpdateSelectBtn(findGroup, comp);

        this.m_selectPeriod = comp.getChild(0).getText();

        if (comp.compId === 'input_btn') {
            this.input_view.removeClass('display-none');
            
        } else {
            this.input_view.addClass('display-none');
        }
    }

    UpdateSelectBtn(btnGroup, selectBtn)
    {
        btnGroup.forEach(btn => {
            btn.removeClass('selectColor');
            btn.addClass('nonSelectColor');
        })

        selectBtn.removeClass('nonSelectColor');
        selectBtn.addClass('selectColor');
    }

    StatusButton(statusText)
    {
        const stateBtns = this.stateBtn_view.findCompByGroup('state_btn');
        
        stateBtns.forEach(btn => {
            const btnText = btn.getChild(0).getText();

            if (btnText === statusText) {
                btn.removeClass('nonSelectColor');
                btn.addClass('selectColor');

            } else {
                btn.removeClass('selectColor');
                btn.addClass('nonSelectColor');
            }
        });
    }

    PeriodButton(periodText)
    {
        const periodBtns = this.periodBtn_view.findCompByGroup('period_btn');
        
        periodBtns.forEach(btn => {
            const btnText = btn.getChild(0).getText();

            if (btnText === periodText) {
                btn.removeClass('nonSelectColor');
                btn.addClass('selectColor');
                
            } else {
                btn.removeClass('selectColor');
                btn.addClass('nonSelectColor');
            }
        });
    }

	OkBtnClick(comp, info, e)
	{
        const data = {
            status: this.m_selectStatus,
            period: this.m_selectPeriod
        };

        if (this.m_selectPeriod === '직접입력') {
            data.startDate = this.calendarPickerS.getDateString();
            data.endDate = this.calendarPickerE.getDateString();
        }

        this.getContainer().close(true, data);
	}
}

