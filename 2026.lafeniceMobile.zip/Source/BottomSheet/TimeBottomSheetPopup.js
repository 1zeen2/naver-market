
class TimeBottomSheetPopup extends AView
{
	constructor()
	{
		super()

        this.m_get_data = null;
        this.m_apm = null;          // 현재 선택 중인 오전/오후
        this.m_hour = null;         // 현재 선택 중인 시간
        this.m_minute = null;       // 현재 선택 중인 분
        this.m_is_start = true;     // 시작시간 선택 중인지 종료시간 선택 중인지 (true:시작 false:종료)
        this.m_start_time = {
            'apm': null,
            'hour': null,
            'minute': null,
        };
        this.m_end_time = {
            'apm': null,
            'hour': null,
            'minute': null,
        };
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
        
        this.m_get_data = this.getContainer().getData() || this.getContainer().wndOptions.data;
        this.m_is_start = this.m_get_data.is_start;
        this.m_start_time = this.m_get_data.start_time;
        this.m_end_time = this.m_get_data.end_time;

		this.SetLabels()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    // TFUNCTION: SetLabels: am, pm, 시간, 분 데이터를 동적으로 셋팅해준다
    SetLabels()
    {
        const lbl_style = {
            'position': 'relative',
            'width': '100%',
            'height': '40px',
            'text-align': 'center',
            'line-height': '40px',
            'font-size': '14px',
            'color': '#7C8292',
            'font-weight': '500',
            'flex-shrink': '0',
            'scroll-snap-align': 'center'
        };

        // 오전/오후
        for(let i=0; i<2; i++) {
            let lbl = new ALabel();
                lbl.init();
                lbl.setText(i == 0 ? '오전' : '오후');
                lbl.setStyleObj(lbl_style);
                lbl.element.dataset.value = (i == 0 ? '오전' : '오후');
                lbl.element.addEventListener('click', () => {
                    this.ScrollToCenter(this.apm_flay, lbl.element);
                });

            this.apm_flay.element.appendChild(lbl.element);
        }

        // 시간 (1 ~ 12)
        for(let j=1; j<=12; j++) {
            let lbl = new ALabel();
                lbl.init();
                lbl.setText(j);
                lbl.setStyleObj(lbl_style);
                lbl.element.dataset.value = String(j);
                lbl.element.addEventListener('click', () => {
                    this.ScrollToCenter(this.hour_flay, lbl.element);
                });

            this.hour_flay.element.appendChild(lbl.element);
        }

        // 분 (0 ~ 59)
        for(let k=0; k<=59; k++) {
            let lbl = new ALabel();
                lbl.init();
                lbl.setText(k);
                lbl.setStyleObj(lbl_style);
                lbl.element.dataset.value = String(k);
                lbl.element.addEventListener('click', () => {
                    this.ScrollToCenter(this.minute_flay, lbl.element);
                });

            this.minute_flay.element.appendChild(lbl.element);
        }

        const bindAutoPick = (flay, type) => {
            flay.element.addEventListener('scroll', () => {
                clearTimeout(flay.element._pickTimer);
                flay.element._pickTimer = setTimeout(() => {
                    this.PickCenterItem(flay, type);
                }, 80);
            });
        };

        bindAutoPick(this.apm_flay, 'apm');
        bindAutoPick(this.hour_flay, 'hour');
        bindAutoPick(this.minute_flay, 'minute');

        // 최초 1회도 선택해두기(화면 뜨자마자 빨강 표시)
        setTimeout(() => {
            if(this.m_get_data)
            {
                this.ApplyInitTime(this.m_is_start ? this.m_start_time : this.m_end_time);
            }
            else
            {
                //맨 처음 것들로 셋팅됨
                this.PickCenterItem(this.apm_flay, 'apm');
                this.PickCenterItem(this.hour_flay, 'hour');
                this.PickCenterItem(this.minute_flay, 'minute');
            }
            
        }, 0);
    }

    // TFUNCTION: ApplyInitTime: 전달받은 데이터 선택되도록하는 함수
    ApplyInitTime(data)
    {
        // 시작/종료 버튼 셀렉
        this.start_time_btn.setCheck(this.m_is_start);
        this.end_time_btn.setCheck(!this.m_is_start);

        let apm = data.apm || '오전';

        let hour24 = Number(data.hour);
        let hour12 = hour24;

        if(hour24 === 0)        { hour12 = 12; apm = '오전'; }
        else if(hour24 === 12)  { hour12 = 12; apm = '오후'; }
        else if(hour24 > 12)    { hour12 = hour24 - 12; apm = '오후'; }
        else                    { hour12 = hour24; }

        const minute = Number(data.minute);

        // 해당 라벨 찾아서 가운데로 이동
        const findByValue = (flay, value) => {
            return Array.from(flay.element.children).find(el => el.dataset && el.dataset.value == value);
        };

        const apm_ele  = findByValue(this.apm_flay, apm);
        const hour_ele = findByValue(this.hour_flay, String(hour12));
        const min_ele  = findByValue(this.minute_flay, String(parseInt(minute, 10)));

        if(apm_ele)  this.ScrollToCenter(this.apm_flay, apm_ele);
        if(hour_ele) this.ScrollToCenter(this.hour_flay, hour_ele);
        if(min_ele)  this.ScrollToCenter(this.minute_flay, min_ele);

        // 스크롤 이동 후 선택/멤버값 확정
        setTimeout(() => {
            this.PickCenterItem(this.apm_flay, 'apm');
            this.PickCenterItem(this.hour_flay, 'hour');
            this.PickCenterItem(this.minute_flay, 'minute');
        }, 150);
    }


    // TFUNCTION: PickCenterItem: 가운데에 가장 가까운 Label찾고 선택 처리하는 함수
    PickCenterItem(container, type)
    {
        const el = container.element;
        const centerY = el.scrollTop + (el.clientHeight / 2);

        const items = el.children;
        let closest = null;
        let min = Infinity;

        for(let i=0; i<items.length; i++)
        {
            const item = items[i];
            if(!item.dataset || item.dataset.value == null) continue;

            const itemCenter = item.offsetTop + (item.clientHeight / 2);
            const dist = Math.abs(centerY - itemCenter);

            if(dist < min) { min = dist; closest = item; }
        }

        if(!closest) return;

        this.SetSelected(container, closest);

        if(type === 'apm')          this.m_apm  = closest.dataset.value; 
        else if(type === 'hour')    this.m_hour = Number(closest.dataset.value);
        else if(type === 'minute')  this.m_minute = Number(closest.dataset.value);

        if(this.m_is_start)
        {
            const mm = String(this.m_minute).padStart(2,'0');
            this.start_time_btn.setText(`${this.m_apm} ${this.m_hour}:${mm}`);

            this.m_start_time = {
                'apm': this.m_apm,
                'hour': this.m_hour,
                'minute': this.m_minute,
            };
        }
        else
        {
            const mm = String(this.m_minute).padStart(2,'0');
            this.end_time_btn.setText(`${this.m_apm} ${this.m_hour}:${mm}`);

            this.m_end_time = {
                'apm': this.m_apm,
                'hour': this.m_hour,
                'minute': this.m_minute,
            };
        }
    }

    // TFUNCTION: SetSelected: 컨테이너 내에서 선택된 것만 빨강, 나머지는 회색으로 셋팅하는 함수
    SetSelected(container, selectedEl)
    {
        const items = container.element.children;

        for(let i=0; i<items.length; i++)
        {
            const item = items[i];
            if(!item.dataset || item.dataset.value == null) continue;

            if(item === selectedEl)
            {
                item.style.color = '#E91E63';
                item.style.fontWeight = '600';
            }
            else
            {
                item.style.color = '#7C8292';
                item.style.fontWeight = '500';
            }
        }
    }

    // TFUNCTION: ScrollToCenter: 선택된 아이템이 스크롤 컨테이너 중앙에 오도록 스크롤 위치를 맞춰주는 함수
    ScrollToCenter(container, element)
    {
        const container_height = container.element.clientHeight;
        const element_top = element.offsetTop;
        const element_height = element.clientHeight;

        const scrollTo = element_top - (container_height / 2) + (element_height / 2);

        container.element.scrollTo({
            top: scrollTo,
            behavior: 'smooth'
        });
    }

    // TFUNCTION: OnTimeBtnClick: 시작시간/종료시간 버튼 클릭 이벤트
	OnTimeBtnClick(comp, info, e)
	{
        const is_start = (comp.compId === 'start_time_btn');

        this.m_is_start = is_start;
        this.start_time_btn.setCheck(is_start);
        this.end_time_btn.setCheck(!is_start);

        const time = is_start ? this.m_start_time : this.m_end_time;

        if(time && time.apm != null && time.hour != null && time.minute != null)
        {
            let hour24 = Number(time.hour);
            if(time.apm === '오후' && hour24 < 12) hour24 += 12;
            if(time.apm === '오전' && hour24 === 12) hour24 = 0;

            this.ApplyInitTime({
                apm: time.apm,
                hour: hour24,
                minute: Number(time.minute),
                is_start: is_start
            });
        }
        else
        {
            // 저장값이 없으면 그냥 현재 스크롤 중앙값을 해당 모드로 저장/표시
            this.PickCenterItem(this.apm_flay, 'apm');
            this.PickCenterItem(this.hour_flay, 'hour');
            this.PickCenterItem(this.minute_flay, 'minute');
        }
	}

        // TFUNCTION: OnOkBtnClick: 확인 버튼 클릭 이벤트
	OnOkBtnClick(comp, info, e)
	{
		const send_data = {
            start_time : this.m_start_time,
            end_time : this.m_end_time
        };

        this.getContainer().close(true, send_data);
	}
}

