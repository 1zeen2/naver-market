
class ViewingFilter extends AView
{
	constructor()
	{
		super()

        this.m_currentMode = 'start';
        this.m_startYear = null;
        this.m_startMonth = null;
        this.m_endYear = null;
        this.m_endMonth = null;
        this.m_selectedYear = null;
        this.m_selectedMonth = null;
        this.m_isLoad = true;
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.YearMonthList();

        this.calendarPickerS.setCalendarIconRight();
        this.calendarPickerE.setCalendarIconRight();

        this.calendarPickerS.setCalendarIconImage('Assets/calendar_icon.png');
        this.calendarPickerE.setCalendarIconImage('Assets/calendar_img_gray.png');

        this.calendarPickerS.setCalendarIconStyle({
            'background-size': '16px 16px',
            'right': '4px'
        });
        this.calendarPickerE.setCalendarIconStyle({
            'background-size': '16px 16px',
            'right': '4px'
        });

        this.calendarPickerS.setCalendarPickerStyle({
            'border-radius': '6px',
            'border-color': '#CACED9'
        });
        this.calendarPickerE.setCalendarPickerStyle({
            'border-radius': '6px',
            'border-color': '#CACED9'
        });

        this.calendarPickerS.setCalendarPickerSelectedStyle({
            'border-color': '#E91E63'
        });
        this.calendarPickerE.setCalendarPickerSelectedStyle({
            'border-color': '#E91E63'
        });

        this.calendarPickerS.setCalendarInputStyle({
            'font-size': '13px',
            'font-weight': '500',
            'color': '#1F2129',
            'padding': '9px 0px 9px 12px',
            'font-family': 'Pretendard Variable'
        });
        this.calendarPickerE.setCalendarInputStyle({
            'font-size': '13px',
            'font-weight': '500',
            'color': '#1F2129',
            'padding': '9px 0px 9px 12px',
            'font-family': 'Pretendard Variable'
        });

        this.calendarPickerS.element.querySelector('input').addEventListener('click', (e) => {
            e.preventDefault();
            this.SwitchMode('start');
        });

        this.calendarPickerE.element.querySelector('input').addEventListener('click', (e) => {
            e.preventDefault();
            this.SwitchMode('end');
        });
    }

    onActiveDone(isFirst)
    {
        super.onActiveDone(isFirst);

        //TODO:edit here

    }

    YearMonthList()
    {
        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1;

        const years = [];
        for (let y = currentYear; y >= 2020; y--) {
            years.push(y);
        }

        const months = [];
        for (let m = 1; m <= 12; m++) {
            months.push(m);
        }

        const lblStyle = {
            position: 'relative',
            width: '100%',
            height: '40px',
            'text-align': 'center',
            'line-height': '40px',
            'font-size': '14px',
            'color': '#7C8292',
            'font-weight': '500',
            'flex-shrink': '0',
            'scroll-snap-align': 'center'
        };

        const topSpacer = document.createElement('div');
        topSpacer.style.height = '93px';
        topSpacer.style.flexShrink = '0';
        this.year_flay.element.appendChild(topSpacer);

        years.forEach((year) => {
            const lbl = new ALabel();
            lbl.init();
            lbl.setText(year + '년');
            lbl.setStyleObj(lblStyle);
            lbl.element.dataset.value = year;

            lbl.addEventListener('click', () => {
                this.SelectYear(year, lbl.element);
                this.ScrollToCenter(this.year_flay, lbl.element);
            });

            this.year_flay.element.appendChild(lbl.element);
        });

        const bottomSpacerYear = document.createElement('div');
        bottomSpacerYear.style.height = '93px';
        bottomSpacerYear.style.flexShrink = '0';
        this.year_flay.element.appendChild(bottomSpacerYear);

        const topSpacerMonth = document.createElement('div');
        topSpacerMonth.style.height = '93px';
        topSpacerMonth.style.flexShrink = '0';
        this.month_flay.element.appendChild(topSpacerMonth);

        months.forEach((month) => {
            const lbl = new ALabel();
            lbl.init();
            lbl.setText(month + '월');
            lbl.setStyleObj(lblStyle);
            lbl.element.dataset.value = month;

            lbl.addEventListener('click', () => {
                this.SelectMonth(month, lbl.element);
                this.ScrollToCenter(this.month_flay, lbl.element);
            });

            this.month_flay.element.appendChild(lbl.element);
        });

        const bottomSpacerMonth = document.createElement('div');
        bottomSpacerMonth.style.height = '93px';
        bottomSpacerMonth.style.flexShrink = '0';
        this.month_flay.element.appendChild(bottomSpacerMonth);

        this.year_flay.element.addEventListener('scrollend', () => {
            if (!this.m_isLoad) {
                this.AutoSelectScroll(this.year_flay, 'year');
            }
        });

        this.month_flay.element.addEventListener('scrollend', () => {
            if (!this.m_isLoad) {
                this.AutoSelectScroll(this.month_flay, 'month');
            }
        });

        const wnd = this.getContainer();
        const data = wnd.wndOptions.data;
    
        if (data && data.start_date && data.end_date) {
            const startYear = parseInt(data.start_date.substring(0, 4));
            const startMonth = parseInt(data.start_date.substring(4, 6));
            const endYear = parseInt(data.end_date.substring(0, 4));
            const endMonth = parseInt(data.end_date.substring(4, 6));
            
            this.m_startYear = startYear;
            this.m_startMonth = startMonth;
            this.m_endYear = endYear;
            this.m_endMonth = endMonth;

        } else {
            this.m_startYear = currentYear;
            this.m_startMonth = currentMonth;
            this.m_endYear = currentYear;
            this.m_endMonth = currentMonth;
        }

        this.SwitchMode('start');

        setTimeout(() => {
            this.m_isLoad = false;
        }, 1000);
    }

    SwitchMode(mode)
    {
        this.m_currentMode = mode;

        if (mode === 'start') {
            this.calendarPickerS.setCalendarPickerStyle({
                'border-color': '#E91E63'
            });
            this.calendarPickerE.setCalendarPickerStyle({
                'border-color': '#CACED9'
            });
            this.calendarPickerS.setCalendarIconImage('Assets/calendar_icon.png');
            this.calendarPickerE.setCalendarIconImage('Assets/calendar_img_gray.png');

            this.LoadDate(this.m_startYear, this.m_startMonth);
        } else {
            this.calendarPickerE.setCalendarPickerStyle({
                'border-color': '#E91E63'
            });
            this.calendarPickerS.setCalendarPickerStyle({
                'border-color': '#CACED9'
            });
            this.calendarPickerS.setCalendarIconImage('Assets/calendar_img_gray.png');
            this.calendarPickerE.setCalendarIconImage('Assets/calendar_icon.png');

            this.LoadDate(this.m_endYear, this.m_endMonth);
        }
    }

    LoadDate(year, month)
    {
        const yearItems = this.year_flay.element.children;
        for (let i = 0; i < yearItems.length; i++) {
            const itemValue = yearItems[i].dataset.value;

            if (itemValue && parseInt(itemValue) === year) {
                this.ScrollToCenter(this.year_flay, yearItems[i]);
                this.SelectYear(year, yearItems[i]);
                break;
            }
        }

        const monthItems = this.month_flay.element.children;
        for (let i = 0; i < monthItems.length; i++) {
            const itemValue = monthItems[i].dataset.value;

            if (itemValue && parseInt(itemValue) === month) {
                this.ScrollToCenter(this.month_flay, monthItems[i]);
                this.SelectMonth(month, monthItems[i]);
                break;
            }
        }
    }

    ScrollToCenter(container, element)
    {
        const containerHeight = container.element.clientHeight;
        const elementTop = element.offsetTop;
        const elementHeight = element.clientHeight;

        const scrollTo = elementTop - (containerHeight / 2) + (elementHeight / 2);

        container.element.scrollTo({
            top: scrollTo,
            behavior: 'smooth'
        });
    }

    AutoSelectScroll(container, type)
    {
        const containerElement = container.element;
        const scrollTop = containerElement.scrollTop;
        const containerHeight = containerElement.clientHeight;
        const centerPosition = scrollTop + (containerHeight / 2);

        const items = containerElement.children;
        let closestItem = null;
        let minDistance = Infinity;

        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            if (!item.dataset.value) {
                continue;
            }

            const itemTop = item.offsetTop;
            const itemCenter = itemTop + (item.clientHeight / 2);
            const distance = Math.abs(centerPosition - itemCenter);

            if (distance < minDistance) {
                minDistance = distance;
                closestItem = item;
            }
        }

        if (closestItem) {
            const value = parseInt(closestItem.dataset.value);

            if (type === 'year') {
                this.SelectYear(value, closestItem);
            } else if (type === 'month') {
                this.SelectMonth(value, closestItem);
            }

            this.ScrollToCenter(container, closestItem);
        }
    }

    SelectYear(year, comp)
    {
        if (this.m_selectedYear) {
            this.m_selectedYear.style.color = '#7C8292';
            this.m_selectedYear.style.fontWeight = '500';
        }

        comp.style.color = '#E91E63';
        comp.style.fontWeight = '600';
        this.m_selectedYear = comp;

        if (this.m_currentMode === 'start') {
            this.m_startYear = year;
        } else {
            this.m_endYear = year;
        }

        this.UpdateInput();
    }

    SelectMonth(month, comp)
    {
        if (this.m_selectedMonth) {
            this.m_selectedMonth.style.color = '#7C8292';
            this.m_selectedMonth.style.fontWeight = '500';
        }

        comp.style.color = '#E91E63';
        comp.style.fontWeight = '600';
        this.m_selectedMonth = comp;

        if (this.m_currentMode === 'start') {
            this.m_startMonth = month;
        } else {
            this.m_endMonth = month;
        }

        this.UpdateInput();
    }

    UpdateInput()
    {
        if (this.m_startYear && this.m_startMonth) {
            const mm = String(this.m_startMonth).padStart(2, '0');
            const value = this.m_startYear + '.' + mm;
            this.calendarPickerS.setDate(value);
        }

        if (this.m_endYear && this.m_endMonth) {
            const mm = String(this.m_endMonth).padStart(2, '0');
            const value = this.m_endYear + '.' + mm;
            this.calendarPickerE.setDate(value);
        }
    }

    OkBtnClick(comp, info, e)
    {
        const data = {
            startDate: this.calendarPickerS.getDateString().replace('.', ''),
            endDate: this.calendarPickerE.getDateString().replace('.', '')
        };

        this.getContainer().close(true, data);
    }
}
