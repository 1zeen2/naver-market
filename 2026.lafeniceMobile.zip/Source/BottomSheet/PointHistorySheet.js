
class PointHistorySheet extends AView
{
	constructor()
	{
		super()
        this._data = {};
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

        this.calendarPickerS.setCalendarIconRight();
        this.calendarPickerE.setCalendarIconRight();

        this.calendarPickerS.setCalendarIconImage('Assets/calendar_icon.png');
        this.calendarPickerE.setCalendarIconImage('Assets/calendar_img_gray.png');

        this.calendarPickerS.setCalendarIconStyle({
            'background-size': '16px 16px',
            'right': '4px'
        });
        this.calendarPickerE.setCalendarIconStyle({
            'background-size': '16px 16px',
            'right': '4px'
        });

        this.calendarPickerS.setCalendarPickerStyle({
            'border-radius': '6px',
            'border-color': '#CACED9'
        });
        this.calendarPickerE.setCalendarPickerStyle({
            'border-radius': '6px',
            'border-color': '#CACED9'
        });

        this.calendarPickerS.setCalendarPickerSelectedStyle({
            'border-color': '#E91E63'
        });
        this.calendarPickerE.setCalendarPickerSelectedStyle({
            'border-color': '#E91E63'
        });

        this.calendarPickerS.setCalendarInputStyle({
            'font-size': '13px',
            'font-weight': '500',
            'color': '#1F2129',
            'padding': '9px 0px 9px 12px',
            'font-family': 'Pretendard Variable'
        });
        this.calendarPickerE.setCalendarInputStyle({
            'font-size': '13px',
            'font-weight': '500',
            'color': '#1F2129',
            'padding': '9px 0px 9px 12px',
            'font-family': 'Pretendard Variable'
        });

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}


	StateBtnClick(comp, info, e)
	{
		const state_group = this.stateBtn_view.findCompByGroup(comp.groupName) || [];
        const period_group = this.periodBtn_view.findCompByGroup(comp.groupName) || [];
        const group = state_group.length > 0 ? state_group : period_group;
        const select_style = ['border-pink-500', 'text-pink-500'];
        const un_select_style = ['border-metal-200', 'text-metal-500'];

        group.forEach(item => {
            if(item !== comp){
                select_style.forEach(stl => item.removeClass(stl));
                un_select_style.forEach(stl => item.addClass(stl));
            } else {
                select_style.forEach(stl => item.addClass(stl));
                un_select_style.forEach(stl => item.removeClass(stl));
            }
        });

        this._data[`${comp.groupName}_value`] = comp.compId;
	}

    OnCloseWnd(comp, info, e)
	{
		this.getContainer().close(true, this._data);
	}
}

