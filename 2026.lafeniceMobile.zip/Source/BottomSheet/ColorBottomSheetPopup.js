
class ColorBottomSheetPopup extends AView
{
	constructor()
	{
		super()
	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    // TFUNCTION: OnColorViewClick: 색상 선택
	OnColorViewClick(comp, info, e)
	{
		this.getContainer().close(true, comp.compId);
	}
}

